# Um Dia de Safra — v8.5 (16/11/2026) — como continuar no Claude Code

## Estado
- Versão estável: v8.5. Entrada: `src/` (módulos na ordem de `src/_order.txt`) -> `dist/index.html` (HTML único, ~6,5 MB).
- Portão de qualidade (precisa do Playwright + Chrome): `node loop/gate.mjs .` -> "ok": true.
- Build: `sh loop/build.sh .` (portátil) ou `./build.sh` (tem caminho fixo /home/claude/s6f: ajuste).
- Em `loop/gate.mjs`, `shot.mjs` e `loop/retrato.mjs` ajuste os caminhos do Playwright (/opt/npm-tools/...) e do Chrome (/usr/bin/google-chrome).

## Leia primeiro
- `loop/DIRECAO.md`: direção do cliente (agroindústria real, Senior + GAtec de ponta a ponta, EPI, Operis YMS, Commerce, caso do motor).
- `loop/PROTOCOLO.md`: como os executores (Haiku) trabalham em cópia isolada + portão.
- `loop/diario.md`: histórico de rodadas.
- `loop/portfolio.md`, `loop/manual/*.md`: fonte única de produto e operação (não inventar além disso).
- `loop/manual/integracao.md`: fluxo oficial Senior ERP x GAtec (base do mapa ponta a ponta).
- `loop/design-system.md`: tokens do Senior Design System usados na home.
- `loop/historia/LEIA.md`: abertura, Valdemar (fiscal), Caderno de Campo, mirantes, devolutiva, conquistas.

## O que está no jogo (v8.5)
Home com design system; abertura com o Dr. Augusto; crachá de visitante + advertências/expulsão do Valdemar (só em balão);
10 paradas com conversa em 4 rodadas (SPIN) e barra de confiança; cartão do produto; selo "Resolvido"; mapa ponta a ponta
(GAtec x ERP); Caderno de Campo (tecla C, 46 verbetes); 3 mirantes; trilha e sons por zona (tecla N); personagens
Rocketbox (MIT) com EPI; cenário de agroindústria; 7 easter eggs; relatório com diagnóstico, pitch e kit de visita.

## Pendente (por prioridade)
1. FASE C (não integrada): reunião presencial com o diretor usando `DEVOLUTIVA`, mínimo de dores por nível
   (`NIVEIS_HISTORIA`), botão "Pedir a reunião" na Plataforma, conquistas (`CONQUISTAS`) no relatório. Hoje o final ainda
   é a "ligação" (showCall em ui__hud.js). Um rascunho interrompido pode estar em `em-andamento/fase-c/` (não testado).
2. Valdemar em 3D: um 11º avatar adicionado à cena não é desenhado (nem uma caixa de teste). Investigar como
   engine__renderer.js/main.js renderizam (passes, layers, mergeStaticByMaterial).
3. Dificuldade das conversas: o autor acertou 9/12 por pista superficial; refazer o teste com um agente que não escreveu.
4. Validar com o time agro: textos das conversas e cartões, frentes sem fonte literal, Commerce vs "Commerce SF".
5. Visual: conferir no olho a animação dos mirantes, a pílula de aviso, a placa de EPI, a fila da balança (não alinhada).
6. Performance: medir FPS real em notebook com GPU integrada (F3). Sombras e refletor ainda sem preset "integrada".
7. Fonte Public Sans não embutida; laranja do botão usa a versão acessível (#B95E00).
8. Crédito obrigatório: Microsoft Rocketbox Avatar Library (MIT) já aparece na home e no relatório.

## Lição de processo
Subagentes Haiku tendem a chamar `send_later` "para esperar": proibir explicitamente e mandar usar `sleep`.
Tarefas pequenas (1 arquivo/1 fase, <200k de contexto) rendem mais e custam menos.
