#!/bin/sh
# monta dist/index.html a partir dos módulos em src/ (ordem em src/_order.txt)
cd /home/claude/s6f && { cat src/_head.html; while read f; do cat "src/$f"; done < src/_order.txt; cat src/_tail.html; } > dist/index.html && wc -c dist/index.html
