// === world/humanos: troca os NPCs procedurais por personagens realistas (Microsoft Rocketbox, MIT) ===
// Cada parada recebe um avatar com esqueleto e animação de respiração (idle) da própria biblioteca.
// Se algo falhar ao carregar, os NPCs procedurais continuam visíveis (o jogo não depende disto).
const HUMANOS_CFG = [
  { m: 'Female_Adult_04', h: 1.66 },                                    // Helena, gerente (sede: sem EPI)
  { m: 'Wood_Male_01', h: 1.76, acc: 'chapeu' },                        // Caio, agrônomo
  { m: 'Construction_Female_01', h: 1.63, acc: 'chapeu' }, // Marta, encarregada de frente
  { m: 'Gardener_Male_01', h: 1.70, acc: 'capacete', cor: 0x2a6fb0 },  // Seu Tião, oficina (capacete azul)
  { m: 'Construction_Male_02', h: 1.79, acc: 'capacete', cor: 0x2a6fb0 }, // Rui, balança (capacete do modelo)
  { m: 'Female_Adult_07', h: 1.68, acc: 'capacete', cor: 0xf2c230 },    // Sílvia, indústria (capacete amarelo)
  { m: 'Construction_Male_07', h: 1.74, acc: 'capacete', cor: 0xf2c230 }, // Jonas, armazém (capacete do modelo)
  { m: 'Business_Female_01', h: 1.65 },                                 // Paula, controladoria
  { m: 'Delivery_Male_01', h: 1.78 },                                   // Rodrigo, centro de gestão
  { m: 'Construction_Male_08', h: 1.72, acc: 'capacete', cor: 0xf2c230 }    // André, porto (capacete do modelo)
];
const HUMANOS_IDLE = { m: 'Wood_Male_01', f: 'Female_Adult_04' };
// roupa de campo: avatares urbanos ganham tom terroso na roupa (nunca cabeça/rosto)
const HUMANOS_URBANOS = /^(Female_Adult_04|Female_Adult_07|Delivery_Male_01|Wood_Male_01)$/;

// Acessório preso ao osso Bip01_Head. Medidas em metros do mundo do grupo; o grupo é
// desenhado na escala do osso (1/escala do osso), então as medidas valem em metros reais.
// Frente da cabeça = direção até o osso do nariz (Bip01_MNose), no plano horizontal.
function acessorioCabeca(modelo, acc, cor, dy = 0) {
  const cabeca = modelo.getObjectByName('Bip01_Head');
  if (!cabeca) { console.warn('humanos: osso Bip01_Head nao encontrado'); return; }
  modelo.updateMatrixWorld(true);
  const pCab = cabeca.getWorldPosition(new THREE.Vector3());
  const bWS = cabeca.getWorldScale(new THREE.Vector3());
  const bWQ = cabeca.getWorldQuaternion(new THREE.Quaternion());
  const mWQ = modelo.getWorldQuaternion(new THREE.Quaternion());
  // boné substitui o capacete de obra do modelo (material *helmet*): esconde e mede o topo sem ele
  const ehCapacete = o => (Array.isArray(o.material) ? o.material : [o.material]).some(m => /helmet/i.test(m.name));
  // capacete: usa o que já vem no modelo; se não houver, cria um procedural (abaixo)
  let temCapNativo = false;
  modelo.traverse(o => { if (o.isMesh && ehCapacete(o)) temCapNativo = true; });
  if (acc === 'capacete' && temCapNativo) return;
  // chapéu ou boné substituem o capacete do modelo
  if (acc !== 'capacete') modelo.traverse(o => { if (o.isMesh && ehCapacete(o)) o.visible = false; });
  let topo = -Infinity; const caixa = new THREE.Box3();
  modelo.traverse(o => { if (o.isMesh && o.visible) { caixa.setFromObject(o, true); topo = Math.max(topo, caixa.max.y); } });
  let fr = new THREE.Vector3(0, 0, 1).applyQuaternion(mWQ);
  const nariz = modelo.getObjectByName('Bip01_MNose');
  if (nariz) { const d = nariz.getWorldPosition(new THREE.Vector3()).sub(pCab); d.y = 0; if (d.lengthSq() > 1e-10) fr = d.normalize(); }
  const fLoc = fr.clone().applyQuaternion(mWQ.clone().invert()); fLoc.y = 0; fLoc.normalize();
  const qAlinha = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 0, 1), fLoc);
  const g = new THREE.Group();
  const bone = acc === 'bone';
  // base do acessório na linha da testa: um pouco acima do meio das sobrancelhas
  const sobr = modelo.getObjectByName('Bip01_MMiddleEyebrow');
  const yTesta = sobr ? sobr.getWorldPosition(new THREE.Vector3()).y + 0.02 : pCab.y + 0.1;
  const ancora = new THREE.Vector3(pCab.x, yTesta + dy, pCab.z);
  g.position.copy(cabeca.worldToLocal(ancora));
  g.quaternion.copy(bWQ.clone().invert().multiply(mWQ).multiply(qAlinha));
  g.scale.setScalar(1 / ((bWS.x + bWS.y + bWS.z) / 3));
  if (bone) {
    // boné de tecido: copa de 6 gomos achatada sobre o crânio, viseira curta na linha da testa
    const c = new THREE.Color(cor).lerp(new THREE.Color(0x9a927f), 0.28);
    const tec = new THREE.MeshStandardMaterial({ color: c, roughness: 0.92, metalness: 0, flatShading: true });
    const cupula = new THREE.Mesh(new THREE.SphereGeometry(0.09, 6, 6, 0, Math.PI * 2, 0, Math.PI / 2), tec);
    cupula.scale.set(1, 0.85, 1.06);
    const viseira = new THREE.Mesh(new THREE.CylinderGeometry(0.085, 0.085, 0.005, 28, 1, false, -Math.PI / 2, Math.PI), tec);
    viseira.scale.set(0.95, 1, 0.85); viseira.position.set(0, 0.003, 0.08); viseira.rotation.x = 0.12;
    const botao = new THREE.Mesh(new THREE.SphereGeometry(0.009, 10, 6), tec); botao.position.y = 0.08;
    g.add(cupula, viseira, botao);
  } else if (acc === 'capacete') {
    // capacete de segurança procedural: casco arredondado, aba frontal curta e nervura central
    const R0 = 0.102;
    const plastico = new THREE.MeshStandardMaterial({ color: cor || 0xf2c230, roughness: 0.42, metalness: 0, side: THREE.DoubleSide });
    const perfil = [new THREE.Vector2(R0, 0)];
    const a = R0 * 0.97, y0 = 0.03, b = 0.075;
    for (let i = 0; i <= 20; i++) { const ph = (i / 20) * Math.PI / 2; perfil.push(new THREE.Vector2(a * Math.cos(ph), y0 + b * Math.sin(ph))); }
    const casco = new THREE.Mesh(new THREE.LatheGeometry(perfil, 56), plastico);
    casco.scale.set(0.92, 1, 1.14);
    // aba frontal: anel de meia-volta na frente, curta (3,5 cm)
    const aba = new THREE.Mesh(new THREE.RingGeometry(R0 - 0.012, R0 + 0.05, 40, 1, Math.PI * 1.12, Math.PI * 0.76), plastico);
    aba.rotation.x = -Math.PI / 2 + 0.16; aba.position.y = 0.004; aba.scale.set(0.92, 1.14, 1);
    const borda = new THREE.Mesh(new THREE.TorusGeometry(R0, 0.007, 8, 48), plastico); borda.rotation.x = Math.PI / 2; borda.scale.set(0.92, 1.14, 1); borda.position.y = 0.004;
    // nervura: fita curva do topo de trás até a frente, colada no casco
    const pts = [];
    for (let i = 0; i <= 24; i++) { const ph = Math.PI - (i / 24) * Math.PI; pts.push(new THREE.Vector3(0, y0 + b * Math.sin(ph) + 0.002, a * 1.14 * Math.cos(ph))); }
    const nervura = new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts), 40, 0.0055, 8), plastico);
    g.add(casco, aba, borda, nervura);
    // se o cabelo passar da altura padrão, o casco cresce um pouco para envolver o topo
    g.scale.y *= Math.max(0.95, Math.min(1.2, (topo - ancora.y + 0.004) / (b + y0)));
  } else {
    // chapeu de palha de vaqueiro: peça única (LatheGeometry) com copa abaulada, aba que sobe nas laterais e faixa escura
    const R0 = 0.092, BORDA = 0.065, ALT = 0.095; // raio no encaixe, largura da aba e altura da copa (m)
    const palha = new THREE.MeshStandardMaterial({ color: 0xc9ab72, roughness: 0.95, metalness: 0, side: THREE.DoubleSide });
    const fita = new THREE.MeshStandardMaterial({ color: 0x3b2716, roughness: 0.9, metalness: 0 });
    // perfil de cima para baixo: topo abaulado (quarto de elipse), lateral da copa, depois a aba por baixo e por cima
    const perfil = [];
    const a = R0 * 0.985, y0 = 0.052, b = 0.053;
    for (let i = 0; i <= 24; i++) { const ph = Math.PI / 2 - (i / 24) * Math.PI / 2; perfil.push(new THREE.Vector2(a * Math.cos(ph), y0 + b * Math.sin(ph))); }
    perfil.push(new THREE.Vector2(R0, 0));
    for (let i = 1; i <= 8; i++) { const s = i / 8; perfil.push(new THREE.Vector2(R0 + BORDA * s, -0.002 * s)); }
    perfil.push(new THREE.Vector2(R0 + BORDA + 0.0012, -0.001), new THREE.Vector2(R0 + BORDA + 0.0012, 0.0015));
    for (let i = 8; i >= 0; i--) { const s = i / 8; perfil.push(new THREE.Vector2(R0 + BORDA * s, 0.0015 + 0.0045 * (1 - s))); }
    const geo = new THREE.LatheGeometry(perfil, 72);
    const pos = geo.attributes.position;
    for (let k = 0; k < pos.count; k++) {
      const x = pos.getX(k), z = pos.getZ(k); let y = pos.getY(k);
      const r = Math.hypot(x, z);
      if (y > 0.03) y -= 0.01 * Math.exp(-Math.pow(r / 0.045, 2)); // vinco: afunda o topo ~1 cm no centro
      if (r > R0 + 0.001 && y < 0.02) { // aba: sobe nas laterais e cai um pouco na frente e atrás
        const f = Math.min(1, (r - R0) / BORDA), th = Math.atan2(x, z);
        y += Math.pow(f, 1.2) * (0.035 * Math.pow(Math.sin(th), 2) - 0.012 * Math.pow(Math.cos(th), 2));
      }
      pos.setY(k, y);
    }
    geo.computeVertexNormals();
    const hg = new THREE.Group(); hg.rotation.x = -0.105; hg.scale.set(0.95, 1, 1.12); // copa levemente oval, inclinada ~6° para trás
    const faixaM = new THREE.Mesh(new THREE.CylinderGeometry(R0 + 0.0012, R0 + 0.0012, 0.013, 48, 1, true), fita); faixaM.position.y = 0.0065;
    hg.add(new THREE.Mesh(geo, palha), faixaM);
    // se o cabelo passar da altura padrão, a copa cresce um pouco para envolver o topo do crânio
    hg.scale.y = Math.max(0.95, Math.min(1.2, (topo - ancora.y + 0.004) / ALT));
    g.add(hg);
  }
  g.traverse(o => { if (o.isMesh) o.castShadow = true; });
  cabeca.add(g);
}

// Roupa de campo: multiplica a cor do material do corpo por um tom terroso (clone, sem tocar na cabeça)
function tingirRoupa(modelo) {
  const TOM = new THREE.Color(0xd8ccb8);
  const tom = m => {
    if (!/body/i.test(m.name) || /head/i.test(m.name)) return m;
    const c = m.clone(); c.color.multiply(TOM); return c;
  };
  modelo.traverse(o => {
    if (!o.isMesh) return;
    o.material = Array.isArray(o.material) ? o.material.map(tom) : tom(o.material);
  });
}

// Osso animado: lê a pose base (do mixer) e evita acumular a correção de um quadro para o outro
function baseOsso(it, osso, chave) {
  const atual = osso.quaternion.clone();
  const ult = it[chave + 'Ult'], bas = it[chave + 'Base'];
  const base = (ult && bas && atual.equals(ult)) ? bas : atual;
  it[chave + 'Base'] = base;
  return base;
}
// Aplica uma rotação feita no espaço do mundo sobre a pose base do osso
function aplicarOsso(it, osso, chave, delta, base) {
  const pq = osso.parent.getWorldQuaternion(new THREE.Quaternion());
  const loc = pq.clone().invert().multiply(delta).multiply(pq);
  osso.quaternion.copy(loc).multiply(base);
  it[chave + 'Ult'] = osso.quaternion.clone();
}
// NPC: balanço lateral do tronco (±2°) e cabeça que acompanha o jogador (±50° de guinada, ±15° de inclinação)
function animarNPC(it, dt, cam) {
  if (!it.cabeca) return;
  const cl = (v, a, b) => Math.max(a, Math.min(b, v));
  const UP = new THREE.Vector3(0, 1, 0);
  it.t += dt;
  const frente = it.frente;
  if (it.tronco) {
    const base = baseOsso(it, it.tronco, 'tr');
    const balanco = 0.035 * Math.sin(it.t * 0.9 + it.fase);
    aplicarOsso(it, it.tronco, 'tr', new THREE.Quaternion().setFromAxisAngle(frente, balanco), base);
  }
  it.raiz.updateMatrixWorld(true);
  const cab = it.cabeca;
  const pCab = cab.getWorldPosition(new THREE.Vector3());
  const para = new THREE.Vector3().subVectors(cam, pCab);
  const hz = new THREE.Vector3(para.x, 0, para.z);
  let yawAlvo = 0, pitchAlvo = 0;
  if (it.p.position.distanceTo(cam) < 12 && hz.lengthSq() > 1e-6) {
    const cruz = frente.z * hz.x - frente.x * hz.z, dot = frente.x * hz.x + frente.z * hz.z;
    yawAlvo = cl(Math.atan2(cruz, dot), -0.87, 0.87);
    pitchAlvo = cl(Math.atan2(para.y, hz.length()), -0.26, 0.26);
  }
  const k = 1 - Math.exp(-4 * dt);
  it.yaw += (yawAlvo - it.yaw) * k;
  it.pitch += (pitchAlvo - it.pitch) * k;
  const base = baseOsso(it, cab, 'cab');
  const dY = new THREE.Quaternion().setFromAxisAngle(UP, it.yaw);
  const fY = frente.clone().applyAxisAngle(UP, it.yaw);
  const eixo = new THREE.Vector3().crossVectors(UP, fY).normalize();
  const dP = new THREE.Quaternion().setFromAxisAngle(eixo, -it.pitch);
  aplicarOsso(it, cab, 'cab', dP.multiply(dY), base);
}

function ligarHumanos() {
  const api = { pronto: false, erro: null, mixers: [], update(dt, cam) {
    // economia: só anima quem está a menos de 45 m da câmera
    for (const it of this.mixers) {
      if (!cam || it.p.position.distanceToSquared(cam) < 2025) { it.m.update(dt); if (cam) animarNPC(it, dt, cam); }
      // sombra só até ~40 m (histerese 38-42 m)
      const d2 = cam ? it.p.position.distanceToSquared(cam) : 0;
      const sombra = it.sombra ? d2 < 1764 : d2 < 1444;
      if (it.sombra !== sombra) { it.sombra = sombra; it.raiz.traverse(o => { if (o.isMesh) o.castShadow = sombra; }); }
    }
  } };
  window.__SAFRA_HUMANOS__ = api;
  const lib = globalThis.__SAFRA_GLTF__;
  if (!lib || typeof HUMANOS_GLB === 'undefined') { api.erro = 'sem loader'; return api; }
  const b64ToBuf = s => { const bin = atob(s); const u = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i); return u.buffer; };
  const loader = new lib.GLTFLoader();
  const parse = key => new Promise((ok, falha) => loader.parse(b64ToBuf(HUMANOS_GLB[key]), '', ok, falha));
  const chaves = [...new Set(HUMANOS_CFG.map(c => c.m))];

  Promise.all(chaves.map(parse)).then(lista => {
    const gltf = {}; chaves.forEach((k, i) => { gltf[k] = lista[i]; });
    const clip = { m: gltf[HUMANOS_IDLE.m].animations[0], f: gltf[HUMANOS_IDLE.f].animations[0] };
    PARADAS.forEach((s, i) => {
      const cfg = HUMANOS_CFG[i]; const P = s.person; if (!cfg || !P || !gltf[cfg.m]) return;
      const modelo = lib.SkeletonUtils.clone(gltf[cfg.m].scene);
      modelo.traverse(o => {
        if (!o.isMesh) return;
        o.castShadow = true; o.receiveShadow = true; o.frustumCulled = false;
        for (const m of (Array.isArray(o.material) ? o.material : [o.material])) {
          m.roughness = Math.max(m.roughness ?? 0.8, 0.72); m.metalness = 0; m.envMapIntensity = 0.55;
        }
      });
      const mixer = new THREE.AnimationMixer(modelo);
      const c = clip[/Female/.test(cfg.m) ? 'f' : 'm'];
      if (c) { const act = mixer.clipAction(c); act.play(); act.time = Math.random() * c.duration; act.timeScale = 0.85 + Math.random() * 0.3; }
      mixer.update(0.001);
      // escala pela altura real, já na pose de respiração (sem braços em T)
      modelo.updateMatrixWorld(true);
      const box = new THREE.Box3().setFromObject(modelo, true);
      const alt = Math.max(0.01, box.max.y - box.min.y);
      modelo.scale.multiplyScalar(cfg.h / alt);
      modelo.updateMatrixWorld(true);
      // assenta no chão e centraliza no grupo da parada (coordenadas locais do grupo)
      const box2 = new THREE.Box3().setFromObject(modelo, true); // ainda fora do grupo: coordenadas locais
      modelo.position.y -= box2.min.y;
      modelo.position.x -= (box2.min.x + box2.max.x) / 2;
      modelo.position.z -= (box2.min.z + box2.max.z) / 2;
      if (HUMANOS_URBANOS.test(cfg.m)) tingirRoupa(modelo);
      if (cfg.acc) acessorioCabeca(modelo, cfg.acc, cfg.cor, cfg.dy || 0);
      // esconde o boneco procedural (mantém a sombra de contato)
      P.children.forEach(ch => { if (!(ch.geometry && ch.geometry.type === 'CircleGeometry')) ch.visible = false; });
      P.add(modelo);
      // direção para onde o personagem olha (horizontal, do osso da cabeça para o nariz), e dados do olhar e do balanço
      modelo.updateMatrixWorld(true);
      const cabOsso = modelo.getObjectByName('Bip01_Head'), narizOsso = modelo.getObjectByName('Bip01_MNose');
      const frente = new THREE.Vector3(0, 0, 1);
      if (cabOsso && narizOsso) {
        frente.subVectors(narizOsso.getWorldPosition(new THREE.Vector3()), cabOsso.getWorldPosition(new THREE.Vector3())); frente.y = 0;
        if (frente.lengthSq() > 1e-10) frente.normalize(); else frente.set(0, 0, 1);
      }
      api.mixers.push({ m: mixer, p: P, raiz: modelo, cabeca: cabOsso, tronco: modelo.getObjectByName('Bip01_Spine1'), frente, fase: Math.random() * Math.PI * 2, t: 0, yaw: 0, pitch: 0 });
      s.humano = modelo;
    });
    api.pronto = true;
  }).catch(e => { api.erro = String(e && e.message || e); console.warn('humanos: ' + api.erro); });
  return api;
}
