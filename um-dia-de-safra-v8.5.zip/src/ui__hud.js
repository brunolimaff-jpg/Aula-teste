// === ui/hud.js ===

const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
// soma minutos a um horário "HH:MM" (relógio do dia depois de expulsão)
const addMin = (hhmm, m) => { const [h, mi] = hhmm.split(':').map(Number); const t = h * 60 + mi + m; return `${String(Math.floor(t / 60) % 24).padStart(2, '0')}:${String(t % 60).padStart(2, '0')}`; };
// Caderno de Campo: artigo, nome curto, "de/do" e "em/no" de cada parada, para montar as pistas ("Conclua a Oficina", "Converse na Balança")
const CAD_LUGAR = {
  plan: ['a', 'Sede', 'da', 'na'], geo: ['o', 'Talhão 12', 'do', 'no'], agri: ['a', 'Frente de colheita', 'da', 'na'],
  auto: ['a', 'Oficina', 'da', 'na'], orig: ['a', 'Balança', 'da', 'na'], ind: ['a', 'Indústria', 'da', 'na'],
  arm: ['o', 'Armazém e pátio', 'do', 'no'], custo: ['a', 'Controladoria', 'da', 'na'], erp: ['o', 'Centro de gestão', 'do', 'no'], com: ['o', 'Porto', 'do', 'no']
};
const CAD_CATS = ['Todos', 'Lugar', 'Equipamento', 'Processo', 'Termo', 'Pessoa', 'Sistema'];
// pista de um verbete travado: diz o que fazer, sem revelar o conteúdo
function cadPista(c) {
  const d = c.desbloqueio;
  if (d.tipo === 'parada') { const L = CAD_LUGAR[d.ref]; return `Conclua ${L[0]} ${L[1]}`; }
  if (d.tipo === 'conversa') { const L = CAD_LUGAR[d.ref]; return `Converse ${L[3]} ${L[1]}`; }
  if (d.tipo === 'evidencia') { const ev = EVIDENCIAS.find(e => e.id === d.ref); const L = CAD_LUGAR[ev.st]; return `Colete a evidência ${L[2]} ${L[1]}`; }
  if (d.tipo === 'egg') return 'Ache um segredo';
  if (d.tipo === 'lugar') {
    // parada mais próxima do ponto do verbete
    let best = PARADAS[0], bd = 1e9;
    for (const p of PARADAS) { const dd = Math.hypot(p.x - d.ref.x, p.nz - d.ref.z); if (dd < bd) { bd = dd; best = p; } }
    const L = CAD_LUGAR[best.id]; return `Explore perto ${L[2]} ${L[1]}`;
  }
  return '';
}

class HUD {
  constructor(state, callbacks) {
    this.state = state;
    this.cb = callbacks;
    this.el = id => document.getElementById(id);

    // Build frentes aggregation
    const map = {};
    PARADAS.forEach(p => p.frentes.forEach(f => {
      if (!map[f.n]) map[f.n] = { f, list: [] };
      map[f.n].list.push(() => !!this.state.feitas[p.id]);
    }));
    SINAIS.forEach(sg => {
      if (!map[sg.n]) map[sg.n] = { f: { n: sg.n, p: sg.p, c: sg.c }, list: [] };
      map[sg.n].list.push(() => !!this.state.sinais[sg.id]);
    });
    this.frentesAgg = Object.values(map);

    this.buildTrilha();
    this.bindTopButtons();
    this.crachaInit();
  }

  buildTrilha() {
    const tr = this.el('trilha');
    tr.innerHTML = PARADAS.map((_, i) => `<i data-i="${i}"></i>`).join('');
  }

  bindTopButtons() {
    this.el('btIr').onclick = () => this.cb.goToStop();
    this.el('btPlat').onclick = () => this.showPlatform();
    this.el('btMenu').onclick = () => this.showPause();
    // celular: botão do Caderno ao lado da Pausa (o CSS mostra só em body.toque e no jogo)
    const btCad = document.createElement('button');
    btCad.type = 'button'; btCad.id = 'btCadTop'; btCad.textContent = 'Caderno';
    btCad.setAttribute('aria-label', 'Abrir o Caderno de Campo');
    this.el('btMenu').insertAdjacentElement('afterend', btCad);
    btCad.onclick = () => { if (!this.state.modalOpen) this.showCaderno(); };
    this.el('btFala').onclick = () => this.cb.triggerInteract();
    this.el('btMedCop').onclick = () => {
      navigator.clipboard?.writeText(this.el('medTxt').textContent).catch(() => {});
      this.notify('Medição copiada');
    };
  }

  // ===== Abertura: reunião inicial na sala da diretoria. Pulável; as falas vão no balão existente (playCena). =====
  abertura(nivel) {
    const base = ABERTURA.falas, ext = ABERTURA.porNivel[nivel];
    const falas = ext ? [...base.slice(0, ext.apos), ...ext.falas, ...base.slice(ext.apos)] : base;
    return new Promise(resolve => {
      const v = document.createElement('div');
      v.id = 'aberturaVeu'; v.className = 'abertura-veu';
      v.innerHTML = `<div class="abertura-card"><small>Sala da diretoria · 05:15</small><h2>${esc(ABERTURA.titulo)}</h2><p>${esc(ABERTURA.cenario)}</p><button class="bt bt-s" id="aberturaPular">Pular</button></div>`;
      document.body.appendChild(v);
      const fim = () => { v.remove(); resolve(); };
      v.querySelector('#aberturaPular').onclick = () => (this._cenaFim ? this._cenaFim() : fim());
      this.playCena({ quem: ABERTURA.quem, roteiro: falas }).then(fim);
    });
  }

  // Crachá de visitante no HUD: uma marca por advertência permitida no nível; a última fica vermelha
  crachaInit() {
    const p = this.el('pontos'), bloco = p && p.closest('.dado');
    const b = document.createElement('div');
    b.id = 'crachaHud'; b.className = 'cracha-hud'; b.hidden = true;
    if (bloco) bloco.insertAdjacentElement('afterend', b); else document.body.appendChild(b);
    this._cracha = b;
  }

  atualizaCracha() {
    const b = this._cracha, st = this.state;
    if (!b) return;
    const cr = st.cracha, lim = REGRAS_CRACHA.advertenciasAteExpulsao[st.nivel] || 3;
    b.hidden = !st.on || st.demo;
    b.innerHTML = `<b>VISITANTE</b><span class="marcas" aria-label="${cr.adv} de ${lim} advertências">${Array.from({ length: lim }, (_, k) => `<i class="${k < cr.adv ? (k === lim - 1 ? 'vermelho' : 'on') : ''}"></i>`).join('')}</span>`;
  }

  pulsaCracha() {
    const b = this._cracha; if (!b) return;
    b.classList.remove('pisca'); void b.offsetWidth; b.classList.add('pisca');
  }

  // Tela cheia (veu meio) para expulsão e fim de visita. botoes: [{rotulo, cls, acao}]
  mostraTela(olho, titulo, corpo, botoes) {
    const veu = this.el('veu'), folha = this.el('folha');
    veu.className = 'veu meio'; veu.hidden = false; this.state.modalOpen = true;
    if (document.pointerLockElement) document.exitPointerLock?.();
    folha.innerHTML = `<div class="olho">${esc(olho)}</div><h2>${esc(titulo)}</h2>${corpo.map(t => `<p class="nota">${esc(t)}</p>`).join('')}<div class="linha-b" style="margin-top:14px">${botoes.map((b, k) => `<button class="bt ${b.cls}" data-tela="${k}">${esc(b.rotulo)}</button>`).join('')}</div>`;
    botoes.forEach((b, k) => { folha.querySelector(`[data-tela="${k}"]`).onclick = () => b.acao(); });
  }

  // Legenda de cena: faixa fixa embaixo, sem modal e sem mexer em state.
  cenaEl() {
    if (this._cena) return this._cena;
    const el = document.createElement('div');
    el.id = 'cena';
    document.body.appendChild(el);
    this._cena = el;
    return el;
  }

  // Balão de fala: letra a letra (25 ms), pulável; Você à direita, personagem à esquerda; sem digitação com movimento reduzido.
  playCena(parada) {
    const falas = (parada && parada.roteiro) || [];
    if (!falas.length) return Promise.resolve();
    const el = this.cenaEl();
    if (this._cenaFim) this._cenaFim();
    const reduz = !!(window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches);
    const [nomeP, ...cargoP] = String(parada.quem || '').split(', ');
    const cargo = cargoP.join(', ');
    return new Promise(resolve => {
      let i = -1, seq = 0, timer = 0, digit = 0, texto = '';
      const parar = () => { clearInterval(digit); digit = 0; };
      const fim = () => {
        clearTimeout(timer); parar(); seq++;
        el.classList.remove('on'); el.onclick = null;
        window.removeEventListener('keydown', tecla, true);
        if (this._cenaFim === fim) this._cenaFim = null;
        resolve();
      };
      const pronto = () => { // texto inteiro na tela; agenda a próxima fala
        parar();
        const t = el.querySelector('.txt'); if (t) t.textContent = texto;
        clearTimeout(timer); timer = setTimeout(proxima, 3000);
      };
      const proxima = () => {
        clearTimeout(timer); parar(); i++;
        if (i >= falas.length) return fim();
        const [quem, fala] = falas[i];
        const eu = quem === 'Você';
        const meu = ++seq;
        texto = fala;
        const mostraCargo = !eu && quem === nomeP && cargo;
        el.className = (eu ? 'voce' : 'pers') + ' on';
        el.innerHTML = `<i></i><div class="who"><b>${esc(eu ? 'Você' : quem)}</b>${mostraCargo ? `<small>${esc(cargo)}</small>` : ''}</div>` +
          `<p class="txt"></p><div class="pts"><span>${i + 1} de ${falas.length}</span>${falas.map((_, k) => `<s class="${k <= i ? 'on' : ''}"></s>`).join('')}</div>` +
          `<div class="dica">${document.body.classList.contains('toque') ? 'Toque para avançar' : 'Espaço ou toque para avançar'}</div>`;
        void el.offsetWidth; el.classList.add('entra');
        if (reduz) return pronto();
        const txt = el.querySelector('.txt'); let k = 0;
        digit = setInterval(() => {
          if (meu !== seq) return parar();
          k++; txt.textContent = texto.slice(0, k);
          if (k >= texto.length) pronto();
        }, 25);
      };
      const avanca = () => { if (digit) pronto(); else proxima(); };
      const tecla = e => {
        if (e.code === 'Space' && !e.repeat) { e.preventDefault(); avanca(); }
      };
      window.addEventListener('keydown', tecla, true);
      el.onclick = avanca;
      this._cenaFim = fim;
      proxima();
    });
  }

  setLoading(msg, pct) {
    this.el('cargaStatus').textContent = msg;
    this.el('cargaFill').style.width = `${pct}%`;
  }

  hideLoading() {
    const c = this.el('carga');
    c.style.opacity = '0';
    setTimeout(() => { c.hidden = true; }, 450);
  }

  // Avisos e rádio: uma pílula por vez no topo central; a nova substitui a anterior
  notify(msg) {
    const box = this.el('avisos');
    box.innerHTML = '';
    this.el('radio').style.opacity = '0';
    const div = document.createElement('div');
    div.className = 'aviso';
    div.textContent = msg;
    box.appendChild(div);
    setTimeout(() => div.remove(), 3100);
  }

  showRadio(txt) {
    const r = this.el('radio');
    this.el('avisos').innerHTML = '';
    this.el('radioTxt').textContent = txt;
    r.style.opacity = '1';
    clearTimeout(this._radioT);
    this._radioT = setTimeout(() => { r.style.opacity = '0'; }, 4800);
  }

  showLocalCard(nome, sub) {
    const loc = this.el('local');
    this.el('localNome').textContent = nome;
    this.el('localSub').textContent = sub;
    loc.classList.remove('on');
    void loc.offsetWidth;
    loc.classList.add('on');
    clearTimeout(this._locT);
    this._locT = setTimeout(() => loc.classList.remove('on'), 3200);
  }

  updateTopHUD() {
    const st = this.state;
    const cur = PARADAS[st.i];
    this.el('relogio').textContent = cur ? addMin(cur.hora, st.atraso || 0) : '18:00';
    this.atualizaCracha();
    this.el('pontos').textContent = String(st.pontos);

    const bars = this.el('trilha').querySelectorAll('i');
    bars.forEach((b, idx) => {
      b.className = st.feitas[PARADAS[idx].id] ? 'ok' : (idx === st.i ? 'now' : '');
    });

    if (cur && !st.fim) {
      this.el('alvo').hidden = false;
      this.el('alvoHora').textContent = `${cur.hora} · Parada ${st.i + 1} de ${PARADAS.length}`;
      this.el('alvoNome').textContent = cur.lugar;
      this.el('alvoDica').textContent = `Fale com ${cur.quem.split(',')[0]}`;
    } else {
      this.el('alvo').hidden = true;
    }
  }

  updateInteractPrompt(target, holdProgress) {
    const el = this.el('fala');
    if (!target || this.state.modalOpen || !this.state.on) {
      el.hidden = true;
      return;
    }
    el.hidden = false;
    // personagem: nome em destaque, cargo embaixo; demais alvos mantêm o texto original
    const [nomeP, ...cargoP] = String(target.title).split(', ');
    const personagem = target.type === 'parada';
    this.el('falaTxt').textContent = personagem ? nomeP : target.title;
    this.el('falaCargo').textContent = personagem ? cargoP.join(', ') : '';
    this.el('falaSub').textContent = personagem ? 'Segure E para conversar' : target.sub;
    const offset = 125.7 * (1 - Math.min(1, Math.max(0, holdProgress)));
    this.el('falaAnel').style.strokeDashoffset = String(offset);
  }

  drawCompass(playerX, playerZ, playerYaw) {
    const cvs = this.el('bussola');
    if (!this.state.on || cvs.hidden) return;
    const ctx = cvs.getContext('2d');
    const w = cvs.width, h = cvs.height;
    ctx.clearRect(0, 0, w, h);

    ctx.fillStyle = 'rgba(7,20,22,0.72)';
    ctx.fillRect(0, 0, w, h);
    ctx.strokeStyle = 'rgba(226,240,234,0.2)';
    ctx.strokeRect(0.5, 0.5, w - 1, h - 1);

    const cur = PARADAS[this.state.i];
    if (cur) {
      const dx = cur.x - playerX;
      const dz = cur.nz - playerZ;
      const targetAngle = Math.atan2(-dx, -dz);
      let diff = targetAngle - playerYaw;
      while (diff > Math.PI) diff -= Math.PI * 2;
      while (diff < -Math.PI) diff += Math.PI * 2;
      const px = w / 2 - (diff / (Math.PI / 2)) * (w * 0.42);
      const clamped = Math.max(16, Math.min(w - 16, px));
      ctx.fillStyle = '#ffb629';
      ctx.beginPath();
      ctx.moveTo(clamped, 6);
      ctx.lineTo(clamped + 6, 16);
      ctx.lineTo(clamped - 6, 16);
      ctx.closePath();
      ctx.fill();
      ctx.fillStyle = '#eef6f1';
      ctx.font = '700 10px Inter, sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText(`${Math.round(Math.hypot(dx, dz))} m`, clamped, 26);
    }
  }

  showTitle(autoDet) {
    const veu = this.el('veu');
    const folha = this.el('folha');
    veu.className = 'veu titulo';
    veu.hidden = false;
    this.state.modalOpen = true;
    document.body.classList.remove('jogo');

    folha.innerHTML = `
      <div class="hm">
        <header class="hm-top">
          <div class="hm-marca"><i></i><span>Senior · Agro</span></div>
          <span class="hm-assina">GAtec <em>by</em> Senior</span>
        </header>
        <div class="hm-texto">
          <h1 class="hm-titulo">Um Dia de Safra</h1>
          <p class="hm-sub">Um dia numa agroindústria para ver, de ponta a ponta, onde Senior e GAtec fazem diferença.</p>
          <p class="hm-missao">A Usina Horizonte perdeu margem. Você tem um dia para descobrir onde.</p>
          <h2 class="hm-h">O que você vai fazer</h2>
          <ul class="hm-cards">
            <li class="hm-card">
              <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 5h16v11H9l-5 4V5z"/></svg>
              <b>Ouvir</b><span>10 conversas em que o argumento conta.</span>
            </li>
            <li class="hm-card">
              <svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="5" cy="12" r="2.5"/><circle cx="19" cy="6" r="2.5"/><circle cx="19" cy="18" r="2.5"/><path d="M7.3 10.8l9.4-3.6M7.3 13.2l9.4 3.6"/></svg>
              <b>Conectar</b><span>Cada dor à solução certa.</span>
            </li>
            <li class="hm-card">
              <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12.5l4.2 4.2L19 7"/><path d="M4 20h16"/></svg>
              <b>Fechar</b><span>A ligação com o diretor e o mapa de ponta a ponta.</span>
            </li>
          </ul>
        </div>
        <div class="hm-form">
          <label class="campo hm-campo" for="nome">Seu nome<input id="nome" value="${esc(this.state.nome)}" maxlength="40" autocomplete="off"></label>
          <div class="hm-bloco">
            <span class="hm-rot">Nível</span>
            <div class="hm-niveis" id="segNivel">
              ${Object.entries(NIVEIS).map(([k, v]) => `<button data-n="${k}" class="${this.state.nivel === k ? 'on' : ''}"><b>${esc(v.n)}</b><small>${esc(v.d)}</small></button>`).join('')}
            </div>
            <span class="hm-sr" id="nivelDesc" aria-live="polite">${esc(NIVEIS[this.state.nivel].d)}</span>
          </div>
          <div class="hm-ajustes">
            <div class="hm-bloco">
              <span class="hm-rot">Qualidade gráfica</span>
              <div class="seg" id="segQual">
                <button data-q="auto" class="${this.state.cfg.qualAuto ? 'on' : ''}">Auto</button>
                <button data-q="alta" class="${!this.state.cfg.qualAuto && this.state.cfg.qual === 'alta' ? 'on' : ''}">Alta</button>
                <button data-q="media" class="${!this.state.cfg.qualAuto && this.state.cfg.qual === 'media' ? 'on' : ''}">Média</button>
                <button data-q="baixa" class="${!this.state.cfg.qualAuto && this.state.cfg.qual === 'baixa' ? 'on' : ''}">Baixa</button>
              </div>
            </div>
            <div class="hm-bloco">
              <span class="hm-rot">Som</span>
              <div class="seg" id="segSom">
                <button data-s="1" class="${this.state.cfg.som ? 'on' : ''}">Ligado</button>
                <button data-s="0" class="${!this.state.cfg.som ? 'on' : ''}">Mudo</button>
              </div>
            </div>
          </div>
          <p class="hm-duracao">Duração estimada: cerca de 20 minutos.</p>
        </div>
        <div class="hm-acoes">
          <button class="bt hm-primario" id="entrar">Começar o dia</button>
          <button class="bt hm-secundario" id="demo">Ver a demonstração</button>
        </div>
        <div class="hm-ctrl">
          <p class="hm-ctrl-tecla nota-tecla">Mouse: clique na cena para olhar. WASD anda, Shift corre, E interage, G leva à parada, M abre a plataforma, P pausa.</p>
          <p class="hm-ctrl-toque nota-toque">Celular: o polegar esquerdo anda e o direito olha. Segure o botão de fala para conversar e registrar evidências.</p>
          <p class="hm-som">Com som: tecla N liga e desliga a música.</p>
        </div>
        <footer class="hm-rodape">
          <p>A Usina Horizonte e as pessoas são fictícias. <span class="hm-qual">Qualidade detectada: <b>${esc(autoDet)}</b>.</span></p>
          <p>Personagens 3D: Microsoft Rocketbox Avatar Library (MIT).</p>
        </footer>
      </div>
    `;

    folha.querySelectorAll('#segQual button').forEach(b => {
      b.onclick = () => {
        const q = b.dataset.q;
        this.cb.setQuality(q);
        folha.querySelectorAll('#segQual button').forEach(x => x.classList.toggle('on', x === b));
      };
    });
    folha.querySelectorAll('#segNivel button').forEach(b => {
      b.onclick = () => {
        this.state.nivel = b.dataset.n;
        window.SAFRA_BRILHO = NIVEIS[this.state.nivel].brilho;
        this.el('nivelDesc').textContent = NIVEIS[this.state.nivel].d;
        folha.querySelectorAll('#segNivel button').forEach(x => x.classList.toggle('on', x === b));
      };
    });
    folha.querySelectorAll('#segSom button').forEach(b => {
      b.onclick = () => {
        const on = b.dataset.s === '1';
        this.state.cfg.som = on;
        this.cb.updateAudio();
        folha.querySelectorAll('#segSom button').forEach(x => x.classList.toggle('on', x === b));
      };
    });
    this.el('entrar').onclick = () => {
      this.state.nome = (this.el('nome').value || 'Consultor').trim();
      this.closeModal();
      this.cb.startGame(false);
    };
    this.el('demo').onclick = () => {
      this.state.nome = (this.el('nome').value || 'Consultor').trim();
      this.closeModal();
      this.cb.startGame(true);
    };
  }

  closeModal() {
    clearInterval(this._digit); this._digit = 0; // fala em digitação para ao fechar
    // fechar o Caderno marca os recém-destravados como vistos (sem o selo "novo" nas próximas vezes)
    if (this._cad) { this._cad = null; this.state.codexNovos = {}; }
    // durante a ligação o veu não fecha: o relógio continua e a ligação termina sozinha
    if (this._ligacaAtiva) { this.el('pausaVeu').hidden = true; return; }
    this.el('veu').hidden = true;
    this.el('pausaVeu').hidden = true;
    const fechou = this.state.modalOpen;
    this.state.modalOpen = false;
    document.body.classList.remove('falando');
    if (fechou && this.cb.playModal) this.cb.playModal(false);
  }

  openStopModal(parada) {
    const veu = this.el('veu');
    const folha = this.el('folha');
    const st = this.state;
    if (st.demo && !st.feitas[parada.id]) this.convAutoDemo(parada);
    clearInterval(this._digit); this._digit = 0; this._digitTok = Math.random();
    veu.className = 'veu convers';
    veu.hidden = false;
    const abriu = !st.modalOpen;
    st.modalOpen = true;
    document.body.classList.add('falando');
    if (abriu && this.cb.playModal) this.cb.playModal(true);
    if (document.pointerLockElement) document.exitPointerLock?.();

    const feita = st.feitas[parada.id];
    const nv = NIVEIS[st.nivel] || NIVEIS.executivo;
    const ato = ATOS.find(a => a.n === parada.ato);
    if (parada.desculpa && !st.desculpas[parada.id]) st.desculpas[parada.id] = parada.desculpa;
    const evs = EVIDENCIAS.filter(e => e.st === parada.id);
    const ops = this.opsConexao(parada);
    const nome = parada.quem.split(',')[0];

    let html = `
      <div class="olho">${ato ? `Ato ${ato.n} · ${esc(ato.t)} · ` : ''}${esc(parada.hora)} · ${esc(parada.lugar)}</div>
      ${parada.aprende ? `<p class="nota"><b>Como funciona aqui:</b> ${esc(parada.aprende)}</p>` : ''}
      <h2>${esc(parada.quem)}</h2>
      <div class="cena">${esc(parada.cena)}</div>
    `;
    if (evs.length) {
      html += `<h3>Evidências no local</h3><div class="chips">${evs.map(ev => `<span>${st.evid[ev.id] ? '✓ ' : '· '}${esc(ev.n)}</span>`).join('')}</div>`;
    }

    let lista = [];
    if (feita) {
      const ord = this.ordemEstavel(ops.length, parada.id + 'o');
      html += `<h3>Conectar à frente certa</h3>` + ord.map(idx => {
        const op = ops[idx];
        return `<button class="op ${op[1] === 1 ? 'sim' : ''}" disabled><b>${esc(op[0])}</b></button>`;
      }).join('');
      const c = st.conv && st.conv[parada.id];
      if (c && c.log && c.log.length) {
        html += `<details class="conv-hist"><summary>Ver a conversa</summary><div class="log">${this.convBolhas(c, nome, true)}</div></details>`;
      }
      html += this.renderFrentesSolved(parada) + this.renderCartao(parada);
    } else {
      lista = this.convDe(parada).fim ? [] : this.convOpcoes(parada);
      html += this.convHTML(parada, nv, ops, lista, nome);
    }

    html += `<div class="linha-b" style="margin-top:16px">
      <button class="bt bt-s" id="btFecharConv">Voltar à cena <kbd>Esc</kbd></button>
      ${feita && parada.id === 'custo' ? `<button class="bt bt-a" id="btMapa">Ver a operação de ponta a ponta</button>` : ''}
      ${feita && this.state.i >= PARADAS.length ? `<button class="bt bt-a" id="btVerRel">Atender o Dr. Augusto</button>` : ''}
    </div>`;

    folha.innerHTML = html;
    if (!feita) this.layoutConversa(folha);
    this.convBind(parada, ops, lista, feita);
  }

  // Celular paisagem curto: cabeçalho e histórico à esquerda; confiança e opções à direita
  layoutConversa(folha) {
    const conv = folha.querySelector('.conv');
    if (!conv || !window.matchMedia('(max-height: 520px) and (orientation: landscape)').matches) return;
    const esq = document.createElement('div'); esq.className = 'cv-esq';
    const dir = document.createElement('div'); dir.className = 'cv-dir';
    const cab = document.createElement('div'); cab.className = 'cv-cab';
    conv.prepend(esq);
    esq.appendChild(cab);
    for (let n = folha.firstElementChild; n && n !== conv; n = folha.firstElementChild) cab.appendChild(n);
    const log = conv.querySelector('.log');
    if (log) esq.appendChild(log);
    ['.etapas', '.conf', '#convOpc'].forEach(sel => { const n = conv.querySelector(sel); if (n) dir.appendChild(n); });
    const bl = folha.querySelector('.linha-b');
    if (bl) dir.appendChild(bl);
    conv.appendChild(dir);
  }

  // ===== Conversa em rodadas (SPIN): confiança 0 a 100, escuta ativa, pontos e gafes =====
  convDe(parada) {
    const st = this.state;
    st.conv = st.conv || {};
    if (!st.conv[parada.id]) {
      const ini = { trainee: 45, executivo: 35, especialista: 25 }[st.nivel] || 35;
      st.conv[parada.id] = { r: 0, conf: ini, log: [], fim: null, usados: [], bonus: false };
    }
    return st.conv[parada.id];
  }

  ordemEstavel(n, key) {
    this._ordens = this._ordens || {};
    if (this._ordens[key] && this._ordens[key].length === n) return this._ordens[key];
    const a = [...Array(n).keys()];
    for (let i = n - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; }
    return (this._ordens[key] = a);
  }

  convRotulo(v) { return v < 35 ? 'Desconfiado' : v < 60 ? 'Ouvindo' : v < 80 ? 'Aberto' : 'Confia em você'; }

  // opções da rodada atual: isca só no especialista; evidência como 4ª opção na implicação
  convOpcoes(parada) {
    const st = this.state, c = this.convDe(parada), nv = NIVEIS[st.nivel] || NIVEIS.executivo;
    const rod = parada.conversa[c.r];
    let lista = rod.opcoes.map((o, i) => ({ ...o, i }));
    if (rod.etapa === 'proposta') lista = lista.filter(o => !c.usados.includes(o.i));
    else if (!nv.isca) lista = lista.filter(o => o.q !== 'isca');
    if (rod.etapa === 'implicacao') {
      const ev = EVIDENCIAS.find(e => e.st === parada.id && st.evid[e.id] && rod.evR && rod.evR[e.id]);
      if (ev) lista.push({ t: `Mostrar o que você viu: ${ev.n}`, q: 'evid', r: rod.evR[ev.id], i: 'ev' });
    }
    return lista;
  }

  convBolhas(c, nome, instantaneo) {
    return c.log.map(m => {
      const quem = m.q === 'voce' ? 'Você' : nome;
      const escrevendo = m.anim && !instantaneo;
      const cls = `bal ${m.q}${escrevendo && m.tremer ? ' tremer' : ''}`;
      return `<div class="${cls}"><small>${esc(quem)}</small><p class="txt">${esc(escrevendo ? '' : m.t)}</p></div>`;
    }).join('');
  }

  convHTML(parada, nv, ops, lista, nome) {
    const c = this.convDe(parada);
    const rod = parada.conversa[Math.min(c.r, parada.conversa.length - 1)];
    const etapas = ['Situação', 'Problema', 'Implicação', 'Proposta'];
    const pend = !!(c.log.length && c.log[c.log.length - 1].anim);
    const cls = c.conf < 35 ? 'baixa' : c.conf >= 70 ? 'alta' : '';
    const pen = Math.round(20 * nv.pesoErro);
    let h = `<h3>Conversa</h3><div class="conv">
      <div class="etapas">${etapas.map((e, i) => `<span class="${c.fim === 'ok' || i < c.r ? 'ok' : (i === c.r && !c.fim ? 'on' : '')}">${e}</span>`).join('')}</div>
      <div class="conf ${cls}"><div class="rot"><span>Confiança ${c.conf}</span><b>${this.convRotulo(c.conf)}</b></div><div class="faixa"><i style="width:${c.conf}%"></i></div></div>
      <div class="log" id="convLog">${this.convBolhas(c, nome, false)}</div>
      <div id="convOpc">`;
    if (pend) {
      // a fala do personagem está sendo digitada; as opções aparecem depois
    } else if (c.fim === 'ok') {
      h += `<p class="nota">Ela aceitou ouvir a proposta. Agora, a conexão com a frente certa.</p>`;
      if (c.conf >= 70) h += `<p class="nota">Confiança alta no fim da conversa: ao conectar, +20 pontos.</p>`;
      h += this.ordemEstavel(ops.length, parada.id + 'o').map(idx => `<button class="op" data-op="${idx}"><b>${esc(ops[idx][0])}</b><span id="opMsg-${idx}" hidden></span></button>`).join('');
    } else if (c.fim) {
      h += `<div class="fim">${c.fim === 'cortou' ? 'A conversa acabou aí.' : 'Ela encerrou a conversa.'}</div>
        <div class="linha-b"><button class="bt bt-a" id="convTentar">Tentar de novo (-${pen} pts)</button></div>`;
    } else {
      if (nv.dica) h += `<p class="nota conv-dica">${esc(rod.dica)}</p>`;
      const ord = this.ordemEstavel(lista.length, parada.id + 'r' + c.r + '_' + lista.length + '_' + c.usados.join('.'));
      h += ord.map(k => `<button class="op conv-op" data-k="${k}"><b>${esc(lista[k].t)}</b></button>`).join('');
    }
    return h + `</div></div>`;
  }

  convBind(parada, ops, lista, feita) {
    const st = this.state, folha = this.el('folha');
    this.el('btFecharConv').onclick = () => this.closeModal();
    if (this.el('btVerRel')) this.el('btVerRel').onclick = () => this.showCall();
    if (this.el('btMapa')) this.el('btMapa').onclick = () => this.showMapa(() => this.openStopModal(parada));
    if (feita) return;
    const nv = NIVEIS[st.nivel] || NIVEIS.executivo;
    const c = this.convDe(parada);
    folha.querySelectorAll('[data-k]').forEach(b => {
      b.onclick = () => { this.convEscolher(parada, lista[Number(b.dataset.k)], false); this.openStopModal(parada); };
    });
    folha.querySelectorAll('[data-op]').forEach(btn => {
      btn.onclick = () => {
        if (btn.classList.contains('nao')) return; // errada já contada: duplo clique não penaliza de novo
        const idx = Number(btn.dataset.op), op = ops[idx];
        st.tent++;
        if (op[1] === 1) {
          if (c.conf >= 70 && !c.bonus) { c.bonus = true; st.pontos += 20; }
          this.cb.completeStop(parada);
          this.openStopModal(parada);
        } else {
          btn.classList.add('nao', 'tremer');
          st.pontos = Math.max(0, st.pontos - Math.round(6 * nv.pesoErro));
          this.updateTopHUD();
          const msg = this.el(`opMsg-${idx}`);
          msg.textContent = op[2];
          msg.hidden = false;
          this.cb.playErr();
          // errar a conexão duas vezes na mesma parada vira advertência (uma só vez)
          st.conexErr = st.conexErr || {};
          st.conexErr[parada.id] = (st.conexErr[parada.id] || 0) + 1;
          if (st.conexErr[parada.id] === 2) this.cb.advertir('conexao_errada_duas_vezes');
        }
      };
    });
    const tent = this.el('convTentar');
    if (tent) tent.onclick = () => {
      st.pontos = Math.max(0, st.pontos - Math.round(20 * nv.pesoErro));
      delete st.conv[parada.id];
      this.updateTopHUD();
      this.openStopModal(parada);
    };
    const log = this.el('convLog');
    if (log) log.scrollTop = log.scrollHeight;
    if (c.log.length && c.log[c.log.length - 1].anim) { this.convTipar(parada); return; }
    // no meio da conversa, leva as opções para a vista (o modal rola)
    if (c.log.length > 2 && this.el('convOpc')) this.el('convOpc').scrollIntoView({block: 'nearest'});
  }

  // Fala do personagem letra a letra; clique na conversa pula. Ao terminar, redesenha o modal com as opções.
  convTipar(parada) {
    const c = this.convDe(parada);
    const m = c.log[c.log.length - 1];
    const log = this.el('convLog');
    const bolha = log && log.lastElementChild;
    if (!bolha) return;
    const p = bolha.querySelector('.txt');
    const tok = this._digitTok;
    const reduz = !!(window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches);
    const cur = document.createElement('span');
    cur.className = 'cur';
    bolha.appendChild(cur);
    const t0 = performance.now();
    const fim = () => { clearInterval(this._digit); this._digit = 0; m.anim = false; this.openStopModal(parada); };
    if (reduz) { p.textContent = m.t; fim(); return; }
    log.onclick = () => { if (this._digit) { p.textContent = m.t; fim(); } };
    // medido pelo relógio (16 ms por letra): não atrasa mesmo quando o quadro cai
    this._digit = setInterval(() => {
      if (tok !== this._digitTok || !this.el('convLog')) { clearInterval(this._digit); this._digit = 0; return; }
      const k = Math.min(m.t.length, Math.floor((performance.now() - t0) / 16));
      p.textContent = m.t.slice(0, k);
      if (k >= m.t.length) fim();
    }, 16);
  }

  // Aplica uma fala do jogador: confiança, pontos, gafes, avanço de rodada, fim (ok, cortou, caiu)
  convEscolher(parada, o, instantaneo) {
    const st = this.state, c = this.convDe(parada), nv = NIVEIS[st.nivel] || NIVEIS.executivo;
    const rod = parada.conversa[c.r];
    const porPerg = { situacao: 1, problema: 0, implicacao: 2 }[rod.etapa];
    let dt = 0, pts = 0, gafe = false, cortou = false, ok = false;
    if (o.q === 'boa') {
      if (rod.etapa === 'proposta') { dt = 10; pts = 15; ok = true; }
      else {
        dt = rod.etapa === 'implicacao' ? 16 : 12; pts = 15;
        st.perg[parada.id] = st.perg[parada.id] || {};
        st.perg[parada.id][porPerg] = true;
      }
    } else if (o.q === 'morna') { dt = 2; pts = 5; }
    else if (o.q === 'ruim') { gafe = true; cortou = !!o.corta; dt = o.corta ? -30 : -15; pts = -Math.round(10 * nv.pesoErro); }
    else if (o.q === 'erro') { dt = -12; pts = -Math.round(6 * nv.pesoErro); }
    else if (o.q === 'isca') { dt = -8; pts = -Math.round(5 * nv.pesoErro); }
    else if (o.q === 'evid') { dt = 18; pts = 10; }
    c.conf = Math.max(0, Math.min(100, c.conf + dt));
    st.pontos = Math.max(0, st.pontos + pts);
    if (gafe) st.gafes++;
    if (gafe || o.q === 'erro' || o.q === 'isca') this.cb.playErr();
    else this.cb.playOk();

    const caiu = !cortou && c.conf <= 0;
    c.log.push({ q: 'voce', t: o.t });
    c.log.push({ q: 'pers', t: o.r, anim: !instantaneo && !cortou && !caiu, tremer: gafe });
    if (cortou) {
      c.log.push({ q: 'pers', t: parada.corta.replace(/^[^:]*:\s*/, ''), anim: !instantaneo });
      c.fim = 'cortou';
    } else if (caiu) {
      c.log.push({ q: 'pers', t: '“Volta depois, tô ocupado.”', anim: !instantaneo });
      c.fim = 'caiu';
    } else if (ok) c.fim = 'ok';
    else if (o.q === 'erro') c.usados.push(o.i);
    else c.r++;
    // pitch antes de ouvir (corte) e confiança zerada viram advertência do Valdemar
    if (cortou) this.cb.advertir('pitch_antes_de_ouvir');
    else if (caiu) this.cb.advertir('confianca_zerada');
    this.updateTopHUD();
  }

  // Modo demonstração: a conversa inteira pelo caminho bom, sem digitação
  convAutoDemo(parada) {
    const c = this.convDe(parada);
    let guarda = 0;
    while (!c.fim && guarda++ < 10) {
      const rod = parada.conversa[c.r];
      const i = rod.opcoes.findIndex(o => o.q === 'boa');
      this.convEscolher(parada, { ...rod.opcoes[i], i }, true);
    }
  }

  // Conexão com a frente certa: ops da parada; isca extra só no especialista
  opsConexao(parada) {
    const nv = NIVEIS[this.state.nivel] || NIVEIS.executivo;
    const ops = parada.op.slice();
    if (nv.isca) {
      const outra = PARADAS[(PARADAS.indexOf(parada) + 5) % PARADAS.length];
      const iscaN = outra.op.find(o => o[1] === 1)[0];
      if (!ops.some(o => o[0] === iscaN)) ops.push([iscaN, 0, `Essa frente existe e é boa, mas resolve a dor de ${outra.quem.split(',')[0]} (${outra.lugar}), não esta.`]);
    }
    parada._ops = ops;
    return ops;
  }

  // Frase de quem conecta sem perguntar: quatro variações, uma por parada e sorteada uma vez por sessão
  chuteFrase(parada) {
    const v = [
      'Conectar sem perguntar nada é chute. Funciona às vezes, igual na vida real.',
      'Sem pergunta, a conexão é palpite. Às vezes acerta, como em loteria.',
      'Ligar a frente sem ouvir a pessoa é aposta. Pode dar certo, mas não é método.',
      'Conectar sem perguntar nada é sorte. A usina não paga por sorte.'
    ];
    this._chutes = this._chutes || {};
    if (!this._chutes[parada.id]) this._chutes[parada.id] = v[Math.floor(Math.random() * v.length)];
    return this._chutes[parada.id];
  }

  renderFrentesSolved(parada) {
    let html = '';
    if (parada.perda) html += `<div class="levar"><small>Perda que isso evita</small>${esc(parada.perda.rotulo)}</div>`;
    parada.frentes.forEach(f => {
      html += `<div class="frente">
        <div class="cab"><b>${esc(f.n)}</b><span class="selo">${esc(f.p)}</span></div>
        <div class="chips">${f.c.map(c => `<span>${esc(c)}</span>`).join('')}</div>
      </div>`;
    });
    html += `<div class="levar"><small>Pergunta para levar ao cliente</small>${esc(parada.levar)}</div>`;
    return html;
  }

  renderCartao(parada) {
    const c = parada.cartao;
    if (!c) return '';
    return `<h3>Cartão do produto · ${esc(c.produto)}</h3>
      <p class="nota"><b>O que é:</b> ${esc(c.oque)}</p>
      <p class="nota"><b>Para quem:</b> ${esc(c.quem)}</p>
      <p class="nota"><b>Pergunta que abre a conversa:</b> ${esc(c.pergunta)}</p>
      <p class="nota"><b>Objeção típica:</b> ${esc(c.objecao)}</p>
      <p class="nota"><b>Resposta:</b> ${esc(c.resposta)}</p>`;
  }

  showPlatform() {
    const veu = this.el('veu');
    const folha = this.el('folha');
    veu.className = 'veu meio';
    veu.hidden = false;
    this.state.modalOpen = true;
    if (document.pointerLockElement) document.exitPointerLock?.();

    const ativas = this.frentesAgg.filter(x => x.list.some(fn => fn())).length;
    let html = `
      <div class="olho">Plataforma GAtec · Senior</div>
      <h2>Frentes em operação (${ativas}/${this.frentesAgg.length})</h2>
      <div class="grade">
    `;
    this.frentesAgg.forEach(item => {
      const on = item.list.some(fn => fn());
      html += `<div class="frente ${on ? '' : 'fechada'}">
        <div class="cab"><b>${esc(item.f.n)}</b><span class="selo ${on ? '' : 'off'}">${esc(item.f.p)}</span></div>
        <div class="chips">${item.f.c.slice(0, 6).map(c => `<span>${esc(c)}</span>`).join('')}</div>
      </div>`;
    });
    html += `</div><div class="linha-b" style="margin-top:16px"><button class="bt bt-s" id="btPlatMapa">Mapa ponta a ponta</button><button class="bt bt-s" id="btPlatCad">Caderno de campo</button><button class="bt bt-a" id="btPlatFechar">Fechar</button></div>`;
    folha.innerHTML = html;
    this.el('btPlatFechar').onclick = () => this.closeModal();
    this.el('btPlatMapa').onclick = () => this.showMapa(() => this.showPlatform());
    this.el('btPlatCad').onclick = () => this.showCaderno(() => this.showPlatform());
  }

  showPause() {
    const pv = this.el('pausaVeu');
    const pf = this.el('pausaFolha');
    pv.hidden = false;
    this.state.modalOpen = true;
    if (document.pointerLockElement) document.exitPointerLock?.();

    const cfg = this.state.cfg;
    pf.innerHTML = `
      <div class="olho">Pausa · ajustes</div>
      <h2>Um Dia de Safra</h2>
      <div class="ajuste"><span>Sensibilidade do olhar</span><input id="rSens" type="range" min="0.4" max="2" step="0.1" value="${cfg.sens}"></div>
      <div class="ajuste"><span id="lblFov">Campo de visão (${cfg.fov}°)</span><input id="rFov" type="range" min="60" max="90" step="2" value="${cfg.fov}"></div>
      <div class="ajuste"><span>Volume</span><input id="rVol" type="range" min="0" max="100" step="5" value="${Math.round(cfg.vol * 100)}"></div>
      <div class="ajuste"><span>Inverter eixo Y</span><input id="cInv" type="checkbox" ${cfg.invY ? 'checked' : ''}></div>
      <div class="ajuste"><span>Reduzir movimento</span><input id="cRed" type="checkbox" ${cfg.reduz ? 'checked' : ''}></div>
      <div class="ajuste"><span>Mostrar medição de desempenho</span><input id="cMed" type="checkbox" ${cfg.medir ? 'checked' : ''}></div>
      <label class="campo" style="margin-top:12px">Qualidade gráfica
        <div class="seg" id="segQualP">
          <button data-q="auto" class="${cfg.qualAuto ? 'on' : ''}">Auto</button>
          <button data-q="alta" class="${!cfg.qualAuto && cfg.qual === 'alta' ? 'on' : ''}">Alta</button>
          <button data-q="media" class="${!cfg.qualAuto && cfg.qual === 'media' ? 'on' : ''}">Média</button>
          <button data-q="baixa" class="${!cfg.qualAuto && cfg.qual === 'baixa' ? 'on' : ''}">Baixa</button>
        </div>
      </label>
      <p class="nota" style="margin-top:10px">Qualidade automática detectou: <b>${esc(cfg.det || '—')}</b>.</p>
      <div class="linha-b" style="margin-top:14px">
        <button class="bt bt-a" id="btVoltar">Continuar (Esc)</button>
        <button class="bt bt-s" id="btRelP">Relatório parcial</button>
      </div>
    `;

    this.el('rSens').oninput = e => { cfg.sens = Number(e.target.value); };
    this.el('rFov').oninput = e => {
      cfg.fov = Number(e.target.value);
      this.el('lblFov').textContent = `Campo de visão (${cfg.fov}°)`;
      this.cb.applyFov(cfg.fov);
    };
    this.el('rVol').oninput = e => { cfg.vol = Number(e.target.value) / 100; this.cb.updateAudio(); };
    this.el('cInv').onchange = e => { cfg.invY = e.target.checked; };
    this.el('cRed').onchange = e => { cfg.reduz = e.target.checked; };
    this.el('cMed').onchange = e => {
      cfg.medir = e.target.checked;
      this.el('medicao').hidden = !cfg.medir;
    };
    pf.querySelectorAll('#segQualP button').forEach(b => {
      b.onclick = () => {
        this.cb.setQuality(b.dataset.q);
        pf.querySelectorAll('#segQualP button').forEach(x => x.classList.toggle('on', x === b));
      };
    });
    this.el('btVoltar').onclick = () => this.closeModal();
    this.el('btRelP').onclick = () => { this.closeModal(); this.showReport(); };
  }

  // ===== Final: a ligação do diretor no viva-voz =====
  showCall(auto) {
    const veu = this.el('veu'), folha = this.el('folha');
    veu.className = 'veu meio'; veu.hidden = false; this.state.modalOpen = true;
    this._ligacaAtiva = true;
    document.body.classList.remove('falando');
    if (document.pointerLockElement) document.exitPointerLock?.();
    const st = this.state, nv = NIVEIS[st.nivel] || NIVEIS.executivo;
    const call = st.ligacao = { escolhas: [], obj: [], pontos: 0, caiu: false };
    const tempoTotal = st.nivel === 'trainee' ? 0 : st.nivel === 'executivo' ? 75 : 55;
    let t0 = performance.now(), timer = null;
    const barras = () => { if (!tempoTotal) return 4; const f = 1 - (performance.now() - t0) / 1000 / tempoTotal; return Math.max(0, Math.ceil(f * 4)); };
    const cab = () => `<div class="viva"><div class="sinal">${[1, 2, 3, 4].map(k => `<i class="${k <= barras() ? 'on' : ''}"></i>`).join('')}</div>
      <div><div class="olho">Viva-voz · chamada em andamento</div><h2 style="margin:4px 0 0">${esc(DIRETOR.quem)}</h2></div>
      ${tempoTotal ? `<b class="crono" id="crono"></b>` : ''}</div>`;
    const tick = () => {
      if (!tempoTotal) return;
      const rest = Math.max(0, tempoTotal - (performance.now() - t0) / 1000);
      const c = this.el('crono'); if (c) c.textContent = `${Math.ceil(rest)}s`;
      folha.querySelectorAll('.sinal i').forEach((el, k) => el.classList.toggle('on', k < barras()));
      if (rest <= 0) { clearInterval(timer); call.caiu = true; this.cb.playErr(); fim('A ligação caiu na serra. O Dr. Augusto vai retornar... algum dia.'); }
    };
    const fim = (msg) => {
      clearInterval(timer);
      this._ligacaAtiva = false;
      st.pontos += call.pontos; this.updateTopHUD();
      folha.innerHTML = cab() + `<div class="cena">${esc(msg)}</div>
        <p>${call.caiu ? 'Você somou' : 'A ligação rendeu'} <b>${call.pontos} pontos</b>.</p>
        <div class="linha-b"><button class="bt bt-a" id="btRel">Ver o relatório do dia</button></div>`;
      this.el('btRel').onclick = () => this.showReport();
    };
    // Passo 1: escolher as 3 dores que você leva ao diretor
    const resolvidas = PARADAS.filter(p => st.feitas[p.id]);
    const passo1 = () => {
      folha.innerHTML = cab() + `<div class="cena">${esc(DIRETOR.abre)}</div>
        <h3>Escolha as 3 dores que você leva para ele</h3>
        <p class="nota">As mais fortes são as que você confirmou com a pessoa certa, fazendo a pergunta certa.</p>
        ${resolvidas.map(p => `<button class="op" data-p="${p.id}"><b>${esc(p.lugar)} · ${esc(p.frentes.map(f => f.n).join(' + '))}</b><span>${esc(p.levar)}</span></button>`).join('')}
        <div class="linha-b"><button class="bt bt-a" id="btPitch" disabled>Falar com o diretor (0/3)</button></div>`;
      folha.querySelectorAll('[data-p]').forEach(b => b.onclick = () => {
        const id = b.dataset.p, k = call.escolhas.indexOf(id);
        if (k >= 0) call.escolhas.splice(k, 1); else if (call.escolhas.length < 3) call.escolhas.push(id);
        folha.querySelectorAll('[data-p]').forEach(x => x.classList.toggle('sim', call.escolhas.includes(x.dataset.p)));
        const bt = this.el('btPitch'); bt.disabled = call.escolhas.length !== 3; bt.textContent = `Falar com o diretor (${call.escolhas.length}/3)`;
      });
      this.el('btPitch').onclick = () => {
        let fortes = 0;
        call.escolhas.forEach(id => {
          const p = PARADAS.find(x => x.id === id), pd = st.perg[id] || {};
          const descobriu = p.pergs && Object.keys(pd).some(ix => p.pergs[ix][1] === 1);
          const evid = EVIDENCIAS.some(e => e.st === id && st.evid[e.id]);
          const v = 10 + (descobriu ? 15 : 0) + (evid ? 10 : 0);
          call.pontos += v; if (descobriu) fortes++;
        });
        call.fortes = fortes;
        this.cb.playOk();
        objecao(0, fortes);
      };
    };
    const reacao = f => f === 3 ? '“Hum. Isso eu reconheço. A Paula reclama disso toda semana.”' : f === 2 ? '“Faz sentido. Uma delas eu nem sabia.”' : '“Isso é bonito, mas é o que todo executivo fala.”';
    const objecao = (k, fortes) => {
      if (k >= nv.objecoes) {
        const ok = call.obj.filter(Boolean).length;
        const venceu = fortes >= 2 && ok >= Math.ceil(nv.objecoes / 2);
        call.venceu = venceu;
        if (venceu) call.pontos += 40;
        fim((k === 0 ? reacao(fortes) + ' ' : '') + (venceu ? '“Fechado. Terça às 8h, aqui na usina. E traz o tablet, quero que o Seu Tião veja.”' : '“Manda por e-mail que eu vejo.” (Spoiler: ele não vai ver.)'));
        return;
      }
      const o = DIRETOR.objecoes[k];
      const ord = [0, 1, 2].sort((a, b) => ((k * 7 + a * 3) % 5) - ((k * 7 + b * 3) % 5));
      folha.innerHTML = cab() + `<div class="cena">${k === 0 ? esc(reacao(fortes)) + '<br><br>' : ''}${esc(o.q)}</div>
        <h3>Sua resposta</h3>${ord.map(ix => `<button class="op" data-r="${ix}"><b>${esc(o.r[ix][0])}</b></button>`).join('')}`;
      folha.querySelectorAll('[data-r]').forEach(b => b.onclick = e => {
        if (e.detail > 1) return; // segundo clique do duplo: não responde a próxima objeção sem querer
        const ok = o.r[Number(b.dataset.r)][1] === 1;
        call.obj.push(ok); if (ok) { call.pontos += 25; this.cb.playOk(); } else this.cb.playErr();
        objecao(k + 1, fortes);
      });
    };
    passo1();
    if (tempoTotal && !auto) timer = setInterval(tick, 250);
    if (auto) {
      // modo apresentação: escolhe as três dores e responde certo, devagar o bastante para a sala ler
      const passo = (fn, ms) => new Promise(r => setTimeout(() => { fn(); r(); }, ms));
      (async () => {
        for (const id of ['plan', 'auto', 'custo']) await passo(() => folha.querySelector(`[data-p="${id}"]`)?.click(), 900);
        await passo(() => this.el('btPitch')?.click(), 1200);
        for (let k = 0; k < nv.objecoes; k++) {
          const certa = DIRETOR.objecoes[k].r.find(r => r[1] === 1)[0];
          await passo(() => [...folha.querySelectorAll('[data-r]')].find(x => x.textContent === certa)?.click(), 3200);
        }
      })();
    }
  }

  // Mapa ponta a ponta: fases Senior + GAtec no fluxo oficial; cada fase acende com a parada concluída.
  // voltar (opcional): reabre a tela de onde o mapa foi aberto; sem ela, o botão só fecha o modal.
  showMapa(voltar) {
    const veu = this.el('veu');
    const folha = this.el('folha');
    veu.className = 'veu meio mapa';
    veu.hidden = false;
    this.state.modalOpen = true;
    if (document.pointerLockElement) document.exitPointerLock?.();

    const feitas = this.state.feitas;
    const fases = PONTA_A_PONTA.map(f => {
      const pars = f.paradas.map(id => PARADAS.find(p => p.id === id)).filter(Boolean);
      const acesa = pars.some(p => feitas[p.id]);
      const falta = pars.find(p => !feitas[p.id]);
      return { f, acesa, dica: falta ? falta.lugar : (pars[0] ? pars[0].lugar : '') };
    });
    const conectadas = fases.filter(x => x.acesa).length;
    const agn = [...new Set(PONTA_A_PONTA.flatMap(f => f.agnosticas || []))];

    // cada célula cai numa linha (1 fase, 2 GAtec, 3 conexão, 4 ERP) e numa coluna (2 a 7); order mantém a leitura por fase no celular
    const cel = (cls, col, row, ord, html) => `<div class="${cls}" style="grid-column:${col};grid-row:${row};order:${ord}">${html}</div>`;
    let grade = cel('raia g', 1, 2, 0, esc('GAtec · operação')) + cel('raia e', 1, 4, 0, esc('Senior ERP · gestão'));
    fases.forEach(({ f, acesa, dica }, i) => {
      const col = i + 2, o = i * 4, off = acesa ? '' : ' off';
      grade += cel('fase-h', col, 1, o,
        `<b>${esc(f.nome)}</b><span class="st ${acesa ? 'ok' : ''}">${acesa ? 'Conectada' : `Visite ${esc(dica)} para acender`}</span>`);
      grade += cel(`ativ g${off}`, col, 2, o + 1,
        `<small class="tag">GAtec · operação</small>${f.gatec.map(a => `<span>${esc(a)}</span>`).join('')}`);
      grade += cel(`conn${off}`, col, 3, o + 2, `<span>${esc(f.conexao)}</span>`);
      grade += cel(`ativ e${off}`, col, 4, o + 3,
        `<small class="tag">Senior ERP · gestão</small>${f.erp.map(a => `<span>${esc(a)}</span>`).join('')}`);
    });

    folha.innerHTML = `
      <div class="olho">Visão de ponta a ponta · Senior + GAtec</div>
      <div class="mapa-top"><h2>Do campo ao balanço: Senior + GAtec de ponta a ponta</h2><p class="mapa-cont"><b>${conectadas} de ${fases.length} fases conectadas</b></p><button class="bt bt-a" id="btMapaFechar">Fechar</button></div>
      <div class="mapa">${grade}</div>
      <div class="mapa-agn"><small>Soluções Senior para qualquer segmento</small>${agn.map(a => `<span>${esc(a)}</span>`).join('')}</div>
    `;
    this.el('btMapaFechar').onclick = () => (voltar ? voltar() : this.closeModal());
  }

  // ===== Caderno de Campo: verbetes destravados (com "Onde a Senior entra") e pistas dos travados =====
  // voltar (opcional): reabre a tela de onde o Caderno foi aberto (Plataforma). Esc e Fechar voltam para lá.
  cadernoAberto() { return !!this._cad; }
  fechaCaderno() {
    const v = this._cad && this._cad.voltar;
    this.closeModal();
    if (v) v();
  }
  showCaderno(voltar) {
    const veu = this.el('veu');
    const folha = this.el('folha');
    const st = this.state;
    veu.className = 'veu meio cad';
    veu.hidden = false;
    st.modalOpen = true;
    if (document.pointerLockElement) document.exitPointerLock?.();
    this._cad = { voltar, cat: 'Todos', busca: '' };
    const n = Object.keys(st.codex || {}).length;
    folha.innerHTML = `
      <div class="cad-cab">
        <div><div class="olho">Usina Horizonte · o que se aprende andando</div><h2>Caderno de Campo</h2></div>
        <div class="cad-prog"><b id="cadCont">${n} de ${CODEX.length}</b><div class="faixa"><i id="cadBarra" style="width:${Math.round((n / CODEX.length) * 100)}%"></i></div></div>
        <button class="bt bt-a" id="cadFechar">Fechar</button>
      </div>
      <div class="cad-filtros" id="cadChips" role="group" aria-label="Filtrar por categoria">${CAD_CATS.map(c => `<button type="button" class="cad-chip${c === 'Todos' ? ' on' : ''}" data-cat="${c}" aria-pressed="${c === 'Todos'}">${c}</button>`).join('')}</div>
      <input type="search" id="cadBusca" class="cad-busca" placeholder="Buscar nos verbetes destravados" aria-label="Buscar no Caderno de Campo" autocomplete="off">
      <div class="cad-lista" id="cadLista"></div>`;
    this.el('cadFechar').onclick = () => this.fechaCaderno();
    this.el('cadChips').onclick = e => {
      const b = e.target.closest('.cad-chip'); if (!b || !this._cad) return;
      this._cad.cat = b.dataset.cat;
      this.el('cadChips').querySelectorAll('.cad-chip').forEach(x => { const on = x === b; x.classList.toggle('on', on); x.setAttribute('aria-pressed', String(on)); });
      this._cadLista();
    };
    this.el('cadBusca').oninput = e => { if (this._cad) { this._cad.busca = e.target.value; this._cadLista(); } };
    this._cadLista();
  }
  // lista: destravados primeiro (os "novo" no topo); travados depois, só com "???" e a pista. Busca não revela travados.
  _cadLista() {
    const st = this.state, cad = this._cad, box = this.el('cadLista');
    if (!cad || !box) return;
    const n = Object.keys(st.codex || {}).length;
    this.el('cadCont').textContent = `${n} de ${CODEX.length}`;
    this.el('cadBarra').style.width = `${Math.round((n / CODEX.length) * 100)}%`;
    const sem = s => String(s).normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();
    const q = sem(cad.busca.trim());
    const pool = CODEX.filter(c => cad.cat === 'Todos' || c.categoria === cad.cat);
    const ok = pool.filter(c => st.codex[c.id] && (!q || sem(`${c.titulo} ${c.texto} ${c.senior || ''}`).includes(q)));
    ok.sort((a, b) => (!!st.codexNovos[b.id] - !!st.codexNovos[a.id]));
    const travados = q ? [] : pool.filter(c => !st.codex[c.id]);
    const cardOk = c => {
      const novo = !!st.codexNovos[c.id];
      return `<article class="cad-card${novo ? ' novo' : ''}">
        <div class="cad-meta"><small>${esc(c.categoria)}</small>${novo ? '<span class="cad-selo">novo</span>' : ''}</div>
        <h3>${esc(c.titulo)}</h3>
        <p>${esc(c.texto)}</p>
        ${c.senior ? `<p class="cad-senior"><b>Onde a Senior entra:</b> ${esc(c.senior)}</p>` : ''}
      </article>`;
    };
    const cardTr = c => `<article class="cad-card travado">
        <div class="cad-meta"><small>${esc(c.categoria)}</small></div>
        <h3>???</h3>
        <p class="cad-pista"><b>Como destravar:</b> ${esc(cadPista(c))}.</p>
      </article>`;
    const html = [...ok.map(cardOk), ...travados.map(cardTr)].join('');
    box.innerHTML = html || '<p class="nota">Nenhum verbete destravado com esse termo. Tente outra palavra ou outra categoria.</p>';
    box.scrollTop = 0;
  }

  showReport() {
    const veu = this.el('veu');
    const folha = this.el('folha');
    veu.className = 'veu meio';
    veu.hidden = false;
    this.state.modalOpen = true;
    if (document.pointerLockElement) document.exitPointerLock?.();

    const st = this.state;
    const obsPct = Math.round((Object.keys(st.evid).length / EVIDENCIAS.length) * 100);
    const totalPerg = PARADAS.reduce((acc, p) => acc + (p.pergs ? p.pergs.length : 0), 0);
    const pergCount = Object.values(st.perg).reduce((acc, m) => acc + Object.keys(m).length, 0);
    const pergPct = totalPerg ? Math.round((pergCount / totalPerg) * 100) : 100;
    const conCount = Object.keys(st.feitas).length;
    const conPct = Math.round((conCount / PARADAS.length) * 100);
    const lowest = [['Observar', obsPct], ['Perguntar', pergPct], ['Conectar', conPct]].sort((a, b) => a[1] - b[1])[0][0];
    const kit = PARADAS.filter(p => st.feitas[p.id] && p.cartao);
    const perdas = PARADAS.filter(p => st.feitas[p.id] && p.perda);

    // diagnóstico e pitch: dores levadas na ligação; sem ligação, as 3 primeiras paradas concluídas
    const lista = a => a.length <= 1 ? (a[0] || '') : `${a.slice(0, -1).join(', ')} e ${a[a.length - 1]}`;
    const idsDiag = st.ligacao && st.ligacao.escolhas && st.ligacao.escolhas.length
      ? st.ligacao.escolhas
      : PARADAS.filter(p => st.feitas[p.id]).slice(0, 3).map(p => p.id);
    const diagParadas = idsDiag.map(id => PARADAS.find(p => p.id === id)).filter(p => p && p.cartao).slice(0, 3);
    const diagTxt = diagParadas.length
      ? `A margem da Horizonte escapa em ${lista(diagParadas.map(p => p.lugar))}. O caminho: ${lista(diagParadas.map(p => p.cartao.produto))}, com o ERP no centro.`
      : 'Ainda não há paradas concluídas para montar o diagnóstico.';
    // uma frase por parada: dor (primeira frase da desculpa) -> produto -> resultado (primeira oração do feito)
    const dorFrase = p => { const d = p.desculpa.replace(/[“”"]/g, '').trim(); const m = d.match(/^.*?[.!?](?=\s|$)/); const s = (m ? m[0] : d).trim(); return /[.!?]$/.test(s) ? s : `${s}.`; };
    const resultado = p => { const r = p.feito.split(';')[0].replace(/[.!?]+$/, '').trim(); return r.charAt(0).toLowerCase() + r.slice(1); };
    const pitchFrases = diagParadas.map(p => `Na ${p.lugar.toLowerCase()}, a margem escapa sem ninguém ver. Com ${p.cartao.produto}: ${resultado(p)}.`);
    const pitchTxt = pitchFrases.length ? pitchFrases.join(' ') : 'Ainda não há paradas concluídas para montar o pitch.';

    const rows = PARADAS.map(p => {
      const ok = st.feitas[p.id];
      return `<tr>
        <td>${esc(p.hora)}</td>
        <td><b>${esc(p.lugar)}</b><br><span class="nota">${esc(p.quem)}</span></td>
        <td>${ok ? esc(p.frentes.map(f => `${f.n} (${f.p})`).join(' + ')) : '<span class="nota">Pendente</span>'}</td>
      </tr>`;
    }).join('');

    // Caderno de Campo: quantos verbetes e as 3 primeiras pistas do que ficou para trás
    const cadN = Object.keys(st.codex || {}).length;
    const cadFaltam = CODEX.filter(c => !st.codex[c.id]).slice(0, 3).map(cadPista).join('; ');
    const resumoTxt = `Um Dia de Safra · ${st.nome} · ${st.pontos} pts · nível ${(NIVEIS[st.nivel] || NIVEIS.executivo).n}\n` +
      `Competências: Observar ${obsPct}% · Perguntar ${pergPct}% · Conectar ${conPct}%\n` +
      PARADAS.map(p => `${p.hora} ${p.lugar}: ${st.feitas[p.id] ? p.feito : 'Pendente'} — ${p.frentes.map(f => `${f.n} (${f.p})`).join(' + ')}`).join('\n');

    folha.innerHTML = `
      <div class="olho">Relatório do dia · Usina Horizonte</div>
      <h2>${esc(st.nome)} — ${st.pontos} pontos</h2>
      <h3>Seu diagnóstico da Horizonte</h3>
      <p>${esc(diagTxt)}</p>
      <div class="linha-b" style="margin:4px 0 6px"><button class="bt bt-a" id="btMapaRel">Ver a operação de ponta a ponta</button></div>
      <h3>Onde a margem escapou</h3>
      ${perdas.map(p => `<p class="nota"><b>${esc(p.perda.rotulo)}</b> (${esc(p.lugar)}): ${esc(p.perda.frase)}</p>`).join('') || '<p class="nota">Nenhuma parada concluída ainda.</p>'}
      <h3>Seu pitch de 30 segundos</h3>
      <p class="nota" id="pitchTxt" style="color:var(--claro)">${esc(pitchTxt)}</p>
      <div class="linha-b" style="margin-top:8px"><button class="bt bt-c" id="cpPitch">Copiar pitch</button></div>
      <table class="dia">${rows}</table>
      <h3>Notas por competência</h3>
      ${[['Observar', obsPct], ['Perguntar', pergPct], ['Conectar', conPct]].map(([lbl, pct]) => `
        <div class="barra"><div class="lbl"><span>${lbl}</span><span>${pct}%</span></div><div class="faixa"><i style="width:${Math.max(4, pct)}%"></i></div></div>
      `).join('')}
      <p class="nota" style="margin-top:8px">O relatório diz qual competência treinar: <b>${lowest}</b>. Nível: <b>${esc((NIVEIS[st.nivel] || NIVEIS.executivo).n)}</b>.</p>
      ${st.ligacao ? `<h3>A ligação do diretor</h3><p class="nota">${st.ligacao.caiu ? 'A ligação caiu antes de você terminar.' : st.ligacao.venceu ? 'Reunião marcada: terça às 8h, na usina.' : 'Ele pediu para mandar por e-mail. Ninguém volta de um “manda por e-mail”.'} ${st.ligacao.fortes != null ? `Dores fortes levadas: ${st.ligacao.fortes} de 3.` : ''}</p>` : ''}
      <h3>Top 5 desculpas da safra</h3>
      ${Object.values(st.desculpas).slice(-5).map((d, k) => `<p class="nota"><b>${k + 1}.</b> ${esc(d)}</p>`).join('') || '<p class="nota">Você não conversou com ninguém. A usina agradece o silêncio.</p>'}
      <p class="nota">Na próxima visita real, quando ouvir uma dessas, você já sabe qual pergunta fazer.</p>
      <p class="nota">Segredos da usina: <b>${Object.keys(st.eggs || {}).length} de ${EASTER.length}</b>${Object.keys(st.eggs || {}).length === EASTER.length ? '. Você achou tudo, até a capivara.' : '. Tem coisa escondida por aí (dica: alguém perdeu um cartão, alguém perdeu uma pasta e alguém nunca sai do gramado da sede).'}</p>
      <p class="nota">Caderno de Campo: <b>${cadN} de ${CODEX.length}</b>${cadN < CODEX.length ? `. Faltou explorar: ${esc(cadFaltam)}.` : '. Nenhum verbete ficou para trás.'}</p>
      <p class="nota">Gafes de executivo apressado: <b>${st.gafes}</b>${st.gafes ? ' (cada uma espantou alguém da conversa)' : ' (nenhuma, parabéns pela paciência)'}.</p>
      ${st.cadeia.armado || st.cadeia.visto ? `<p class="nota">Efeito em cadeia: a preventiva ignorada na Oficina parou a colhedora na Frente de colheita${st.cadeia.visto ? ' — você viu ao voltar lá' : ''}. Quem cuida da frota no dia, colhe no dia.</p>` : ''}
      ${kit.length ? `<h3>Seu kit de visita</h3>${kit.map(p => `<p class="nota"><b>${esc(p.cartao.produto)}:</b> ${esc(p.cartao.pergunta)}</p>`).join('')}` : ''}
      <h3>Perguntas para levar ao cliente</h3>
      ${PARADAS.map(p => `<p class="nota"><b>${esc(p.lugar)}:</b> ${esc(p.levar)}</p>`).join('')}
      <div class="linha-b" style="margin-top:14px">
        <button class="bt bt-a" id="cp">Copiar resumo</button>
        <button class="bt bt-c" id="de">Refazer o dia</button>
        <button class="bt bt-c" id="ex">Continuar explorando</button>
      </div>
      <p class="nota" style="font-size:11px;margin-top:14px">Personagens 3D: Microsoft Rocketbox Avatar Library (MIT).</p>
      <textarea id="copia" hidden readonly>${esc(resumoTxt)}</textarea>
    `;

    this.el('btMapaRel').onclick = () => this.showMapa(() => this.showReport());
    this.el('cpPitch').onclick = async () => {
      const b = this.el('cpPitch');
      try {
        await navigator.clipboard.writeText(pitchTxt);
        b.textContent = 'Copiado';
      } catch (e) {
        this.notify('Não consegui copiar. Selecione o texto do pitch.');
      }
    };
    this.el('cp').onclick = () => {
      const ta = this.el('copia');
      ta.hidden = false;
      ta.select();
      navigator.clipboard?.writeText(resumoTxt).catch(() => {});
      this.notify('Resumo copiado');
    };
    this.el('de').onclick = () => location.reload();
    this.el('ex').onclick = () => this.closeModal();
  }
}


