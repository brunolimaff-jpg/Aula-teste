// === data/safraData.js ===
// Dados preservados integralmente de Um Dia de Safra · v5.html
// Roteiro v7 — "A safra que não fecha". Tom leve e corporativo: a graça está nas situações da operação, nunca no cliente.
// Formato de pergs: [texto, tipo, resposta] — tipo 1 = descoberta (a boa), 0 = neutra, 2 = empurrou produto cedo demais.
// A pergunta de índice 0 é sempre a de descoberta (o modo demonstração usa a primeira); a tela embaralha a ordem.
const ATOS = [
  { n: 1, t: 'Amanhecer · O campo', s: 'A Usina Horizonte perdeu margem na safra passada. Ninguém sabe onde. O problema nasce aqui, no talhão.' },
  { n: 2, t: 'Dia cheio · A operação', s: 'O problema cresce na operação. Cada parada tem um custo que ninguém soma.' },
  { n: 3, t: 'Fim de tarde · A gestão', s: 'Aqui o problema fica invisível. O diretor quer um número, e cada área tem o seu.' }
];
const PARADAS = [
{id:"plan",ato:1,hora:"05:30",lugar:"Sede",x:-96,lado:-1,quem:"Helena, gerente agrícola",
 cena:"Bom dia! Café? A safra começa hoje e o plano está... ali no quadro. E na planilha. E um pedaço no bloquinho. O diretor quer o orçamento até o meio-dia. Plano que não acompanha o campo é margem que a usina perde sem perceber.",
 desculpa:"“O plano está no quadro. A versão certa é a de caneta azul.”",
 pergs:[["Quando o campo muda, quem atualiza o plano, e em quantos lugares?",1,"Helena ri sem graça: “Eu. No quadro, na planilha e no bloquinho. Se eu tirar férias, a safra tira junto.”"],
  ["Quantos hectares vocês vão reformar este ano, e quem decide a área?",0,"Helena: “Uns 1.800. Ou 2.000. Depende de qual planilha você abrir.”"],
  ["Já pensou em colocar tudo numa plataforma integrada de última geração?",2,"Helena olha o celular: “Opa, o diretor está ligando...” e sai andando sem ligação nenhuma."]],
 op:[["Planejamento",1,""],["Custos gerenciais",0,"Custos apura o que já aconteceu. A Helena ainda está decidindo o que vai acontecer."],["Comercialização",0,"Comercialização cuida da venda. O dia ainda nem saiu da sede."]],
 frentes:[{n:"Planejamento",p:"SimpleFarm",c:["Plantio e reforma","Colheita","Orçamento","Recursos"]}],
 levar:"Onde vive o plano da safra hoje? Quem atualiza quando o campo muda?",
 feito:"Plano de plantio, reforma, colheita, orçamento e recursos num lugar só, atualizado pelo campo.",
 roteiro:[["Você","Onde está o plano da safra, Helena?"],["Helena","Tá no quadro. Na planilha. E um pedaço no bloquinho."],["Você","Qual deles está atualizado?"],["Helena","Ah, o certo é o de caneta azul. Vai ao talhão 12 ver o Caio, ele tem uma mancha para mostrar."]],
 aprende:"O plano de safra define o que será plantado, reformado e colhido, e quanto cada etapa pode custar.",perda:{rotulo:"Plano que não acompanha o campo",frase:"Plano velho manda a frente de colheita para o talhão errado."},corta:"Helena: “Plataforma? Antes me acha a caneta azul.”",abre:"Helena: “Essa é a pergunta. Ninguém me fez essa ainda.”",cartao:{produto:"SimpleFarm (planejamento)",oque:"Plataforma que unifica a gestão agroindustrial, do plano de cultivo ao campo.",quem:"Gerente agrícola, responsável pelo plano de cultivo.",pergunta:"Onde vive hoje o plano de cultivo, e quem o atualiza quando o campo muda?",objecao:"Já controlo a safra em planilha.",resposta:"Pode manter a planilha. O ganho é o plano se atualizar com o que o campo registra."}},
{id:"geo",ato:1,hora:"07:00",lugar:"Talhão 12",x:-72,lado:1,quem:"Caio, agrônomo",
 cena:"Tá vendo aquela mancha amarela? O satélite viu ontem. Eu vi hoje. A aplicação vai sair... quando o e-mail for aprovado. Trouxe repelente? Cada dia de praga sem resposta é tonelada que a usina não vai moer.",
 desculpa:"“O satélite aponta. Quem decide é o meu olho e um e-mail com três aprovações.”",
 pergs:[["Quanto tempo passa entre ver a mancha no mapa e o pulverizador chegar nela?",1,"Caio: “Num dia bom, um dia. Num dia normal, a praga ganha de mim por dois a zero.”"],
  ["Essa imagem de satélite é de qual dia, e de qual fornecedor vocês compram?",0,"Caio: “De ontem. A praga, infelizmente, é de hoje.”"],
  ["Nosso módulo de mapas faz isso sozinho, quer ver uma demo agora?",2,"Caio coloca o fone de ouvido: “Desculpa, tá ventando muito aqui, não ouvi nada.”"]],
 op:[["Geoespacial e Controle de pragas",1,""],["Gestão automotiva",0,"Gestão automotiva cuida da frota. O problema do Caio está na lavoura."],["Armazéns e pátios",0,"Armazéns e pátios entram depois da indústria. Ainda estamos no campo."]],
 frentes:[{n:"Geoespacial",p:"Mapfy",c:["Web e mobile","Uso offline"]},{n:"Controle de pragas",p:"Shield",c:["Menos infestação","Uso racional de insumos","Manejo sustentável","Decisão mais rápida"]}],
 levar:"Quanto tempo passa entre ver o problema no talhão e agir? Como vocês decidem onde aplicar?",
 feito:"Mancha no mapa, praga confirmada e aplicação dirigida no mesmo dia.",
 roteiro:[["Você","Essa mancha amarela já tem aplicação marcada?"],["Caio","Marcada, sim. Aprovada, ainda não. Falta o e-mail."],["Você","E quanto tempo leva do satélite até o pulverizador?"],["Caio","Num dia bom, um dia. Num dia normal, a praga ganha. Fala com a Marta: a frente dela precisa dar passagem para a aplicação."]],
 aprende:"Talhão é a menor área de lavoura com manejo próprio. A aplicação dirigida cobre só a mancha, e não o campo inteiro.",perda:{rotulo:"Praga sem resposta",frase:"Cada dia de praga sem aplicação é cana que o campo perde antes da moagem."},corta:"Caio: “Demo? Eu nem terminei de olhar a mancha.”",abre:"Caio: “Agora você olhou para a praga, e não para o slide.”",cartao:{produto:"Shield e Mapfy",oque:"Manejo de pragas com dados, IA e geoprocessamento, ligado ao mapa dos talhões.",quem:"Agrônomo e gestor de fitossanidade.",pergunta:"Como a decisão de aplicar é tomada hoje: pelo olho, pelo calendário ou pelo mapa?",objecao:"Satélite não tem resolução para lavoura.",resposta:"Vale confirmar a resolução e a frequência das imagens antes de confiar nelas."}},
{id:"agri",ato:1,hora:"08:30",lugar:"Frente de colheita",x:-48,lado:-1,quem:"Marta, encarregada de frente",
 cena:"Colhedora rodando, transbordo enchendo, e eu anotando tudo nesta prancheta. A digitadora lança à noite. Se ela pegar gripe, a safra de terça só existe na quinta. Apontamento que chega dois dias depois não salva a colheita de ontem.",
 desculpa:"“Se a digitadora pegar gripe, a colheita de terça só existe na quinta.”",
 pergs:[["Como o apontamento da frente chega ao controle da safra, e em quanto tempo?",1,"Marta: “Papel, carro, sede, digitadora. Dois dias, se a estrada estiver boa.”"],
  ["Quantos transbordos você tem rodando agora nessa frente de colheita?",0,"Marta: “Três. Quantos deveria ter? Pergunta difícil pra segunda-feira.”"],
  ["Com a nossa solução você nunca mais vai precisar de prancheta!",2,"Marta abraça a prancheta: “Essa prancheta está comigo há onze safras, moço.”"]],
 op:[["Gestão agrícola",1,""],["Processo industrial",0,"Processo industrial começa quando a cana chega à moenda. A Marta está no talhão."],["Originação",0,"Originação trata dos contratos com fornecedores. A Marta fala da operação no campo."]],
 frentes:[{n:"Gestão agrícola",p:"SimpleFarm",c:["Pesagem e classificação de matéria-prima","Plantio","Tratos","Colheita","Pragas e doenças","Fornecedores","Terceiros","Irrigação","Custos","Mapas","Rurícolas","Máquinas e equipamentos","Fertirrigação"]}],
 levar:"Como o que acontece no campo chega ao controle da safra? No mesmo dia?",
 feito:"Frente apontando no mesmo dia; cana pesada batendo com o que saiu do talhão.",
 roteiro:[["Você","O apontamento da colheita já chegou ao sistema?"],["Marta","Chega na quinta. A colheita foi na terça."],["Você","E por que demora tanto?"],["Marta","Prancheta, sinal fraco e onze safras de costume. O trator do transbordo foi para a oficina do Seu Tião e não volta."]],
 aprende:"Na colheita, o transbordo recebe a cana da colhedora e leva ao caminhão. O apontamento registra cada carga por talhão e turno.",perda:{rotulo:"Cana que fica no campo",frase:"Colhedora que deixa cana inteira no talhão é perda que ninguém soma no dia."},corta:"Marta: “Pode mostrar. A colhedora não espera a sua apresentação.”",abre:"Marta: “Essa pergunta eu entendi. Ninguém me perguntou isso antes.”",cartao:{produto:"SimpleFarm e MobAgro",oque:"Apontamento de campo no Android, que sincroniza depois de registrado.",quem:"Encarregado de frente e agrônomo de campo.",pergunta:"Se o celular fica sem sinal na lavoura, o apontamento se perde ou espera?",objecao:"Nosso pessoal não usa celular para trabalho.",resposta:"Escolha a tarefa que mais sofre com o papel e prove o ganho com o encarregado."}},
{id:"auto",ato:2,hora:"10:00",lugar:"Oficina",x:-24,lado:1,quem:"Seu Tião, líder de manutenção",
 cena:"Preventiva? Preventiva é quando quebra, né? Brincadeira... A ordem está ali, pregada na parede há dez dias. O abastecimento eu anoto no caderno. Caderno não trava, moço. Motor novo? Abro a ordem de serviço. Se a peça estiver aqui, sai do estoque. Se não estiver, vira pedido no ERP, ou o motor vai para serviço de terceiro. Trator quebrado na safra é frente de colheita esperando, e a conta só chega no fim do ano.",
 desculpa:"“Caderno não trava, moço.”",
 pergs:[["Seu Tião, quando foi a última preventiva desse trator?",1,"Seu Tião aponta a parede: “Venceu semana passada. Mas ele está bom, só faz um barulhinho... desde março.”"],
  ["Quanto custa uma hora dessa máquina parada aqui no meio da safra?",0,"Seu Tião: “Caro. O número exato é com a Paula, lá da controladoria. Ela tem uma planilha só pra isso.”"],
  ["O senhor sabia que dá pra trocar esse caderno por um sistema moderno?",2,"Seu Tião fecha o caderno devagar: “Moço, esse caderno sobreviveu a três sistemas modernos.”"]],
 op:[["Gestão automotiva",1,""],["Manutenção industrial",0,"Quase. Manutenção industrial cuida da planta. Trator, colhedora e caminhão são frota."],["Automação",0,"Automação envia os dados das máquinas. Quem planeja preventiva, pneus e abastecimento é outra frente."]],
 frentes:[{n:"Gestão automotiva",p:"SimpleFarm",c:["Planejamento","Preventiva","Corretiva","Mecânicos","Agregados","Serviços externos","Documentos","Custos","Abastecimento","Oficina"]}],
 levar:"Quando uma máquina quebra, de onde vem a peça: do estoque, de compra no ERP ou de serviço de terceiro? Quem enxerga o custo?",
 feito:"Ordem de serviço aberta, peça do estoque ou compra no ERP, e custo da máquina registrado.",
 roteiro:[["Você","Seu Tião, cadê a ficha do trator?"],["Seu Tião","Tá aqui... não, isso é a lista do churrasco."],["Você","E a preventiva, venceu quando?"],["Seu Tião","Semana passada. Ele só faz um barulhinho. Vai avisar o Rui que o caminhão de cana atrasou por causa dele."]],
 aprende:"A ordem de serviço (OS) abre cada reparo. Se a manutenção for interna, a peça sai do estoque ou vira solicitação de compra no ERP. Se não for, a máquina segue para manutenção externa, como serviço de terceiro. A manutenção automotiva e o ERP trocam estoque, lançamentos e demais itens da oficina.",perda:{rotulo:"Máquina parada",frase:"Trator quebrado na safra é frente de colheita esperando."},corta:"Seu Tião: “Moço, primeiro me ajuda a achar a ficha.”",abre:"Seu Tião: “Essa eu sei de cabeça. O barulho começou em março.”",cartao:{produto:"Manutenção automotiva (GAtec) e ERP",oque:"Abre a ordem de serviço do reparo e liga estoque, compras e serviço de terceiro ao ERP, com o custo de cada máquina.",quem:"Líder de manutenção e controller.",pergunta:"Quando uma máquina quebra, a peça sai do estoque, vem de compra ou vai para serviço de terceiro?",objecao:"Já temos ERP. Para que outro sistema?",resposta:"A gestão continua no ERP. A ordem de serviço do campo ganha casa própria e chega ao ERP com estoque e custo."}},
{id:"orig",ato:2,hora:"11:30",lugar:"Balança",x:0,lado:-1,quem:"Rui, analista de balança",
 cena:"Está vendo essa fila de caminhão? Cada um tem contrato, serviço e pagamento por trás. Eu confiro na pasta. A pasta azul. A pasta azul sumiu. Pagamento sem contrato achado é margem que sai pela porta da balança.",
 desculpa:"“Está tudo na pasta azul. A pasta azul sumiu.”",
 pergs:[["Quando um fornecedor reclama do pagamento, quanto tempo você leva para achar o contrato?",1,"Rui: “Depende. Se a pasta azul aparecer, meia hora. Se não, uma tarde e um pedido de desculpas.”"],
  ["Quantos fornecedores parceiros entregam cana para a usina hoje em dia?",0,"Rui: “Uns oitenta. Ou noventa, contando o cunhado do Seu Tião.”"],
  ["Nossa plataforma acaba com essa fila em uma semana, garanto!",2,"Rui olha a fila, olha você: “Moço, essa fila existe desde antes de mim. Respeita a fila.”"]],
 op:[["Balança e recebimento",1,""],["Gestão agrícola",0,"Gestão agrícola fica no campo. A balança começa quando a cana chega ao portão da usina."],["Armazéns e pátios",0,"Armazéns e pátios guardam produto pronto. O Rui pesa a cana que acabou de chegar."]],
 frentes:[{n:"Balança",p:"SimpleFarm",c:["Pesagem de entrada e saída","Análise da cana","Central de processamento","Monitor de integração"]},{n:"Fila de pátio",p:"Operis YMS",c:["Agendamento","Check-in","Painel de chamada","Checklist do motorista"]}],
 levar:"Como vocês controlam contrato, entrega e pagamento de fornecedores e parceiros?",
 feito:"Contrato, serviço e pagamento amarrados a cada carga. A pasta azul pode descansar.",
 roteiro:[["Você","Rui, cadê a pasta azul com o contrato?"],["Rui","Tá aqui... não, isso é a pasta do cunhado do Seu Tião."],["Você","Quanto tempo leva para achar um contrato?"],["Rui","Se a pasta aparecer, meia hora. Se não, uma tarde. E a cana que chegou hoje já está subindo para a moenda da Sílvia."]],
 aprende:"Todo caminhão pesa na entrada e na saída. A diferença é a carga, e é ela que vira pagamento ao fornecedor (o acerto de contas).",perda:{rotulo:"Pagamento sem contrato",frase:"Pagamento sem contrato achado é dinheiro que sai pela balança sem conta."},corta:"Rui: “Sistema novo? Primeiro acha a pasta azul, moço.”",abre:"Rui: “Enfim alguém pergunta da pasta azul. Ela já sumiu três vezes.”",cartao:{produto:"Balança do SimpleFarm e Operis YMS",oque:"Pesagem de entrada e saída de cada caminhão, análise da cana e fila de pátio no mesmo fluxo.",quem:"Balanceiro ou analista de balança.",pergunta:"Quanto tempo leva hoje, do caminhão na fila ao ticket de pesagem fechado?",objecao:"Nossa balança já é automática.",resposta:"Ótimo. Vale medir o que acontece depois do peso: o ticket chega ao ERP sem redigitar?"}},
{id:"ind",ato:2,hora:"13:00",lugar:"Indústria",x:26,lado:1,quem:"Sílvia, gerente industrial",
 cena:"Fala alto, a moenda não para! O laboratório manda o resultado num papel, eu passo para a planilha, e a parada programada a gente programa... quando quebra. Laudo que vira decisão só depois do almoço é rendimento que a moenda perde a cada hora.",
 desculpa:"“A parada programada a gente programa quando quebra.”",
 pergs:[["Quanto tempo o resultado do laboratório leva para virar decisão na moenda?",1,"Sílvia: “O laudo sai de manhã. A decisão sai depois do almoço. A cana não espera o almoço.”"],
  ["Qual é a capacidade de moagem diária da indústria nesta safra?",0,"Sílvia: “Num dia bom, muita. Num dia de quebra, nenhuma. Hoje está no meio.”"],
  ["A gente tem um módulo industrial top, quer que eu já mande a proposta?",2,"Sílvia aponta o protetor de ouvido: “Hã? Proposta? Não ouvi, a moenda está muito alta!”"]],
 op:[["Processo industrial e Manutenção industrial",1,""],["Gestão automotiva",0,"Gestão automotiva cuida da frota. A Sílvia fala da planta."],["Gestão agrícola",0,"Gestão agrícola fica no campo. Aqui a cana já virou processo."]],
 frentes:[{n:"Processo industrial",p:"Gestão Industrial",c:["Planejamento industrial","Laboratório","Insumos industriais","Rendimentos e eficiências","Certificado de qualidade individualizado"]},{n:"Manutenção industrial",p:"Gestão Industrial",c:["Preventiva","Corretiva","Eficiência","Planejamento","Paradas programadas","Serviços externos","Nivelamento","Custos"]}],
 levar:"Como vocês ligam o resultado do laboratório ao rendimento da indústria? Como planejam as paradas?",
 feito:"Laboratório ligado ao rendimento; paradas programadas antes de quebrar.",
 roteiro:[["Você","Sílvia, o laudo do laboratório já virou decisão?"],["Sílvia","O laudo chega de manhã. A decisão, depois do almoço."],["Você","E a parada programada da moenda?"],["Sílvia","A gente programa quando quebra. Funciona, mas custa caro. Pergunta ao Jonas quanto açúcar já foi para o armazém dele."]],
 aprende:"A moenda esmaga a cana para extrair o caldo, e a moega guarda a cana que espera a vez. O laudo do laboratório ajusta o processo.",perda:{rotulo:"Horas de moenda parada",frase:"Cada hora que o laudo espera é hora de moenda rodando sem decisão."},corta:"Sílvia: “Fala depois da moagem. E fala do laudo, que eu entendo.”",abre:"Sílvia: “Agora sim. Esse é o problema do meu dia.”",cartao:{produto:"Gestão Industrial",oque:"Controla insumos, paradas e produção da indústria, com rendimento à vista da gerência.",quem:"Gerente industrial e laboratorista.",pergunta:"Quanto tempo o rendimento de um dia leva para chegar à gerência?",objecao:"A indústria já tem um sistema de supervisão.",resposta:"Pode manter o sistema atual. Aqui o foco é levar insumo, parada e produção à gestão."}},
{id:"arm",ato:2,hora:"14:30",lugar:"Armazém e pátio",x:52,lado:-1,quem:"Jonas, coordenador de expedição",
 cena:"Quanto tem no armazém? Tem bastante. Onde está? Lá dentro. Qual caminhão carrega agora? O que buzinar mais alto. Brincadeira. Mais ou menos. Carga fora de ordem é produto que sai sem conta e margem que o inventário não enxerga.",
 desculpa:"“Carrega primeiro o caminhão que buzinar mais alto.”",
 pergs:[["Como você decide qual caminhão carrega primeiro e confere o que saiu?",1,"Jonas: “Agenda no grupo do celular e confiro no olho. O inventário fecha... no fim do mês, com fé.”"],
  ["Quantas toneladas cabem no armazém, contando o pátio de fora?",0,"Jonas: “Cabe tudo. Até não caber mais. Aí cabe no pátio.”"],
  ["Imagina isso tudo num painel bonito com gráficos em tempo real?",2,"Jonas sorri: “Imagino. Agora imagina eu explicando painel bonito pro caminhoneiro.”"]],
 op:[["Armazéns e pátios",1,""],["Gestão Logística",0,"Gestão Logística cuida de frota e transporte. O Jonas cuida do produto acabado no armazém."],["Custos gerenciais",0,"Custos mostra quanto custou. O Jonas precisa saber onde está e quando sai."]],
 frentes:[{n:"Armazéns e pátios",p:"Operis",c:["Armazenamento","Expedição","Inventário"]},{n:"Fila de pátio",p:"Operis YMS",c:["Agendamento","Check-in","Painel de chamada"]}],
 levar:"Como vocês agendam as cargas e conferem o inventário? Onde o pátio trava?",
 feito:"Produto localizado, carga agendada e inventário conferido sem fé.",
 roteiro:[["Você","Jonas, qual caminhão carrega primeiro?"],["Jonas","O que buzinar mais alto. Brincadeira. Mais ou menos."],["Você","E o inventário, fecha quando?"],["Jonas","No fim do mês. Com fé. A Paula, lá na controladoria, quer esse número antes de vinte dias."]],
 aprende:"O armazém guarda o produto pronto, e o inventário confere quanto existe e onde está. Sem isso, o que sai não bate com o sistema.",perda:{rotulo:"Produto sem localização",frase:"Carga fora de ordem e inventário com fé: produto sai sem conta."},corta:"Jonas: “Painel? Moço, o caminhão já buzinou duas vezes.”",abre:"Jonas: “Pelo menos alguém pergunta como o caminhão sai. Continua.”",cartao:{produto:"Operis YMS e Operis",oque:"Agenda a fila de caminhões no pátio, com check-in e painel de chamada, e controla armazém e expedição.",quem:"Coordenador de expedição ou supervisor de pátio.",pergunta:"Quanto tempo um caminhão espera no pátio em dia de pico?",objecao:"O agendamento já é feito pelo grupo de WhatsApp.",resposta:"Um grupo de mensagens não prioriza a fila de caminhões. Vale comparar com o Operis YMS."}},
{id:"custo",ato:3,hora:"16:00",lugar:"Controladoria",x:76,lado:1,quem:"Paula, controller",
 cena:"Quanto custou a tonelada? Essa é a pergunta de um milhão. Está aqui na CUSTO_FINAL_v7_AGORA_VAI.xlsx. Não encosta no teclado. Tem post-it escrito “NÃO FECHAR”. Custo que chega vinte dias depois não mostra onde a margem escorreu. Só mostra o estrago.",
 desculpa:"“Está na CUSTO_FINAL_v7_AGORA_VAI.xlsx. Não fecha a planilha!”",
 pergs:[["Quanto tempo depois da operação você consegue dizer quanto custou a tonelada?",1,"Paula: “Uns vinte dias. Até lá a safra já mudou, o diesel subiu e o diretor já ligou três vezes.”"],
  ["Qual foi o custo da tonelada no mês passado, fechado pela controladoria?",0,"Paula: “Na v6 era um número. Na v7 é outro. Estou aguardando a v8.”"],
  ["Com a gente você teria esse número em tempo real, é só assinar aqui.",2,"Paula abre outra planilha: “Vou anotar sua proposta. Na aba 14. Depois a gente vê.”"]],
 op:[["Custos gerenciais",1,""],["Planejamento",0,"Planejamento monta o orçamento. A Paula quer o custo do que foi realizado."],["Integração com o ERP",0,"A integração leva os dados ao ERP. A visão gerencial que a Paula pede é outra frente."]],
 frentes:[{n:"Custos gerenciais",p:"SimpleFarm",c:["Por processo","Por recurso","Por fazenda","Por produto"]}],
 levar:"Quanto tempo depois da operação vocês fecham o custo? Por fazenda e por produto?",
 feito:"Custo por processo, recurso, fazenda e produto. A v8 não vai ser necessária.",
 roteiro:[["Você","Paula, quanto custou a tonelada no mês passado?"],["Paula","Está na CUSTO_FINAL_v7_AGORA_VAI.xlsx. Não fecha a planilha!"],["Você","E esse número bate com o da v6?"],["Paula","Na v6 era um. Na v7 é outro. A v8 vai desempatar, se o Rodrigo me mandar os números do ERP."]],
 aprende:"O custo da tonelada é o gasto total da safra dividido pelo que foi produzido. Quando fecha tarde, a decisão de hoje vira retrovisor.",perda:{rotulo:"Retrabalho de fechamento",frase:"Custo que chega vinte dias depois mostra o estrago, não o caminho."},corta:"Paula: “Não encosta no teclado, por favor. Sério.”",abre:"Paula: “Era isso. Agora entendo por que o diretor liga três vezes.”",cartao:{produto:"SimpleFarm (controladoria)",oque:"Módulo de controladoria do SimpleFarm para apurar custos gerenciais.",quem:"Controller ou diretor financeiro.",pergunta:"Quanto tempo passa entre uma aplicação no talhão e você saber o custo real dele?",objecao:"Já temos BI.",resposta:"Pode seguir com o BI. Vale checar se o custo do campo chega até ele."}},
{id:"erp",ato:3,hora:"16:45",lugar:"Centro de gestão",x:88,lado:1,quem:"Rodrigo, analista de integração",
 cena:"Minha função? Eu sou a integração. Pego o que a operação faz e digito no ERP. Depois pego o que o ERP diz e conto para a operação. Por telefone. Cada número redigitado é uma chance de a margem se perder entre a operação e o ERP.",
 desculpa:"“A integração sou eu. Por telefone.”",
 pergs:[["O que hoje ainda é redigitado entre a operação e o ERP?",1,"Rodrigo: “Requisição, pesagem, estoque, pagamento... Mais fácil perguntar o que não é. Nada.”"],
  ["Qual ERP vocês usam hoje, e faz quanto tempo que está implantado?",0,"Rodrigo: “Um ERP bom. O problema não é ele, é a ponte até ele. A ponte sou eu.”"],
  ["Troca tudo pelo nosso e seus problemas acabam!",2,"Rodrigo cruza os braços: “Trocar tudo? Moço, eu levei dois anos pra decorar os atalhos.”"]],
 op:[["Integração com o ERP",1,""],["Automação",0,"Automação leva o dado da máquina e do sensor para a plataforma. O Rodrigo fala do fluxo entre a plataforma e o ERP."],["Custos gerenciais",0,"Custos apura e mostra o valor. Quem leva o dado da operação até o ERP é a integração."]],
 frentes:[{n:"Integração com o ERP",p:"Gestão Empresarial",c:["Pagamentos","Estoque","Contabilidade","Custo","Compras","Folha de pagamento"]}],
 levar:"O que hoje ainda é redigitado entre a operação e o ERP? O que precisa voltar do ERP para o campo?",
 feito:"Requisição, pesagem e estoque chegando ao ERP sozinhos; o Rodrigo finalmente almoça.",
 roteiro:[["Você","Rodrigo, a operação já conversa com o ERP?"],["Rodrigo","Tenho dois celulares. Um integra, o outro confirma o que o primeiro disse."],["Você","Então a integração é automática?"],["Rodrigo","Automática é a ponte. E a ponte sou eu, por telefone. Se o André fechar um navio hoje, eu só descubro amanhã."]],
 aprende:"O ERP guarda contabilidade, estoque e folha da empresa. A integração leva a ele o que a operação registra, sem digitar de novo.",perda:{rotulo:"Número redigitado",frase:"Cada número redigitado entre a operação e o ERP é uma chance de a margem se perder."},corta:"Rodrigo: “Trocar tudo? E quem me ensina os atalhos de novo?”",abre:"Rodrigo: “Enfim alguém que pergunta da ponte. Eu achei que ninguém via.”",cartao:{produto:"Gestão Empresarial (ERP) e GAtec",oque:"ERP para agroindústria, ligado à operação de campo e industrial pela integração GAtec.",quem:"Diretor financeiro, controller ou compras.",pergunta:"Qual ERP vocês usam, há quanto tempo, e o que ainda é redigitado nele?",objecao:"Já temos ERP e não queremos trocar.",resposta:"Não se trata de trocar o ERP. Trata-se de conectar a operação a ele, com compatibilidade confirmada."}},
{id:"com",ato:3,hora:"17:30",lugar:"Porto",x:98,lado:-1,quem:"André, trader",
 cena:"O navio sai em dois dias. O preço eu fechei, o risco eu controlo de cabeça, e o contrato... está no e-mail. Em algum dos 4.312 e-mails não lidos. Contrato perdido no e-mail é risco de preço que a usina carrega até o navio sair.",
 desculpa:"“O contrato está no e-mail. Em algum dos 4.312 não lidos.”",
 pergs:[["Você enxerga posição física, contratos e risco na mesma foto, hoje?",1,"André ri: “Na mesma foto? Eu enxergo em três telas, dois celulares e um palpite.”"],
  ["Para onde vai esse navio, e quanto de açúcar ele leva nessa viagem?",0,"André: “Para onde o contrato mandar. Assim que eu achar o contrato.”"],
  ["Nosso sistema de trading é o melhor do mercado, posso te mostrar?",2,"André põe o telefone na orelha: “Hello? Yes, yes, the ship...” e se afasta falando inglês."]],
 op:[["Comercialização",1,""],["Originação",0,"Originação compra a matéria-prima. O André vende e embarca o produto."],["Armazéns e pátios",0,"O armazém expede. Preço, risco, contrato e embarque são da comercialização."]],
 frentes:[{n:"Comercialização",p:"Commerce",c:["Oneclick","Trading","Front office e pricing","Gestão de contratos","MtM e P&L","Gestão de riscos","Compliance","Rastreabilidade","Integrado com a execução","Commerce","Produtores e tradings","Commodities","Contratos de compra e venda","Controle de ponta a ponta","Execução do embarque","Otimização operacional","Multimoedas","Commerce Log","Gestão de carregamentos","Fretes de compra, venda e transferência","Planejamento dos embarques","Planejado × executado","Contato com a transportadora","E-mails automáticos"]}],
 levar:"Vocês enxergam posição física, contratos e risco na mesma foto?",
 feito:"Preço, risco, contrato e embarque na mesma foto. A caixa de entrada agradece.",
 roteiro:[["Você","André, onde está o contrato desse navio?"],["André","No e-mail. Em algum dos 4.312 não lidos."],["Você","E o navio já foi vendido?"],["André","Fechado. Só falta o contrato aparecer. O diretor deve ligar, então ache o contrato antes."]],
 aprende:"Trading compra e vende commodities para entrega futura. Fixar preço é travar o valor de uma venda antes do embarque.",perda:{rotulo:"Risco de preço",frase:"Contrato perdido no e-mail é risco de preço que a usina carrega até o navio sair."},corta:"André: “Demo agora? O navio sai em dois dias, moço.”",abre:"André: “Essa é a pergunta certa. Eu chuto, mas prefiro provar.”",cartao:{produto:"Commerce",oque:"Controla contratos físicos, fretes, exposição e fixações de commodities.",quem:"Traders e gestores de risco.",pergunta:"Quanto tempo leva para consolidar exposição e fixações de uma semana?",objecao:"Já usamos planilha de risco.",resposta:"Mantenha a planilha para análise. Ganhe ao unir contrato, frete e P&L numa base só."}}];

// Final: a ligação do diretor (viva-voz). Objeções só no nível Especialista.
const DIRETOR = {
  quem: 'Dr. Augusto, diretor da Usina Horizonte',
  abre: '“Fala, tô na serra, o sinal cai a qualquer momento. A Horizonte perdeu margem na safra passada e ninguém sabe onde. Te dei um dia para descobrir. Me diz em três frases: por que eu deveria te dar meia hora na semana que vem?”',
  objecoes: [
    { q: '“A gente já paga um ERP caro. Por que eu pagaria mais um sistema?”',
      r: [['Hoje o Rodrigo leva pesagem e estoque ao ERP por telefone. A gente liga a operação ao ERP que o senhor já paga, sem trocar nada.', 1],
          ['Nosso ERP é melhor que o seu, vale trocar tudo.', 0],
          ['É só mais um sisteminha, ninguém nem percebe.', 0]] },
    { q: '“Meu pessoal vai largar o caderno? O Seu Tião nunca vai largar o caderno.”',
      r: [['Começa pela oficina, onde o trator sem preventiva dói mais. O apontamento vai no celular e sincroniza depois de registrado. O Seu Tião vira o primeiro a mostrar.', 1],
          ['Aí a gente recolhe os cadernos no primeiro dia.', 0],
          ['Treinamento obrigatório de 40 horas resolve.', 0]] },
    { q: '“Já me prometeram número em uma semana. Quanto tempo até eu ver um número em que eu confie?”',
      r: [['Hoje o custo da tonelada muda de versão para versão: v6, v7 e uma v8 que ninguém viu. Começo pelo custo da controladoria e medimos o prazo juntos.', 1],
          ['Em uma semana está tudo funcionando, garanto.', 0],
          ['Isso depende do senhor, não da gente.', 0]] }
  ]
};
const NIVEIS = {
  trainee: { n: 'Trainee', d: 'Evidências brilham, o tablet dá dica e errar não custa caro.', brilho: true, dica: true, pesoErro: 0.5, isca: false, objecoes: 0 },
  executivo: { n: 'Executivo', d: 'Sem brilho nas evidências. Você precisa olhar a cena.', brilho: false, dica: false, pesoErro: 1, isca: false, objecoes: 1 },
  especialista: { n: 'Especialista', d: 'Sem dicas, uma frente-isca a mais em cada conversa e o diretor faz objeções.', brilho: false, dica: false, pesoErro: 1.5, isca: true, objecoes: 3 }
};


const SINAIS = [{id:"mob",x:-60,z:5.6,n:"Mobilidade de campo",p:"Celular Android",t:"Os apontamentos de campo têm versão para celular Android e sincronizam depois de registrados.",c:["Apontamento em Android","Sincroniza depois","Formulários no aplicativo"]},{id:"iot",x:-36,z:5.6,n:"Automa\xE7\xE3o",p:"IoT",t:"As m\xE1quinas e os sensores mandam os dados sem digita\xE7\xE3o.",c:["Envio de apontamentos","Dados operacionais das m\xE1quinas","Dados meteorol\xF3gicos","An\xE1lises laboratoriais","Consumo das m\xE1quinas"]},{id:"vin",x:-12,z:5.6,n:"Log\xEDstica de vinha\xE7a e plantio",p:"SimpleFarm",t:"Dimensiona e controla o abastecimento das opera\xE7\xF5es de campo.",c:["Otimiza\xE7\xE3o","Redu\xE7\xE3o","Gest\xE3o e controle","Abastecimento linear (CTT, plantio, preparo e tratos)","Dimensionamento","Previs\xF5es e tend\xEAncias","Custos"]},{id:"erp",x:64,z:5.6,n:"Integra\xE7\xE3o com o ERP",p:"Senior",t:"O que acontece na opera\xE7\xE3o chega \xE0 gest\xE3o da empresa.",c:["Pagamentos","Estoque","Contabilidade","Custo","Compras","Folha de pagamento"]}];

const EVIDENCIAS = [{id:"ev-plan1",st:"plan",x:-100.5,z:-11.5,y:1.3,n:"Quadro do plano de safra",d:"Plantio e reforma, colheita, or\xE7amento e recursos escritos na parede da sede \u2014 o plano vive no papel.",val:"pendente"},{id:"ev-plan2",st:"plan",x:-92.5,z:-11,y:.9,n:"Recursos na planilha",d:"M\xE1quinas e equipes alocadas \xE0 m\xE3o, sem v\xEDnculo com o plano impresso.",val:"pendente"},{id:"ev-geo1",st:"geo",x:-75.5,z:15.5,y:1.2,n:"A mancha no talh\xE3o",d:"A \xE1rea amarelada que a imagem de sat\xE9lite apontou \u2014 vis\xEDvel da estrada.",val:"pendente"},{id:"ev-geo2",st:"geo",x:-64.5,z:15.2,y:1.2,n:"Torre e drone prontos",d:"A opera\xE7\xE3o j\xE1 tem dado de cima; falta ligar o que se v\xEA ao que se decide.",val:"pendente"},{id:"ev-agri1",st:"agri",x:-52.5,z:-11,y:1.1,n:"Apontamento em papel",d:"O apontamento da frente vira planilha depois \u2014 quando sobra tempo.",val:"pendente"},{id:"ev-agri2",st:"agri",x:-43.5,z:-12,y:1,n:"Palha e cana inteira",d:"A colhedora deixa cana inteira no campo: perda que ningu\xE9m soma no dia.",val:"pendente"},{id:"ev-auto1",st:"auto",x:-20.5,z:15,y:1.3,n:"Ordem de preventiva atrasada",d:"A preventiva do trator venceu na semana passada e o cap\xF4 continua aberto.",val:"pendente",cadeia:!0},{id:"ev-auto2",st:"auto",x:-27.5,z:15.5,y:1,n:"Abastecimento no caderno",d:"Litros anotados \xE0 m\xE3o no balc\xE3o da oficina \u2014 custo de m\xE1quina sem dono.",val:"pendente"}];

PARADAS.forEach(g => {
  g.sz = g.lado * 4.5;
  g.nz = g.lado * 10.5;
  g.bz = g.lado * 22;
  g.val = "pendente — revisão agro antes do piloto";
});



// Conversa em rodadas (SPIN). Cada parada tem 4 rodadas: situacao, problema, implicacao, proposta.
// q: boa (avança e sobe a confiança), morna (avança pouco), ruim (gafe; com corta:true a pessoa encerra), erro (só na proposta: escolha errada),
// isca (plausível e fora do alvo; só no nível Especialista), evid (só na implicação, se a evidência foi registrada; evR traz a resposta).
// chave (rodada 2): termo que a pessoa diz na resposta da rodada 2; a opção boa da rodada 3 retoma esse termo.
// Na proposta, a boa cita a dor nas palavras da pessoa e o resultado (feito); as erradas falam de produto ou de outra área.
const CONVERSAS = {
plan: [
 {etapa:'situacao', dica:'Etapa 1, situação: pergunte sobre o trabalho dela. Deixe ela descrever.', opcoes:[
  {t:'Helena, como o plano da safra nasce hoje e onde ele vai parar?', q:'boa', r:'Nasce aqui, na sede, com café e caneta. Vai para o quadro, depois para a planilha e, se sobrar tempo, para o bloquinho.'},
  {t:'Helena, se o plano sai do quadro para a planilha, quanto custa cada dia de atraso?', q:'morna', r:'Custo? Eu nem sei onde ele dói ainda. Primeiro me pergunta como o plano anda hoje.'},
  {t:'Helena, como o plano do ano passado nasce hoje e onde ele vai parar?', q:'ruim', r:'Ano passado? Este plano é o da safra. Nasce aqui, com café e caneta.'},
  {t:'Helena, como o plano de compras da sede nasce hoje e onde ele vai parar?', q:'isca', r:'Compras é com a Paula. Eu falo do plano da safra.'}]},
 {etapa:'problema', dica:'Etapa 2, problema: procure onde dói, com as palavras dela.', chave:'caneta azul', opcoes:[
  {t:'Quando o plano sai do quadro e vai para a planilha, o que se perde pelo caminho?', q:'boa', r:'Não sei com certeza. A versão certa é a de caneta azul, e nem sempre é a que a colheita lê.'},
  {t:'Quando o plano sai do quadro e vai para a planilha, quanto de colheita se perde por dia?', q:'morna', r:'Por dia? Não sei. Sei que a planilha é a última a saber.'},
  {t:'Quando o plano sai do quadro e vai para o bloquinho, o que se perde pelo caminho?', q:'ruim', r:'Bloquinho? Vai para a planilha. O bloquinho é só o rascunho do rascunho.'},
  {t:'Quando o plano sai do quadro e vai para a planilha, quem paga o diesel da frota?', q:'isca', r:'Diesel é com a Paula. Eu só sei que o quadro manda.'}]},
 {etapa:'implicacao', dica:'Etapa 3, implicação: deixe ela dizer o que custa. Não diga você.', evR:{'ev-plan1':'Esse quadro é a casa do plano. Quando o campo muda, eu apago e escrevo de novo.','ev-plan2':'Essa planilha tem as máquinas, mas não sabe que a caneta azul mudou.'}, opcoes:[
  {t:'Quando a caneta azul não bate com o campo, quanto a usina perde até alguém perceber?', q:'boa', r:'Uma frente inteira no talhão errado. Até alguém perceber, são dias de máquina e de cana.'},
  {t:'Quando a caneta azul não bate com o campo, como o plano é registrado no sistema da sede?', q:'morna', r:'Sistema? Antes disso, a caneta azul tem que aparecer.'},
  {t:'Quando a caneta azul não bate com o campo, e isso atrasa a colheita, como vocês lidam?', q:'ruim', r:'Lidamos depois que a frente já foi para o talhão errado. Não tem jeito bonito para isso.'},
  {t:'Quando a caneta azul não bate com o campo, quanto a frota gasta a mais de diesel?', q:'isca', r:'Diesel é com a Paula. Eu só sei que a caneta azul mudou.'}]},
 {etapa:'proposta', dica:'Etapa 4, proposta: ligue a solução à dor que ela descreveu.', opcoes:[
  {t:'Quando o campo muda, o SimpleFarm atualiza o plano sem apagar e escrever de novo, num lugar só, com a versão que a colheita lê.', q:'boa', r:'É isso. Ninguém tinha pensado nisso antes. Vai ao talhão 12, o Caio tem uma mancha para mostrar.'},
  {t:'O SimpleFarm tem módulo de planejamento, com app, painel, orçamento e relatórios. Integra com o ERP e tem versão para o celular.', q:'erro', r:'Isso é a lista de recursos. Eu perguntei o que muda quando o campo muda.'},
  {t:'O HCM cuida da folha dos safristas, do ponto e da escala de alojamento, então a sede fica tranquila com o RH e o refeitório.', q:'erro', r:'Safrista é com o RH. Eu estou falando do plano, e ele ainda está no quadro.'}]}
],
geo: [
 {etapa:'situacao', dica:'Etapa 1, situação: pergunte sobre o trabalho dele. Deixe ele descrever.', opcoes:[
  {t:'Caio, como uma mancha vista no talhão chega até a sua decisão de aplicar?', q:'boa', r:'O satélite aponta a mancha, mas eu venho olhar com os meus olhos. Depois a aplicação vai para aprovação, por e-mail.'},
  {t:'Caio, se a mancha chega à aplicação por e-mail, quanto a praga come por dia?', q:'morna', r:'Isso eu não sei medir. Primeiro me pergunta como a mancha chega até mim.'},
  {t:'Caio, como uma mancha vista na sede chega até a sua decisão de aplicar?', q:'ruim', r:'Na sede? Mancha se vê no talhão, moço. Da sede não se vê nada.'},
  {t:'Caio, como uma mancha vista no talhão chega até o contrato de compra do diesel?', q:'isca', r:'Diesel é com a Paula. Eu só quero a mancha no talhão.'}]},
 {etapa:'problema', dica:'Etapa 2, problema: procure onde dói, com as palavras dele.', chave:'e-mail com três aprovações', opcoes:[
  {t:'Quando a praga aparece, o que segura a aplicação entre o seu olho e o pulverizador?', q:'boa', r:'Um e-mail com três aprovações. Ele chega quando a praga já ganhou de mim por dois a zero.'},
  {t:'Quando a praga aparece, quanto custa cada dia de aplicação parada no pulverizador?', q:'morna', r:'Custa caro, mas ainda não sei o número. Me pergunta primeiro onde a aplicação trava.'},
  {t:'Quando a praga aparece, o que segura a aplicação entre o seu olho e o caminhão?', q:'ruim', r:'Caminhão? Quem segura é o pulverizador. Caminhão é com a frota.'},
  {t:'Quando a praga aparece, o que segura a compra do pulverizador entre o seu olho e a sede?', q:'isca', r:'Compra é com a sede. Eu falo de aplicação.'}]},
 {etapa:'implicacao', dica:'Etapa 3, implicação: deixe ele dizer o que custa. Não diga você.', evR:{'ev-geo1':'Essa é a mancha, visível da estrada. Se eu aplico amanhã, ela já virou duas.','ev-geo2':'A torre e o drone estão aí, prontos. O que falta é ligar o que eles veem ao que eu decido.'}, opcoes:[
  {t:'Quando a praga ganha dois dias nesse e-mail com três aprovações, o que vem depois?', q:'boa', r:'Uma área de cana que a praga come antes da moagem. Não tem número bonito para isso, tem perda.'},
  {t:'Quando a praga ganha dois dias nesse e-mail com três aprovações, como a aplicação é aprovada no sistema?', q:'morna', r:'Sistema? Antes disso, a praga tem que parar de ganhar.'},
  {t:'Quando a praga ganha dois dias nesse e-mail, e a área perde tudo, o que vem depois?', q:'ruim', r:'A área perde, sim. Não precisava você me dizer isso.'},
  {t:'Quando a praga ganha dois dias nesse e-mail com três aprovações, quanto a sede gasta de energia?', q:'isca', r:'Energia é com a sede. Eu só olho a lavoura.'}]},
 {etapa:'proposta', dica:'Etapa 4, proposta: ligue a solução à dor que ele descreveu.', opcoes:[
  {t:'Com o e-mail de três aprovações no meio, a mancha demora; com Shield e Mapfy, ela vira aplicação dirigida no mesmo dia.', q:'boa', r:'É isso. Vai à frente de colheita. A Marta precisa dar passagem para a aplicação.'},
  {t:'O Shield tem IA e geoprocessamento para manejo sustentável de pragas, e o Mapfy tem mapas em web e mobile com uso offline.', q:'erro', r:'Isso é a apresentação. Eu perguntei por que a praga espera o e-mail.'},
  {t:'A gestão automotiva cuida do pulverizador, da manutenção e do combustível da frota, com ordem de serviço e custo por máquina.', q:'erro', r:'O pulverizador é do motorista. A praga é minha.'}]}
],
agri: [
 {etapa:'situacao', dica:'Etapa 1, situação: pergunte sobre o trabalho dela. Deixe ela descrever.', opcoes:[
  {t:'Marta, depois que a cana cai no transbordo, por onde passa o apontamento?', q:'boa', r:'Anoto na prancheta. O carro leva o papel até a sede, e a digitadora lança à noite.'},
  {t:'Marta, depois que a cana cai no transbordo, quanto de cana se perde por dia?', q:'morna', r:'Não sei o número. Primeiro me conta onde o apontamento passa, que eu ainda estou no papel.'},
  {t:'Marta, depois que a cana cai na balança, por onde passa o apontamento?', q:'ruim', r:'Balança é com o Rui. Eu anoto na prancheta, no transbordo.'},
  {t:'Marta, depois que a cana cai no transbordo, quem tira o diesel do tanque?', q:'isca', r:'Diesel é com a Paula. Eu só anoto a cana.'}]},
 {etapa:'problema', dica:'Etapa 2, problema: procure onde dói, com as palavras dela.', chave:'cana inteira', opcoes:[
  {t:'Quando o apontamento chega dois dias depois, o que se perde no talhão?', q:'boa', r:'A colhedora deixa cana inteira para trás, e ninguém soma. Quando eu vejo, a cana já está no chão.'},
  {t:'Quando o papel chega dois dias depois, quanto custa a hora da colhedora parada?', q:'morna', r:'Custa, mas o problema está no papel, moço. Primeiro me pergunta onde ele se perde.'},
  {t:'Quando o apontamento chega dois meses depois, o que se perde no talhão?', q:'ruim', r:'Dois meses? É dois dias, moço. Dois meses ninguém aguenta.'},
  {t:'Quando o apontamento chega dois dias depois, o que se perde no almoxarifado?', q:'isca', r:'Almoxarifado é com o Jonas. Eu falo da cana no talhão.'}]},
 {etapa:'implicacao', dica:'Etapa 3, implicação: deixe ela dizer o que custa. Não diga você.', evR:{'ev-agri1':'Esse papel é o apontamento. Só vira planilha quando sobra tempo, e tempo é o que não sobra.','ev-agri2':'Olha a cana inteira no talhão. Ninguém soma isso no dia, e a gente só vê no fim do mês.'}, opcoes:[
  {t:'Quando a colhedora deixa cana inteira no talhão, quanto a usina perde por dia?', q:'boa', r:'Não sei o número exato. Sei que cada colhedora que deixa cana inteira é cana que ninguém soma no dia.'},
  {t:'Quando a colhedora deixa cana inteira no talhão, como a sede registra o apontamento?', q:'morna', r:'Registro é com a digitadora. Eu falo do talhão, que é onde a cana fica.'},
  {t:'Quando a colhedora deixa cana inteira no talhão, e isso atrasa tudo, quanto a usina perde por dia?', q:'ruim', r:'Atrasa, sim. Mas o número, quem diz é o diretor.'},
  {t:'Quando a colhedora deixa cana inteira no talhão, quanto a oficina gasta de peça por mês?', q:'isca', r:'Peça é com o Seu Tião. Eu só quero que a colhedora ande.'}]},
 {etapa:'proposta', dica:'Etapa 4, proposta: ligue a solução à dor que ela descreveu.', opcoes:[
  {t:'Se a colheita de terça só chega na quinta, o MobAgro registra o apontamento no Android e sincroniza depois, sem a digitadora.', q:'boa', r:'Agora sim. Me mostra isso no celular, que o encarregado é o primeiro a querer.'},
  {t:'O MobAgro tem versão para Android, formulários no aplicativo, sincronização e painel de apontamentos com filtros por frente, equipe e talhão.', q:'erro', r:'Isso é o folheto do produto. Eu falei da prancheta, e a prancheta é a minha dor.'},
  {t:'O ERP fecha a folha dos safristas, paga no dia certo, envia o comprovante ao RH da sede e concilia o ponto de cada turma com a escala do mês.', q:'erro', r:'Folha é com o RH. A prancheta é comigo.'}]}
],
auto: [
 {etapa:'situacao', dica:'Etapa 1, situação: pergunte sobre o trabalho dele. Deixe ele descrever.', opcoes:[
  {t:'Quando a máquina precisa de reparo, como a ordem chega até a oficina?', q:'boa', r:'Anoto no caderno e penduro na parede. A peça eu vou atrás, no almoxarifado ou no telefone.'},
  {t:'Quando a máquina precisa de reparo, quanto custa uma hora dela parada?', q:'morna', r:'Não sei de cabeça. Me pergunta como a ordem chega, que eu ainda estou no caderno.'},
  {t:'Quando a máquina precisa de reparo, como a ordem chega até a sede?', q:'ruim', r:'Sede? A ordem chega é na oficina, moço. Na sede ninguém lê caderno.'},
  {t:'Quando a máquina precisa de reparo, como a folha de pagamento chega até a oficina?', q:'isca', r:'Folha é com o RH. Eu falo de peça e de caderno.'}]},
 {etapa:'problema', dica:'Etapa 2, problema: procure onde dói, com as palavras dele.', chave:'barulhinho desde março', opcoes:[
  {t:'Quando o trator começou a falhar, o senhor abriu ordem ou só anotou no caderno?', q:'boa', r:'Anotei no caderno. Ele faz um barulhinho desde março, e a gente vai levando.'},
  {t:'Quando o trator começou a falhar, quanto de diesel a frota gasta a mais?', q:'morna', r:'Diesel é com a Paula. Primeiro me pergunta do caderno.'},
  {t:'Quando o trator começou a falhar em fevereiro, o senhor abriu ordem ou só anotou no caderno?', q:'ruim', r:'Fevereiro? Foi março, moço. O caderno também erra.'},
  {t:'Quando o trator começou a falhar, a balança já sabia do problema, ou só anotou no caderno?', q:'isca', r:'Balança é com o Rui. Trator é comigo, e é caderno.'}]},
 {etapa:'implicacao', dica:'Etapa 3, implicação: deixe ele dizer o que custa. Não diga você.', evR:{'ev-auto1':'A preventiva venceu semana passada. A ordem ainda está pregada na parede, e ele faz barulhinho.','ev-auto2':'Litro anotado no caderno, esse é o único registro. Quem paga o diesel acha que é de graça.'}, opcoes:[
  {t:'Com esse barulhinho desde março, o que acontece quando o trator para na safra?', q:'boa', r:'Caro. A frente de colheita espera o trator, e o caminhão de cana atrasa. O número exato é com a Paula.'},
  {t:'Com esse barulhinho desde março, como a ordem chega até o almoxarifado?', q:'morna', r:'Ordem? Eu penduro na parede. A peça eu vou atrás no telefone.'},
  {t:'Com esse barulhinho desde março, e o trator vai parar na safra, o que acontece depois?', q:'ruim', r:'Vai parar, sim. Você já sabe, então por que me pergunta?'},
  {t:'Com esse barulhinho desde março, quanto o RH paga de hora extra para o motorista?', q:'isca', r:'Hora extra é com o RH. Eu cuido do trator.'}]},
 {etapa:'proposta', dica:'Etapa 4, proposta: ligue a solução à dor que ele descreveu.', opcoes:[
  {t:'O barulhinho desde março e a preventiva vencida viram uma ordem de serviço: a peça sai do estoque ou vira compra no ERP, e o custo fica na máquina.', q:'boa', r:'É isso mesmo. Vai no Rui, que o caminhão de cana já atrasou por causa desse trator.'},
  {t:'A manutenção automotiva do SimpleFarm tem planejamento, preventiva, corretiva, histórico completo, painel de custos e alertas por máquina, com relatórios para a gestão.', q:'erro', r:'Isso é a lista de coisas. Eu perguntei de onde vem a peça.'},
  {t:'O HCM cuida dos mecânicos na folha, na escala de turnos e no banco de horas da oficina, com ponto eletrônico, aviso de férias e controle de horas extras por equipe.', q:'erro', r:'Mecânico eu sei escalar. Quero saber da peça e do barulhinho.'}]}
],
orig: [
 {etapa:'situacao', dica:'Etapa 1, situação: pergunte sobre o trabalho dele. Deixe ele descrever.', opcoes:[
  {t:'Quando um fornecedor entrega cana, qual o caminho até o pagamento?', q:'boa', r:'Primeiro a tara, depois o bruto, e o líquido sai da conta. O contrato eu procuro na papelada, e o pagamento depende de achar o ticket.'},
  {t:'Quando um fornecedor entrega cana, quanto a usina perde por cada pagamento atrasado?', q:'morna', r:'Não sei o número. Primeiro me pergunta como a cana chega à balança.'},
  {t:'Quando um fornecedor entrega milho, qual o caminho até o pagamento?', q:'ruim', r:'Milho? Aqui é cana, moço. Milho eu não peso.'},
  {t:'Quando um fornecedor entrega cana, qual o caminho do diesel até o pagamento?', q:'isca', r:'Diesel é com a Paula. Eu só peso a cana.'}]},
 {etapa:'problema', dica:'Etapa 2, problema: procure onde dói, com as palavras dele.', chave:'pedido de desculpas', opcoes:[
  {t:'Quando um fornecedor reclama do pagamento, quanto tempo você leva para achar o contrato?', q:'boa', r:'Se a pasta azul aparecer, meia hora. Se não, uma tarde e um pedido de desculpas ao fornecedor.'},
  {t:'Quando um fornecedor reclama do pagamento, quanto a usina perde por fornecedor que sai?', q:'morna', r:'Perde, sim, mas eu ainda nem achei o contrato. Primeiro me pergunta onde ele some.'},
  {t:'Quando um fornecedor reclama do pagamento, quanto tempo você leva para achar o ticket?', q:'ruim', r:'O ticket é da pesagem, moço. O contrato é que some. Mas o ticket também.'},
  {t:'Quando um fornecedor reclama do pagamento, quanto tempo a sede leva para liberar o cartão?', q:'isca', r:'Cartão é com a sede. Eu falo de contrato na papelada.'}]},
 {etapa:'implicacao', dica:'Etapa 3, implicação: deixe ele dizer o que custa. Não diga você.', opcoes:[
  {t:'Depois de um pedido de desculpas ao fornecedor, o que acontece na safra seguinte?', q:'boa', r:'Custa fornecedor que não volta na safra seguinte. E dinheiro que sai pela balança sem conta achada.'},
  {t:'Depois de um pedido de desculpas ao fornecedor, como o contrato chega até a pasta azul?', q:'morna', r:'Pasta azul? Primeiro me conta como o contrato chega ao pagamento, que eu ainda estou na papelada.'},
  {t:'Depois de um pedido de desculpas ao fornecedor, e ele perde a safra inteira, o que acontece?', q:'ruim', r:'Perde, sim. Não precisava você me dizer. Eu já sei.'},
  {t:'Depois de um pedido de desculpas ao fornecedor, quanto a sede gasta com a folha de março?', q:'isca', r:'Folha é com o RH. Eu cuido de cana e de papelada.'}]},
 {etapa:'proposta', dica:'Etapa 4, proposta: ligue a solução à dor que ele descreveu.', opcoes:[
  {t:'Quando o contrato não aparece, vem o pedido de desculpas; com a pesagem ligada ao contrato e ao pagamento, cada carga fica amarrada.', q:'boa', r:'Enfim alguém fala da pasta azul. Vai ver o Jonas no armazém, ele sabe onde o produto está.'},
  {t:'O App da Balança tem painel de indicadores e gráficos bonitos por turno, agenda de cargas, alertas no celular e integração de cancelas e balanças.', q:'erro', r:'Gráfico não acha contrato, moço.'},
  {t:'O Commerce cuida de contrato de venda de açúcar, risco de preço, frete até o porto e P&L por embarque, com exposição líquida por produto.', q:'erro', r:'Porto é com o André. Aqui eu pesei a cana que chegou hoje.'}]}
],
ind: [
 {etapa:'situacao', dica:'Etapa 1, situação: pergunte sobre o trabalho dela. Deixe ela descrever.', opcoes:[
  {t:'Sílvia, como o resultado do laboratório chega até a moenda hoje?', q:'boa', r:'O laudo sai no papel de manhã. Eu passo para a planilha e levo até a moenda, de mão em mão.'},
  {t:'Sílvia, quanto a moenda perde por hora quando o laudo não chega?', q:'morna', r:'Não sei o número. Me pergunta primeiro como o laudo chega, que eu ainda estou no papel.'},
  {t:'Sílvia, como o resultado do laboratório chega até a balança hoje?', q:'ruim', r:'Balança? A cana é que passa lá. O laudo vai para a moenda, moço.'},
  {t:'Sílvia, como a folha dos safristas chega até a moenda hoje?', q:'isca', r:'Safrista é com o RH. Eu cuido do laudo e da moenda.'}]},
 {etapa:'problema', dica:'Etapa 2, problema: procure onde dói, com as palavras dela.', chave:'a cana não espera', opcoes:[
  {t:'Quando o laudo só chega depois do almoço, quanto de moenda roda sem decisão?', q:'boa', r:'Cada hora de espera é moenda rodando sem decisão. A cana não espera o almoço.'},
  {t:'Quando o laudo só chega depois do almoço, quanto custa cada hora de moenda parada?', q:'morna', r:'Custa, mas não tenho número. Primeiro me conta onde o laudo trava.'},
  {t:'Quando o laudo só chega depois da janta, quanto de moenda roda sem decisão?', q:'ruim', r:'Janta? Quem janta é o turno da noite. O laudo chega depois do almoço.'},
  {t:'Quando o laudo só chega depois do almoço, quanto de diesel a moenda consome por dia?', q:'isca', r:'Diesel é com a Paula. Eu só quero a moenda com decisão.'}]},
 {etapa:'implicacao', dica:'Etapa 3, implicação: deixe ela dizer o que custa. Não diga você.', opcoes:[
  {t:'Se a cana não espera o almoço, quanto rendimento se perde a cada hora sem decisão?', q:'boa', r:'Não tenho o número na mão. Sei que cada hora sem decisão é rendimento que a moenda perde, e o diretor sente no fim do mês.'},
  {t:'Se a cana não espera o almoço, como o laudo chega até a planilha da sede?', q:'morna', r:'Planilha da sede é com a Paula. O laudo eu levo de mão em mão.'},
  {t:'Se a cana não espera o almoço, e a moenda perde rendimento a cada hora, quanto se perde por dia?', q:'ruim', r:'Perde, sim. Você já sabe disso, então por que pergunta?'},
  {t:'Se a cana não espera o almoço, quanto a balança gasta de papel por mês?', q:'isca', r:'Papel é com o Rui. Eu só espero o laudo.'}]},
 {etapa:'proposta', dica:'Etapa 4, proposta: ligue a solução à dor que ela descreveu.', opcoes:[
  {t:'O laudo que chega de manhã e a decisão que sai depois do almoço viram, na Gestão Industrial, rendimento à vista da gerência, todo dia.', q:'boa', r:'Agora sim. Esse é o problema do meu dia. Me manda o laudo de amanhã cedo.'},
  {t:'A Gestão Industrial tem gestão de insumos, estoque, produção, paradas, planejamento de manutenção, painéis de eficiência e custo por unidade produzida.', q:'erro', r:'Isso é a lista do catálogo. Eu quero saber do laudo.'},
  {t:'A Gestão Logística cuida do caminhão de cana desde a fila da balança até a rota e a moega, com controle de frota, motoristas e custo por viagem.', q:'erro', r:'Caminhão é com a balança. Eu estou na moenda, moço.'}]}
],
arm: [
 {etapa:'situacao', dica:'Etapa 1, situação: pergunte sobre o trabalho dele. Deixe ele descrever.', opcoes:[
  {t:'Jonas, como você decide qual caminhão carrega primeiro e onde está cada carga hoje?', q:'boa', r:'Agenda no grupo do celular. Onde está cada carga, eu sei no olho e na memória.'},
  {t:'Jonas, quanto de produto some por dia quando a carga sai fora de ordem?', q:'morna', r:'Não sei de cabeça. Primeiro me pergunta como eu decido o caminhão.'},
  {t:'Jonas, como você decide qual caminhão carrega primeiro e onde está cada carga ontem?', q:'ruim', r:'Ontem? Hoje é que importa. Ontem já foi carregado, moço.'},
  {t:'Jonas, como você decide qual navio carrega primeiro e onde está cada carga hoje?', q:'isca', r:'Navio é com o André. Eu decido caminhão.'}]},
 {etapa:'problema', dica:'Etapa 2, problema: procure onde dói, com as palavras dele.', chave:'grupo do celular', opcoes:[
  {t:'Quando a carga sai fora de ordem, como você sabe se o inventário ainda bate?', q:'boa', r:'Não sei de cabeça. Confiro no olho, e é no grupo do celular que a ordem muda.'},
  {t:'Quando a carga sai fora de ordem, quanto de produto some por safra, no total?', q:'morna', r:'Não sei a conta. Me pergunta primeiro de onde a ordem muda.'},
  {t:'Quando a carga sai fora de ordem, como você sabe se o inventário ainda bate no fim da semana?', q:'ruim', r:'Fim da semana? Eu confiro no fim do mês, moço, quando dá tempo.'},
  {t:'Quando a carga sai fora de ordem, como a portaria sabe se o caminhão ainda bate?', q:'isca', r:'Portaria é com a portaria. Eu cuido da carga no pátio.'}]},
 {etapa:'implicacao', dica:'Etapa 3, implicação: deixe ele dizer o que custa. Não diga você.', opcoes:[
  {t:'Pelo grupo do celular, quanto produto sai sem conta, e o que acontece depois?', q:'boa', r:'Não sei a conta. Sei que o inventário fecha no fim do mês, com fé. E fé não é número.'},
  {t:'Pelo grupo do celular, como a portaria registra o caminhão que entra?', q:'morna', r:'Portaria é com a portaria. Eu só sei da carga.'},
  {t:'Pelo grupo do celular, e o produto sai sem conta todo mês, o que acontece depois?', q:'ruim', r:'Sai, sim. Você já falou como se fosse certo.'},
  {t:'Pelo grupo do celular, quanto a sede gasta de energia no armazém?', q:'isca', r:'Energia é com a sede. Eu só conto caixa.'}]},
 {etapa:'proposta', dica:'Etapa 4, proposta: ligue a solução à dor que ele descreveu.', opcoes:[
  {t:'A ordem que sai do grupo do celular vira agenda no Operis YMS: a carga passa pelo check-in, sai no horário e o inventário do armazém confere sem fé.', q:'boa', r:'Pelo menos alguém pergunta como o caminhão sai. Vai ver a Paula, que quer o inventário fechado antes do dia 5.'},
  {t:'O Operis tem armazenagem, expedição, inventário, certificados de qualidade, painel de pátio e controle de acesso de portaria, tudo em tela única.', q:'erro', r:'Isso é catálogo. Eu quero saber quem sai primeiro.'},
  {t:'O TMS monitora a frota e o consumo de diesel de cada viagem, com roteirização, custo por quilômetro e controle de manutenção da carreta.', q:'erro', r:'Frota é com o Seu Tião e a Paula. Aqui é o caminhão que carrega.'}]}
],
custo: [
 {etapa:'situacao', dica:'Etapa 1, situação: pergunte sobre o trabalho dela. Deixe ela descrever.', opcoes:[
  {t:'Como vocês chegam ao custo da tonelada hoje, e de onde vêm os números?', q:'boa', r:'Da planilha de custo, versão sete. Os números vêm das áreas, uma de cada vez, e eu fecho na mão.'},
  {t:'Quanto a hora de máquina parada custa a tonelada, em média por safra?', q:'morna', r:'Esse número é com a manutenção, e não está fechado em nenhuma versão.'},
  {t:'Como vocês chegam ao custo da tonelada ontem, e de onde vêm os números?', q:'ruim', r:'Ontem? O custo fecha no mês. Hoje eu nem tenho a versão sete pronta.'},
  {t:'Como o RH chega ao custo da folha hoje, e de onde vêm os números?', q:'isca', r:'Folha é com o RH. Eu cuido da tonelada.'}]},
 {etapa:'problema', dica:'Etapa 2, problema: procure onde dói, com as palavras dela.', chave:'vinte dias', opcoes:[
  {t:'Quanto tempo depois da operação você consegue dizer quanto custou a tonelada?', q:'boa', r:'Uns vinte dias. Até lá a safra já mudou, o diesel subiu e o diretor já ligou três vezes.'},
  {t:'Quanto a usina perde por dia com essa tonelada sem custo?', q:'morna', r:'Não sei o número. Me pergunta primeiro quanto tempo leva, que eu ainda estou na versão sete.'},
  {t:'Quanto tempo depois da safra você consegue dizer quanto custou a tonelada?', q:'ruim', r:'Safra? A safra acaba depois. A operação é o que eu fecho em vinte dias.'},
  {t:'Quanto tempo depois da compra você consegue dizer quanto custou a tonelada?', q:'isca', r:'Compra é com a sede. Eu fecho a tonelada da operação.'}]},
 {etapa:'implicacao', dica:'Etapa 3, implicação: deixe ela dizer o que custa. Não diga você.', opcoes:[
  {t:'Se a decisão só chega ao custo em vinte dias, o que a usina perde de margem?', q:'boa', r:'Não sei quanto. Sei que a decisão vira retrovisor, e o diretor só vê o estrago.'},
  {t:'Se a decisão só chega ao custo em vinte dias, como a planilha de custo é montada?', q:'morna', r:'Montada por área, uma de cada vez. Mas quem fecha sou eu, na mão.'},
  {t:'Se a decisão só chega ao custo em vinte dias, e a margem já sumiu, o que a usina perde?', q:'ruim', r:'Sumiu, sim. Você já disse. Eu só fecho a versão sete.'},
  {t:'Se a decisão só chega ao custo em vinte dias, quanto a folha de pagamento pesa no mês?', q:'isca', r:'Folha é com o RH.'}]},
 {etapa:'proposta', dica:'Etapa 4, proposta: ligue a solução à dor que ela descreveu.', opcoes:[
  {t:'O custo que chega em vinte dias deixa de existir como v8 quando o SimpleFarm dá o custo gerencial por processo, recurso e produto, sem planilha no meio.', q:'boa', r:'Era isso. Agora entendo por que o diretor liga três vezes. Manda o número da operação e eu fecho a v8 com você.'},
  {t:'O SimpleFarm tem módulo de controladoria, com custos gerenciais e de produtos, relatórios em painel, exportação e integração com o ERP.', q:'erro', r:'Isso é o catálogo. Eu perguntei por que o número chega tarde.'},
  {t:'O HCM controla a folha, os encargos e o rateio por equipe, e a folha entra no custo da safra com a conta do mês fechada e a data de corte definida pela sede.', q:'erro', r:'Folha é do RH. O custo que me atrasa é o da frota e do diesel.'}]}
],
erp: [
 {etapa:'situacao', dica:'Etapa 1, situação: pergunte sobre o trabalho dele. Deixe ele descrever.', opcoes:[
  {t:'Como uma pesagem ou uma requisição chega ao ERP hoje?', q:'boa', r:'Eu pego a pesagem e digito no ERP. Depois pego o que o ERP diz e conto para a operação. Por telefone.'},
  {t:'Quanto de margem a usina perde quando uma pesagem chega ao ERP atrasada?', q:'morna', r:'Não sei. Primeiro me conta como ela chega, que é por telefone.'},
  {t:'Como uma pesagem ou uma requisição chega ao CRM hoje?', q:'ruim', r:'CRM? Não, moço, é o ERP. Por telefone.'},
  {t:'Como uma pesagem ou uma requisição chega à folha de pagamento hoje?', q:'isca', r:'Folha é com o RH. Eu só digito no ERP.'}]},
 {etapa:'problema', dica:'Etapa 2, problema: procure onde dói, com as palavras dele.', chave:'a ponte', opcoes:[
  {t:'O que hoje ainda é redigitado entre a operação e o ERP, e quem faz esse caminho?', q:'boa', r:'Requisição, pesagem, estoque, pagamento. Cada número redigitado passa pela ponte, e a ponte sou eu.'},
  {t:'Quanto de margem a operação perde por cada número redigitado no ERP?', q:'morna', r:'Não sei. Me pergunta primeiro quem redigita, que sou eu.'},
  {t:'O que hoje ainda é redigitado entre a operação e o CRM, e quem faz esse caminho?', q:'ruim', r:'CRM? Moço, é o ERP. A ponte é entre a operação e o ERP.'},
  {t:'O que hoje ainda é redigitado entre a operação e o ERP, e quem paga a conta de telefone?', q:'isca', r:'Conta de telefone é com a sede. Eu só digito.'}]},
 {etapa:'implicacao', dica:'Etapa 3, implicação: deixe ele dizer o que custa. Não diga você.', opcoes:[
  {t:'Se a ponte depende de uma pessoa, quanto de margem escapa entre a operação e o ERP?', q:'boa', r:'Não sei o número. Sei que, se o André fecha um navio hoje, eu só descubro amanhã.'},
  {t:'Se a ponte depende de uma pessoa, como o ERP registra cada pesagem que chega?', q:'morna', r:'Registra o que eu digito. Por telefone, como eu disse.'},
  {t:'Se a ponte depende de uma pessoa, e a margem já escapa, quanto de margem escapa?', q:'ruim', r:'Escapa, sim. Você já afirmou. Eu só sei que sou eu.'},
  {t:'Se a ponte depende de uma pessoa, quanto a sede gasta de telefone por mês?', q:'isca', r:'Telefone é com a sede. Eu só ligo para a operação.'}]},
 {etapa:'proposta', dica:'Etapa 4, proposta: ligue a solução à dor que ele descreveu.', opcoes:[
  {t:'Requisição, pesagem e estoque deixam de passar pela ponte por telefone quando a integração GAtec ao Senior ERP os leva sozinhos ao ERP.', q:'boa', r:'Enfim alguém pergunta da ponte. Me mostra o fluxo que eu quero ver o almoço.'},
  {t:'O Senior ERP tem módulos de compras, estoque, contabilidade e folha, com painel de indicadores, relatórios exportáveis e acesso por perfil de usuário.', q:'erro', r:'Isso é o catálogo. Eu perguntei de quem é o telefone.'},
  {t:'O CRM organiza a carteira de clientes, as oportunidades de venda e o funil do time comercial, com metas, painel e previsão por vendedor.', q:'erro', r:'CRM é com a área comercial. Eu tenho pesagem para integrar.'}]}
],
com: [
 {etapa:'situacao', dica:'Etapa 1, situação: pergunte sobre o trabalho dele. Deixe ele descrever.', opcoes:[
  {t:'André, quando você fecha um preço, onde ficam o contrato, o risco e o embarque?', q:'boa', r:'Preço fecho de cabeça. Risco eu controlo em três telas. O contrato está em algum lugar do e-mail.'},
  {t:'André, quanto de risco de preço a usina carrega quando você fecha um preço?', q:'morna', r:'Não sei. Primeiro me pergunta onde fica o contrato, que eu ainda estou no e-mail.'},
  {t:'André, quando você fecha um frete, onde ficam o contrato, o risco e o embarque?', q:'ruim', r:'Frete é com a transportadora, moço. Preço eu fecho de cabeça.'},
  {t:'André, quando você fecha um preço, onde ficam a folha, o risco e o embarque?', q:'isca', r:'Folha é com o RH. O contrato está no e-mail.'}]},
 {etapa:'problema', dica:'Etapa 2, problema: procure onde dói, com as palavras dele.', chave:'contrato no e-mail', opcoes:[
  {t:'Quando o preço fecha, em que ponto o contrato costuma aparecer para você?', q:'boa', r:'Só depois de achar no e-mail. O contrato no e-mail é a parte que eu não controlo de cabeça.'},
  {t:'Quando o preço fecha, quanto de risco a usina perde até o embarque?', q:'morna', r:'Não sei o número. Me pergunta primeiro onde o contrato some.'},
  {t:'Quando o preço fecha, em que ponto o contrato costuma aparecer para o diretor?', q:'ruim', r:'Para o diretor? Quem acha o contrato sou eu, no e-mail.'},
  {t:'Quando o preço fecha, em que ponto a sede costuma pagar a conta do frete?', q:'isca', r:'Frete é com a transportadora. O contrato é meu.'}]},
 {etapa:'implicacao', dica:'Etapa 3, implicação: deixe ele dizer o que custa. Não diga você.', opcoes:[
  {t:'Se cada contrato no e-mail fica sem achar, quanto de risco de preço a usina carrega?', q:'boa', r:'Não tenho a conta. Sei que é risco de preço que vai até o navio, e o diretor liga quando sai.'},
  {t:'Se cada contrato no e-mail fica sem achar, como o embarque é confirmado no navio?', q:'morna', r:'Confirmo no telefone, e o navio segue. Mas essa conta é do navio.'},
  {t:'Se cada contrato no e-mail fica sem achar, e o risco já sobra para a usina, quanto de risco sobra?', q:'ruim', r:'Sobra, sim. Você já disse. Não sei a conta.'},
  {t:'Se cada contrato no e-mail fica sem achar, quanto a folha pesa no custo do mês?', q:'isca', r:'Folha é com o RH. Eu só fecho contrato.'}]},
 {etapa:'proposta', dica:'Etapa 4, proposta: ligue a solução à dor que ele descreveu.', opcoes:[
  {t:'O contrato que fica no e-mail e o risco que fica com a usina cabem numa base só no Commerce, com frete e P&L até o embarque.', q:'boa', r:'Essa é a pergunta certa. Eu chuto, mas prefiro provar. Me manda o contrato e a gente vê.'},
  {t:'O Commerce tem Oneclick, trading, front office, pricing e painel de P&L, com módulos de contrato físico, frete e logística de transferência.', q:'erro', r:'Isso é lista de módulo. Eu quero saber onde está o contrato.'},
  {t:'O WMS organiza as ordens de movimentação do armazém, a expedição por doca e o inventário por lote, com leitura por coletor de dados.', q:'erro', r:'Armazém é do Jonas. Aqui é o porto, e o navio sai em dois dias.'}]}
]
};
PARADAS.forEach(p => { p.conversa = CONVERSAS[p.id]; });

// Easter eggs: escondidos pelo mapa. Não valem nota, valem história para contar no café.
const EASTER = [
  {id:'wiipo', x:73.2, z:13.4, y:0.95, n:'Cartão Wiipo perdido', d:'Alguém da controladoria esqueceu o cartão de benefícios em cima do arquivo. A Paula vai procurar a tarde inteira.'},
  {id:'capivara', x:-117, z:-29, y:0.5, n:'Capivara fiscal da safra', d:'Ela está aqui desde antes da usina. Fiscaliza tudo, não assina nada e nunca perdeu uma reunião.'},
  {id:'pasta', x:45.6, z:-16.2, y:0.4, n:'A pasta azul do Rui', d:'Estava no armazém, embaixo de um palete. O Rui vai querer te dar um abraço.'},
  {id:'caramelo', x:-116.8, z:-10.5, y:0.5, n:'Cachorro da portaria', d:'Caramelo, fiscal de portaria. Não tem crachá, mas confere todos.'},
  {id:'cafe', x:-28, z:12.8, y:0.9, n:'Garrafa térmica da oficina', d:'Café da oficina. Passado às 5h, forte o bastante para ligar o trator.'},
  {id:'dias', x:-92, z:-12.8, y:1.4, n:'Placa de dias sem acidente', d:'Dias sem acidente. O número é anotado a giz. O giz sumiu em março.'},
  {id:'cracha', x:-41.5, z:-8.8, y:1.2, n:'Crachá do safrista', d:'Crachá do safrista. Bateu ponto na entrada. A saída ninguém sabe.'}
];

// Mapa ponta a ponta (16/11): fases na ordem do fluxo oficial "Integração Senior x GATEC" (loop/manual/integracao.md).
// gatec e erp usam os nomes das atividades do fluxo; paradas são ids de PARADAS; agnosticas só entre as soluções agnósticas.
const PONTA_A_PONTA = [
  {id:'planejamento', nome:'Planejamento', gatec:['Planejamento / Orçamento Safra','Parametrizações'], erp:['Parametrizações','Cadastros'], conexao:'Cadastros e parametrizações do ERP dão a base do plano da safra.', paradas:['plan']},
  {id:'compras', nome:'Compras e estoque', gatec:['Requisitar Insumos / Materiais','Contratos de Compra / Embarques'], erp:['Requisição de Compra','Ordem de Compra','Documento / Nota Fiscal de Entrada'], conexao:'Uma OS de manutenção pede a peça: ela sai do estoque ou vira solicitação de compra no ERP.', paradas:['auto','erp'], agnosticas:['WMS']},
  {id:'producao', nome:'Produção e pesagem', gatec:['Apontar Peso Previsto / Real','Baixar / Consumir / Estornar Insumos e Materiais','Operis YMS (fila de pátio)'], erp:['Movimentação de Estoque','Saldo Estoque / Saldo Série/Lote'], conexao:'Peso e consumo de insumo viram movimentação de estoque no ERP.', paradas:['geo','agri','orig','ind'], agnosticas:['Gestão de Frotas','Gestão de Acesso e Segurança']},
  {id:'venda', nome:'Venda e saída', gatec:['Contratos de Venda / Embarques','Pedido de Venda','Pesagem / Balança','Operis YMS (fila de pátio)'], erp:['Pedido de Venda','Nota Fiscal de Saída','eDocs / CT-e'], conexao:'Pedido e pesagem do GAtec alimentam pedido e nota fiscal no ERP.', paradas:['com','arm'], agnosticas:['CRM','TMS']},
  {id:'financeiro', nome:'Financeiro', gatec:['Lançar Despesas / Taxas','Adiantamento / Antecipação'], erp:['Títulos do Contas a Pagar','Título do Contas a Receber'], conexao:'Despesas do campo viram contas a pagar; antecipações, contas a receber.', paradas:['erp']},
  {id:'custos', nome:'Custos e contabilidade', gatec:['Lançar Custos Diretos e Indiretos','Distribuição de Custos Agrícolas'], erp:['Rateios e Lançamentos Contábeis','Saldo Contábil das Contas'], conexao:'O saldo contábil volta ao campo como custo por talhão e cultura.', paradas:['custo'], agnosticas:['HCM']}
];
