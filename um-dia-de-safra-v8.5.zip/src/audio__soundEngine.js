// === audio/soundEngine.js ===
// Motor de áudio sintetizado com Web Audio API. Nenhum arquivo de áudio: tudo sai de osciladores,
// ruído filtrado, envelopes e amostras geradas em JS (Karplus-Strong para as cordas da viola).
// Camadas: trilha caipira (Lá maior, 16 compassos), ambiente por zona (panorama e distância),
// base de campo (vento, pássaros, grilos), sons de interação e toque de ligação.
const CHAVE_MUSICA = 'safra_musica';

// Progressão de 16 compassos em Lá maior. r = raiz em MIDI; m = acorde menor.
const ACORDES = {
  A: { r: 57, m: false }, D: { r: 50, m: false }, E: { r: 52, m: false },
  Fm: { r: 54, m: true }, Bm: { r: 59, m: true }
};
const PROGRESSAO = ['A', 'D', 'E', 'A', 'Fm', 'D', 'E', 'A', 'D', 'A', 'Bm', 'E', 'A', 'D', 'E', 'A'];
// Padrão de arpejo da viola por colcheia (índices em T, ver musicaPasso)
const PADRAO_VIOLA = [0, 2, 4, 2, 1, 3, 4, 2];
// Andamento por ato: amanhecer e dia cheio em 84; fim de tarde mais lento
const BPM_ATO = { 1: 84, 2: 84, 3: 76 };
// Ganho geral do mestre: volume (0-1) x GANHO_MESTRE. Calibrado para RMS ~0,04-0,06 e pico < 0,7.
const GANHO_MESTRE = 1.6;
const DIST_MAX = 55;      // m: além disso a zona fica muda
const FONTES_MAX = 6;     // zonas de áudio ao mesmo tempo

// Construtores de cada zona (ids de PARADAS). Recebem o motor e o barramento da zona.
// Cada um devolve { ev(zona, horizonte) } para os eventos rítmicos ou {} para sons contínuos.
const CONSTRUTORES = {
  // Sede: rádio de pilha com a trilha, chiado e ventilador
  plan(E, dest) {
    E.radio(dest, 1.1, 1100, 0.8);
    E.ruido('highpass', 4000, 0.5, dest, 0.004);
    const v = E.ruido('lowpass', 420, 0.7, dest, 0.02);
    E.lfo(v.gain, 2.1, 0.005, 'sine');
    E.osc('sine', 118, dest, 0.006);
    return {};
  },
  // Talhão 12: farfalhar de canavial, zumbido distante, folha que estala de vez em quando
  geo(E, dest) {
    const cana = E.ruido('bandpass', 2600, 0.45, dest, 0.03);
    E.lfo(cana.gain, 0.35, 0.012, 'sine');
    E.ruido('highpass', 1200, 0.3, dest, 0.006);
    E.osc('sine', 110, dest, 0.012);
    E.osc('sine', 111.7, dest, 0.01);
    return {
      ev: (z, h) => E.cad(z, 'f', h, 3.5, 9, t => E.clique(dest, t, 2400 + Math.random() * 1500, 0.5 + Math.random() * 0.4, 0.02, 'bandpass', 0.7))
    };
  },
  // Frente de colheita: colhedora (diesel pulsante e corte ritmado) e transbordo
  agri(E, dest) {
    E.motor(38, 9, 0.05, dest, 170);
    E.ruido('bandpass', 1800, 0.5, dest, 0.012);
    E.motor(29, 3, 0.02, dest, 220);
    return {
      ev: (z, h) => {
        E.cad(z, 'corte', h, 0.24, 0.27, t => E.clique(dest, t, 3200, 0.05, 0.03, 'bandpass', 1.5));
        E.cad(z, 'tomba', h, 1.6, 3.8, t => E.impacto(dest, t, 900, 0.14, 0.05));
      }
    };
  },
  // Oficina: compressor de ar ciclando, marteladas, chave de impacto e rádio AM
  auto(E, dest) {
    const comp = E.ruido('bandpass', 1200, 1.2, dest, 0);
    E.radio(dest, 0.35, 800, 1.5);
    return {
      ev: (z, h) => {
        E.cad(z, 'comp', h, 9, 12, t => {
          comp.gain.setTargetAtTime(0.03, t, 0.3);
          comp.gain.setTargetAtTime(0.0, t + 4, 0.3);
        });
        E.cad(z, 'martelo', h, 1.2, 3.5, t => E.sino(dest, t, 1800, 0.14, 0.03));
        E.cad(z, 'chave', h, 11, 22, t => {
          for (let i = 0; i < 8; i++) E.clique(dest, t + i * 0.07, 900, 0.05, 0.03, 'bandpass', 0.6);
        });
      }
    };
  },
  // Balança: caminhão em marcha lenta, bips, impressora de ticket, cancela e campainha de senha
  orig(E, dest) {
    E.motor(30, 7, 0.035, dest, 150);
    E.ruido('lowpass', 300, 0.5, dest, 0.02);
    return {
      ev: (z, h) => {
        E.cad(z, 'bip', h, 3.2, 6, t => { E.bip(dest, t, 2200, 0.07, 0.035); E.bip(dest, t + 0.14, 2200, 0.07, 0.035); });
        E.cad(z, 'ticket', h, 9, 14, t => { for (let i = 0; i < 14; i++) E.clique(dest, t + i * 0.04, 3500, 0.02, 0.02, 'bandpass', 2); });
        E.cad(z, 'cancela', h, 18, 30, t => { E.bip(dest, t, 700, 0.5, 0.012, 'sawtooth'); E.impacto(dest, t + 0.5, 260, 0.12, 0.04); });
        E.cad(z, 'senha', h, 14, 25, t => E.sino(dest, t, 1320, 1.0, 0.025));
      }
    };
  },
  // Indústria: moenda (ronco grave), vapor em rajadas e esteira
  ind(E, dest) {
    E.motor(52, 2.4, 0.06, dest, 260);
    E.motor(26, 2.4, 0.04, dest, 120);
    E.ruido('bandpass', 900, 1.2, dest, 0.01);
    return {
      ev: (z, h) => E.cad(z, 'vapor', h, 4, 8, t => E.clique(dest, t, 4500, 1.2, 0.012, 'highpass', 0.4))
    };
  },
  // Armazém: empilhadeira com bip de ré e pancada de palete
  arm(E, dest) {
    E.motor(70, 11, 0.02, dest, 220);
    return {
      ev: (z, h) => {
        E.cad(z, 're', h, 1.1, 1.3, t => E.bip(dest, t, 1000, 0.05, 0.012, 'square'));
        E.cad(z, 'palete', h, 7, 14, t => { E.impacto(dest, t, 70, 0.18, 0.08); E.clique(dest, t, 3000, 0.02, 0.04); });
      }
    };
  },
  // Controladoria: ar-condicionado, teclado, impressora e o "plim" de erro de planilha
  custo(E, dest) {
    E.ruido('lowpass', 500, 0.5, dest, 0.02);
    E.osc('sine', 97, dest, 0.006);
    return {
      ev: (z, h) => {
        E.cad(z, 'teclado', h, 2.5, 5, t => { for (let i = 0; i < 12; i++) E.clique(dest, t + i * 0.065 + Math.random() * 0.02, 3000, 0.03, 0.015, 'bandpass', 2); });
        E.cad(z, 'impressora', h, 14, 20, t => { for (let i = 0; i < 18; i++) E.clique(dest, t + i * 0.05, 2200, 0.03, 0.02, 'bandpass', 1.5); });
        E.cad(z, 'plim', h, 16, 30, t => { E.bip(dest, t, 1200, 0.22, 0.02); E.bip(dest, t + 0.1, 660, 0.14, 0.018, 'triangle'); });
      }
    };
  },
  // Centro de gestão: telefones tocando, toque de celular e zumbido de servidor
  erp(E, dest) {
    E.osc('sine', 120, dest, 0.006);
    E.osc('sine', 240, dest, 0.003);
    E.ruido('lowpass', 300, 0.5, dest, 0.012);
    return {
      ev: (z, h) => {
        E.cad(z, 'telefone', h, 22, 38, t => E.toque(dest, t, 0.03));
        E.cad(z, 'celular', h, 12, 20, t => { E.bip(dest, t, 1980, 0.09, 0.02, 'triangle'); E.bip(dest, t + 0.12, 2640, 0.09, 0.018, 'triangle'); });
      }
    };
  },
  // Porto: água batendo, guindaste, buzina grave de navio ao longe e gaivota
  com(E, dest) {
    const agua = E.ruido('bandpass', 600, 0.4, dest, 0.04);
    E.lfo(agua.gain, 0.12, 0.02, 'sine');
    E.motor(60, 0, 0.012, dest, 200);
    return {
      ev: (z, h) => {
        E.cad(z, 'buzina', h, 45, 75, t => E.buzina(dest, t));
        E.cad(z, 'gaivota', h, 15, 30, t => { if (Math.random() < 0.6) E.varre(dest, t, 1900, 2700, 0.5, 0.02, 'sine'); });
        E.cad(z, 'guindaste', h, 20, 35, t => E.varre(dest, t, 300, 900, 0.6, 0.012, 'sawtooth'));
      }
    };
  }
};

class SoundEngine {
  constructor() {
    this.ctx = null;
    this.master = null;
    this.enabled = true;
    this.volume = 0.9;
    this.stepTimer = 0;
    this.musica = true;
    try { this.musica = localStorage.getItem(CHAVE_MUSICA) !== '0'; } catch {}
    this.iniciado = false;
    this.ato = 1;
    this.fimAnterior = false;
    this.ksCache = new Map();
    this.nosAvulsos = 0;
    this._coleta = null;
    this._pe = false;
    this._buf = null;
    this.zonas = PARADAS.map(p => ({
      id: p.id, nome: p.lugar, x: p.x, z: p.nz, nodes: [], montada: false,
      bus: null, pan: null, ev: null, ganhoAlvo: 0, construtor: CONSTRUTORES[p.id]
    }));
    this.ativas = [];
    this.campo = null;
    this.musicaProx = 0;
    this.musicaPasso = 0;
    this.variacao = 0;
    window.__SAFRA_AUDIO__ = {
      estado: () => this.estado(),
      fontesAtivas: () => this.fontesAtivas(),
      setMusica: on => this.setMusica(on),
      nivel: () => this.medir('rms'),
      pico: () => this.medir('pico')
    };
  }

  init() {
    if (this.ctx) return;
    try {
      const AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return;
      const c = (this.ctx = new AC());
      // Cadeia: master -> limitador -> analisador -> saída
      this.master = c.createGain();
      this.master.gain.value = this.enabled ? this.volume * GANHO_MESTRE : 0;
      const limitador = c.createDynamicsCompressor();
      limitador.threshold.value = -12;
      limitador.knee.value = 6;
      limitador.ratio.value = 12;
      limitador.attack.value = 0.003;
      limitador.release.value = 0.25;
      this.analisador = c.createAnalyser();
      this.analisador.fftSize = 2048;
      this.master.connect(limitador).connect(this.analisador).connect(c.destination);

      // Barramentos: ambiente (zonas e campo), música (voz -> ducking -> liga/desliga) e efeitos
      this.busAmbiente = c.createGain();
      this.busAmbiente.connect(this.master);
      this.busVozes = c.createGain();
      this.busVozes.gain.value = 0.5;
      this.busDuck = c.createGain();
      this.busLiga = c.createGain();
      this.busLiga.gain.value = this.musica ? 1 : 0;
      this.busVozes.connect(this.busDuck).connect(this.busLiga).connect(this.master);
      this.busSfx = c.createGain();
      this.busSfx.gain.value = 0.6;
      this.busSfx.connect(this.master);

      // Ruído branco de 2 s reutilizado por todas as fontes de ruído
      this.ruidoBuf = c.createBuffer(1, c.sampleRate * 2, c.sampleRate);
      const d = this.ruidoBuf.getChannelData(0);
      for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;

      this.campoMontar();
      this.timer = setInterval(() => this.agenda(), 50);
      document.addEventListener('visibilitychange', () => {
        if (!this.ctx) return;
        if (document.hidden) this.ctx.suspend().catch(() => {});
        else if (this.iniciado && this.enabled) this.ctx.resume().catch(() => {});
      });
    } catch (e) {
      console.warn('audio: init falhou', e);
      this.ctx = null;
    }
  }

  resume() {
    if (!this.ctx) this.init();
    this.iniciado = true;
    if (this.ctx && this.ctx.state === 'suspended' && !document.hidden) {
      this.ctx.resume().catch(() => {});
    }
  }

  setConfig(enabled, volume) {
    this.enabled = enabled;
    this.volume = volume;
    if (this.master && this.ctx) {
      this.master.gain.setTargetAtTime(enabled ? volume * GANHO_MESTRE : 0, this.ctx.currentTime, 0.06);
    }
  }

  setMusica(on) {
    this.musica = !!on;
    if (this.ctx) this.busLiga.gain.setTargetAtTime(this.musica ? 1 : 0, this.ctx.currentTime, 0.08);
    try { localStorage.setItem(CHAVE_MUSICA, this.musica ? '1' : '0'); } catch {}
    return this.musica;
  }

  toggleMusica() {
    return this.setMusica(!this.musica);
  }

  // ---------- Ponto de ligação por frame (main.js) ----------
  // cena: { yaw, ato, on, duck, fim } vindos do jogo
  updateSpatial(playerX, playerZ, moving, running, dt, cena) {
    if (this.ctx && this.enabled) this.espacial(playerX, playerZ, cena || {});

    // Passos
    if (moving) {
      this.stepTimer -= dt * (running ? 1.55 : 1.0);
      if (this.stepTimer <= 0) {
        this.stepTimer = 0.44;
        this.playStep(playerX > -6 && Math.abs(playerZ) > 5);
      }
    } else {
      this.stepTimer = 0.08;
    }
  }

  espacial(px, pz, cena) {
    const c = this.ctx, t = c.currentTime;
    const yaw = cena.yaw || 0;
    this.ato = cena.ato || 1;
    const ligado = cena.on !== false;

    // Ducking: música abaixa em diálogo e mais ainda na ligação final
    const duck = cena.fim && cena.duck ? 0.2 : cena.duck ? 0.35 : 1;
    this.busDuck.gain.setTargetAtTime(duck, t, 0.35);
    if (cena.fim && !this.fimAnterior) this.toqueLigacao();
    this.fimAnterior = !!cena.fim;

    this.campo.out.gain.setTargetAtTime(ligado ? 1 : 0, t, 0.6);

    // As FONTES_MAX zonas mais próximas, dentro de DIST_MAX
    const ord = [];
    if (ligado) {
      for (const z of this.zonas) {
        const ox = z.x - px, oz = z.z - pz, d = Math.hypot(ox, oz);
        if (d < DIST_MAX) ord.push({ z, d, ox, oz });
      }
      ord.sort((a, b) => a.d - b.d);
      ord.length = Math.min(ord.length, FONTES_MAX);
    }
    const escolhidas = new Set(ord.map(o => o.z));
    for (const z of this.zonas) if (z.montada && !escolhidas.has(z)) this.desmontar(z);
    for (const o of ord) if (!o.z.montada) this.montar(o.z);
    this.ativas = ord;

    // Panorama e ganho: eixo direito e frontal da câmera (WASD usa o mesmo yaw)
    const fx = -Math.sin(yaw), fz = -Math.cos(yaw), rx = Math.cos(yaw), rz = -Math.sin(yaw);
    for (const o of ord) {
      const d = o.d || 1e-3;
      const ganho = Math.pow(Math.max(0, 1 - o.d / DIST_MAX), 1.5);
      const frente = (o.ox * fx + o.oz * fz) / d;             // -1 atrás, +1 na frente
      const costas = 0.6 + 0.4 * (frente + 1) / 2;            // atrás da câmera soa mais baixo
      const lado = (o.ox * rx + o.oz * rz) / d;                // -1 esquerda, +1 direita
      o.z.ganhoAlvo = ganho * costas;
      o.z.bus.gain.setTargetAtTime(o.z.ganhoAlvo, t, 0.2);
      o.z.pan.pan.setTargetAtTime(Math.max(-0.9, Math.min(0.9, lado * 0.9)), t, 0.2);
    }
  }

  montar(z) {
    const c = this.ctx;
    z.montada = true;
    z.nodes = [];
    this._coleta = z.nodes;
    z.bus = this.reg(c.createGain());
    z.bus.gain.value = 0;
    z.pan = this.reg(c.createStereoPanner());
    z.bus.connect(z.pan).connect(this.busAmbiente);
    const b = z.construtor ? z.construtor(this, z.bus) : null;
    this._coleta = null;
    z.ev = b && b.ev ? b.ev : null;
  }

  desmontar(z) {
    if (!z.montada) return;
    z.montada = false;
    z.ev = null;
    z.ganhoAlvo = 0;
    z.bus.gain.setTargetAtTime(0, this.ctx.currentTime, 0.1);
    const velhos = z.nodes;
    z.nodes = [];
    setTimeout(() => {
      for (const n of velhos) {
        try { if (n._de) n._de.disconnect(n); } catch {}
        try { if (n.stop && !n._parado) n.stop(); } catch {}
        try { n.disconnect(); } catch {}
      }
    }, 700);
  }

  // Agendador: roda a cada 50 ms e preenche os eventos até 0,3 s à frente
  agenda() {
    const c = this.ctx;
    if (!c || c.state !== 'running') return;
    try {
      const h = c.currentTime + 0.3;
      for (const z of this.zonas) if (z.montada && z.ev) z.ev(z, h);
      if (this.campo) this.campoEv(h);
      this.musicaAgenda(h);
    } catch (e) {
      if (!this._errou) { this._errou = true; console.warn('audio:', e); }
    }
  }

  // ---------- Construtores de nós (registram para descarte) ----------
  reg(n) {
    if (this._coleta) this._coleta.push(n);
    return n;
  }

  conta(src) {
    this.nosAvulsos++;
    src.onended = () => { this.nosAvulsos--; };
  }

  cad(obj, k, h, min, max, fn) {
    const t = this.ctx.currentTime;
    if (obj[k] === undefined || obj[k] < t) obj[k] = t + 0.05;
    while (obj[k] < h) {
      fn(obj[k]);
      obj[k] += min + Math.random() * (max - min);
    }
  }

  ruido(tipo, freq, q, dest, ganho = 1) {
    const c = this.ctx;
    const s = this.reg(c.createBufferSource());
    s.buffer = this.ruidoBuf;
    s.loop = true;
    const f = this.reg(c.createBiquadFilter());
    f.type = tipo; f.frequency.value = freq; f.Q.value = q;
    const g = this.reg(c.createGain());
    g.gain.value = ganho;
    s.connect(f).connect(g).connect(dest);
    s.start(0, Math.random() * 1.5);
    return g;
  }

  osc(tipo, freq, dest, ganho = 1) {
    const c = this.ctx;
    const o = this.reg(c.createOscillator());
    o.type = tipo; o.frequency.value = freq;
    const g = this.reg(c.createGain());
    g.gain.value = ganho;
    o.connect(g).connect(dest);
    o.start();
    return g;
  }

  // LFO ligado a um parâmetro (AM ou vibrato lento)
  lfo(param, freq, amp, tipo = 'sine') {
    const c = this.ctx;
    const o = this.reg(c.createOscillator());
    o.type = tipo; o.frequency.value = freq;
    const g = this.reg(c.createGain());
    g.gain.value = amp;
    o.connect(g).connect(param);
    o.start();
  }

  // Motor: dente de serra grave filtrado, com pulsação de cilindros
  motor(freq, pulso, ganho, dest, corte = 170) {
    const c = this.ctx;
    const o = this.reg(c.createOscillator());
    o.type = 'sawtooth'; o.frequency.value = freq;
    const f = this.reg(c.createBiquadFilter());
    f.type = 'lowpass'; f.frequency.value = corte;
    const g = this.reg(c.createGain());
    g.gain.value = ganho;
    o.connect(f).connect(g).connect(dest);
    o.start();
    if (pulso) this.lfo(g.gain, pulso, ganho * 0.5, 'triangle');
    return g;
  }

  // Rádio: a trilha passa por um passa-banda estreito ("rádio de pilha" ou AM)
  radio(dest, ganho, freq, q) {
    const c = this.ctx;
    const f = this.reg(c.createBiquadFilter());
    f.type = 'bandpass'; f.frequency.value = freq; f.Q.value = q;
    f._de = this.busDuck;
    this.busDuck.connect(f);
    const g = this.reg(c.createGain());
    g.gain.value = ganho;
    f.connect(g).connect(dest);
    return g;
  }

  // ---------- Sons curtos (disparos, sem nó persistente) ----------
  clique(dest, t, freq, dur, ganho, tipo = 'bandpass', q = 1) {
    const c = this.ctx;
    const s = c.createBufferSource();
    s.buffer = this.ruidoBuf;
    const f = c.createBiquadFilter();
    f.type = tipo; f.frequency.value = freq; f.Q.value = q;
    const g = c.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(ganho, t + 0.003);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    s.connect(f).connect(g).connect(dest);
    s.start(t, Math.random() * 1.4, dur + 0.02);
    this.conta(s);
  }

  impacto(dest, t, freq, dur, ganho) {
    const c = this.ctx;
    const o = c.createOscillator();
    o.type = 'sine';
    o.frequency.setValueAtTime(freq, t);
    o.frequency.exponentialRampToValueAtTime(Math.max(20, freq * 0.45), t + dur);
    const g = c.createGain();
    g.gain.setValueAtTime(ganho, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g).connect(dest);
    o.start(t); o.stop(t + dur + 0.02);
    this.conta(o);
  }

  bip(dest, t, freq, dur, ganho, tipo = 'sine') {
    const c = this.ctx;
    const o = c.createOscillator();
    o.type = tipo; o.frequency.value = freq;
    const g = c.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(ganho, t + 0.005);
    g.gain.setValueAtTime(ganho, t + Math.max(0.01, dur - 0.02));
    g.gain.linearRampToValueAtTime(0.0001, t + dur);
    o.connect(g).connect(dest);
    o.start(t); o.stop(t + dur + 0.02);
    this.conta(o);
  }

  // Varredura de frequência (gaivota, rangido de guindaste)
  varre(dest, t, f0, f1, dur, ganho, tipo) {
    const c = this.ctx;
    const o = c.createOscillator();
    o.type = tipo;
    o.frequency.setValueAtTime(f0, t);
    o.frequency.linearRampToValueAtTime(f1, t + dur);
    const g = c.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(ganho, t + dur * 0.3);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g).connect(dest);
    o.start(t); o.stop(t + dur + 0.02);
    this.conta(o);
  }

  // Sino com parciais inarmônicas (martelo em metal, campainha de senha, plim)
  sino(dest, t, freq, dur, ganho) {
    [[1, 1], [2.76, 0.35], [5.4, 0.18]].forEach(([r, a]) => {
      this.impacto(dest, t, freq * r, dur, ganho * a);
    });
  }

  // Toque de telefone: dois pares de trinados de 0,35 s
  toque(dest, t, ganho) {
    for (const dt of [0, 0.5]) {
      for (const fr of [440, 480]) {
        const c = this.ctx, o = c.createOscillator(), g = c.createGain();
        o.frequency.value = fr;
        g.gain.setValueAtTime(0.0001, t + dt);
        g.gain.linearRampToValueAtTime(ganho, t + dt + 0.02);
        g.gain.setValueAtTime(ganho, t + dt + 0.33);
        g.gain.linearRampToValueAtTime(0.0001, t + dt + 0.35);
        o.connect(g).connect(dest);
        o.start(t + dt); o.stop(t + dt + 0.37);
        this.conta(o);
      }
    }
  }

  // Buzina grave de navio ao longe
  buzina(dest, t) {
    const c = this.ctx;
    const f = c.createBiquadFilter();
    f.type = 'lowpass'; f.frequency.value = 900;
    const g = c.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(0.05, t + 0.5);
    g.gain.setValueAtTime(0.05, t + 2.0);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 2.6);
    f.connect(g).connect(dest);
    for (const fr of [58, 87.5]) {
      const o = c.createOscillator();
      o.type = 'sawtooth'; o.frequency.value = fr;
      o.connect(f);
      o.start(t); o.stop(t + 2.7);
      this.conta(o);
    }
  }

  // ---------- Base de campo: vento contínuo, pássaros de manhã, grilos e cigarras ao fim da tarde ----------
  campoMontar() {
    const c = this.ctx;
    this._coleta = [];
    const out = this.reg(c.createGain());
    out.gain.value = 1;
    out.connect(this.busAmbiente);
    const vento = this.ruido('bandpass', 380, 0.5, out, 0.05);
    this.lfo(vento.gain, 0.09, 0.03, 'sine');
    // grilos: tom agudo em tremolo; o ganho geral muda por ato
    const grilo = this.reg(c.createGain());
    grilo.gain.value = 0;
    grilo.connect(out);
    const tom = this.reg(c.createOscillator());
    tom.type = 'sine'; tom.frequency.value = 4300;
    const gAM = this.reg(c.createGain());
    gAM.gain.value = 0.25;
    tom.connect(gAM).connect(grilo);
    tom.start();
    this.lfo(gAM.gain, 16, 0.25, 'triangle');
    this.campo = { out, grilo, nodes: this._coleta, nx: undefined };
    this._coleta = null;
  }

  campoEv(h) {
    const c = this.ctx, t = c.currentTime;
    const camp = this.campo;
    camp.grilo.gain.setTargetAtTime(this.ato === 3 ? 0.035 : this.ato === 2 ? 0.01 : 0, t, 0.8);
    const taxa = this.ato === 1 ? 0.7 : this.ato === 2 ? 0.2 : 0.05;
    this.cad(camp, 'passaro', h, 0.6, 2.6, t0 => {
      if (Math.random() < taxa) this.passaro(t0);
    });
  }

  passaro(t0) {
    const c = this.ctx;
    const pan = this.reg(c.createStereoPanner());
    pan.pan.value = Math.random() * 1.6 - 0.8;
    pan.connect(this.campo.out);
    const n = 2 + Math.floor(Math.random() * 3);
    const base = 2600 + Math.random() * 2000;
    let t = t0;
    for (let i = 0; i < n; i++) {
      const o = c.createOscillator(), g = c.createGain();
      o.type = 'sine';
      const f0 = base * (0.85 + Math.random() * 0.3), f1 = f0 * (1.15 + Math.random() * 0.5);
      o.frequency.setValueAtTime(f0, t);
      o.frequency.exponentialRampToValueAtTime(f1, t + 0.05);
      g.gain.setValueAtTime(0.0001, t);
      g.gain.exponentialRampToValueAtTime(0.035, t + 0.012);
      g.gain.exponentialRampToValueAtTime(0.0001, t + 0.07);
      o.connect(g).connect(pan);
      o.start(t); o.stop(t + 0.09);
      this.conta(o);
      t += 0.09 + Math.random() * 0.08;
    }
    setTimeout(() => { try { pan.disconnect(); } catch {} }, (t - t0 + 0.3) * 1000);
  }

  // ---------- Trilha: viola caipira (Karplus-Strong), baixo e chocalho ----------
  // Amostra de corda gerada uma vez por nota e guardada em cache
  ksBuffer(midi) {
    let b = this.ksCache.get(midi);
    if (b) return b;
    const c = this.ctx, sr = c.sampleRate;
    const f = 440 * Math.pow(2, (midi - 69) / 12);
    const N = Math.max(2, Math.round(sr / f)), L = Math.floor(sr * 1.5);
    b = c.createBuffer(1, L, sr);
    const d = b.getChannelData(0);
    for (let i = 0; i < N; i++) d[i] = Math.random() * 2 - 1;
    for (let i = 1; i < N; i++) d[i] = 0.5 * (d[i] + d[i - 1]); // ataque macio, sem chiado
    const g = 0.99992; // queda por amostra: a corda soa uns 1,5 s
    for (let i = N; i < L; i++) {
      const atras = i - N - 1 >= 0 ? d[i - N - 1] : 0;
      d[i] = g * 0.5 * (d[i - N] + atras);
    }
    let p = 0;
    for (let i = 0; i < L; i++) p = Math.max(p, Math.abs(d[i]));
    if (p > 0) for (let i = 0; i < L; i++) d[i] *= 0.9 / p;
    this.ksCache.set(midi, b);
    return b;
  }

  pluck(midi, ganho, t, dest) {
    const c = this.ctx;
    const s = c.createBufferSource();
    s.buffer = this.ksBuffer(midi);
    const g = c.createGain();
    g.gain.value = ganho;
    s.connect(g).connect(dest || this.busSfx);
    s.start(t);
    this.conta(s);
  }

  baixo(midi, t, ganho) {
    const c = this.ctx, f = 440 * Math.pow(2, (midi - 69) / 12);
    const g = c.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(ganho, t + 0.012);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 0.9);
    g.connect(this.busVozes);
    for (const [tipo, a] of [['sine', 1], ['triangle', 0.25]]) {
      const o = c.createOscillator(), ga = c.createGain();
      o.type = tipo; o.frequency.value = f;
      ga.gain.value = a;
      o.connect(ga).connect(g);
      o.start(t); o.stop(t + 0.95);
      this.conta(o);
    }
  }

  musicaAgenda(h) {
    const c = this.ctx, t = c.currentTime;
    if (this.musicaProx < t - 0.3) this.musicaProx = t + 0.05;
    while (this.musicaProx < h) {
      if (this.musica) this.musicaNota(this.musicaProx, this.musicaPasso);
      this.musicaProx += 60 / (BPM_ATO[this.ato] || 84) / 4;
      this.musicaPasso++;
    }
  }

  // Uma semicolcheia da trilha. Compasso = 16 passos; laço de 16 compassos.
  musicaNota(t, s) {
    const pos = s % 16, bar = Math.floor(s / 16) % 16;
    if (bar === 0 && pos === 0) this.variacao = Math.random(); // nova volta do laço: pequena variação
    const ac = ACORDES[PROGRESSAO[bar]];
    const r = ac.r, th = ac.m ? 3 : 4;
    const T = [r, r + th, r + 7, r + 12, r + 12 + th, r + 19];
    const ato = this.ato, bus = this.busVozes;

    // Viola: rasgueado no tempo 1 e arpejo nas colcheias (dia cheio) ou só nos tempos 1 e 3 (amanhecer)
    if (pos === 0 && (ato !== 1 || Math.random() < 0.8)) {
      [0, 1, 2, 3].forEach((k, i) => this.pluck(T[k] + (this.variacao > 0.85 ? 12 : 0), 0.2, t + i * 0.018, bus));
    } else if (pos % 2 === 0 && ato !== 1) {
      if (Math.random() > 0.12) this.pluck(T[PADRAO_VIOLA[pos / 2]], pos % 4 === 0 ? 0.18 : 0.13, t, bus);
    } else if (ato === 1 && pos === 8 && Math.random() < 0.7) {
      this.pluck(T[PADRAO_VIOLA[4]], 0.16, t, bus);
    }

    // Baixo: raiz nos tempos 1 e 3, quinta ou passagem de vez em quando
    const b = r - 12;
    if (pos === 0 && Math.random() < (ato === 1 ? 0.7 : 0.95)) this.baixo(b, t, 0.15);
    if (pos === 8 && ato !== 1) this.baixo(Math.random() < 0.5 ? b + 7 : b, t, 0.1);
    if (pos === 12 && ato === 2 && Math.random() < 0.25) this.baixo(b + (Math.random() < 0.5 ? 2 : 4), t, 0.07);

    // Chocalho e pandeiro suave: fora no amanhecer
    if (ato !== 1 && pos % 2 === 0 && Math.random() > 0.15) {
      this.clique(bus, t, 7000, 0.035, pos % 4 === 2 ? 0.03 : 0.016, 'bandpass', 0.8);
    }
    if (ato !== 1 && (pos === 4 || pos === 12) && Math.random() < (ato === 2 ? 0.6 : 0.4)) {
      this.clique(bus, t, 1200, 0.07, 0.035, 'bandpass', 3);
      this.impacto(bus, t, 230, 0.06, 0.018);
    }
  }

  // ---------- Medição e estado (teste) ----------
  medir(tipo) {
    if (!this.analisador) return 0;
    if (!this._buf) this._buf = new Float32Array(this.analisador.fftSize);
    this.analisador.getFloatTimeDomainData(this._buf);
    let soma = 0, pico = 0;
    for (const v of this._buf) {
      soma += v * v;
      const a = Math.abs(v);
      if (a > pico) pico = a;
    }
    return tipo === 'pico' ? pico : Math.sqrt(soma / this._buf.length);
  }

  contarNos() {
    let n = this.nosAvulsos;
    for (const z of this.zonas) if (z.montada) n += z.nodes.length;
    if (this.campo) n += this.campo.nodes.length;
    return n;
  }

  fontesAtivas() {
    return this.ativas.map(o => ({ zona: o.z.nome, dist: Math.round(o.d), ganho: +o.z.ganhoAlvo.toFixed(3) }));
  }

  estado() {
    return {
      contexto: this.ctx ? this.ctx.state : 'sem contexto',
      musica: this.musica,
      ato: this.ato,
      bpm: BPM_ATO[this.ato] || 84,
      ducking: this.busDuck ? +this.busDuck.gain.value.toFixed(2) : null,
      ligacao: this.fimAnterior,
      fontes: this.ativas.length,
      nos: this.contarNos()
    };
  }

  // ---------- Sons de interação (chamados pelo jogo) ----------
  playStep(onConcrete) {
    if (!this.ctx || !this.enabled) return;
    const t = this.ctx.currentTime;
    this._pe = !this._pe; // pé direito e esquerdo com timbres ligeiramente diferentes
    if (onConcrete) {
      this.clique(this.busSfx, t, this._pe ? 1500 : 1300, 0.06, 0.03, 'bandpass', 1.5);
    } else {
      this.clique(this.busSfx, t, this._pe ? 640 : 560, 0.09, 0.05, 'bandpass', 1.1);
      this.impacto(this.busSfx, t, this._pe ? 110 : 92, 0.08, 0.02);
    }
  }

  playTone(freq = 540, dur = 0.12, type = 'sine', gain = 0.08) {
    if (!this.ctx || !this.enabled) return;
    try {
      const t = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const g = this.ctx.createGain();
      osc.type = type;
      osc.frequency.setValueAtTime(freq, t);
      g.gain.setValueAtTime(gain, t);
      g.gain.exponentialRampToValueAtTime(0.001, t + dur);
      osc.connect(g).connect(this.busSfx);
      osc.start(t);
      osc.stop(t + dur + 0.02);
    } catch {}
  }

  // Acerto: acorde maior curto (Lá, Dó sustenido, Mi) em cordas pinçadas
  playOk() {
    if (!this.ctx || !this.enabled) return;
    const t = this.ctx.currentTime;
    [69, 73, 76].forEach((m, i) => this.pluck(m, 0.22, t + i * 0.035, this.busSfx));
  }

  // Erro: nota abafada, grave e curta
  playErr() {
    if (!this.ctx || !this.enabled) return;
    const t = this.ctx.currentTime, c = this.ctx;
    const o = c.createOscillator(), f = c.createBiquadFilter(), g = c.createGain();
    o.type = 'triangle'; o.frequency.value = 196;
    f.type = 'lowpass'; f.frequency.value = 380;
    g.gain.setValueAtTime(0.12, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 0.3);
    o.connect(f).connect(g).connect(this.busSfx);
    o.start(t); o.stop(t + 0.32);
    this.conta(o);
  }

  // Evidência coletada: duas notas de viola
  playEvidencia() {
    if (!this.ctx || !this.enabled) return;
    const t = this.ctx.currentTime;
    this.pluck(69, 0.26, t, this.busSfx);
    this.pluck(76, 0.26, t + 0.09, this.busSfx);
  }

  // Segredo encontrado: arpejo rápido
  playSegredo() {
    if (!this.ctx || !this.enabled) return;
    const t = this.ctx.currentTime;
    [69, 73, 76, 81].forEach((m, i) => this.pluck(m, 0.2, t + i * 0.06, this.busSfx));
  }

  // Modal abrindo (sobe) ou fechando (desce)
  playModal(abrir = true) {
    if (!this.ctx || !this.enabled) return;
    this.varre(this.busSfx, this.ctx.currentTime, abrir ? 520 : 780, abrir ? 780 : 390, 0.09, 0.05, 'sine');
  }

  // Toque de telefone da ligação final: três sequências de toques
  toqueLigacao() {
    if (!this.ctx || !this.enabled) return;
    const t = this.ctx.currentTime + 0.05;
    for (let k = 0; k < 3; k++) this.toque(this.busSfx, t + k * 2.0, 0.05);
  }
}
